<?php
require_once 'includes/config.php';
$db = getDB();
header('Content-Type: application/json');

$pollId   = intval($_POST['poll_id']   ?? 0);
$optionId = intval($_POST['option_id'] ?? 0);
$voterIp  = $_SERVER['REMOTE_ADDR'];

if(!$pollId || !$optionId) {
    echo json_encode(['success'=>false,'message'=>'Invalid data.']);
    exit;
}

// Check already voted
if($db->query("SELECT id FROM poll_votes WHERE poll_id=$pollId AND voter_ip='$voterIp'")->num_rows > 0) {
    echo json_encode(['success'=>false,'message'=>'You have already voted!','already_voted'=>true]);
    exit;
}

// Record vote
$db->query("INSERT INTO poll_votes (poll_id, option_id, voter_ip) VALUES ($pollId, $optionId, '$voterIp')");
$db->query("UPDATE poll_options SET votes=votes+1 WHERE id=$optionId");

// Return updated results
$options = $db->query("SELECT * FROM poll_options WHERE poll_id=$pollId ORDER BY id ASC")->fetch_all(MYSQLI_ASSOC);
$total   = array_sum(array_column($options, 'votes'));

echo json_encode(['success'=>true,'options'=>$options,'total'=>$total]);