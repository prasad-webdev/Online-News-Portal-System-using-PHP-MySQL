<?php
require_once 'includes/config.php';
$db = getDB();

$slug = isset($_GET['slug']) ? sanitize($_GET['slug']) : '';
if(!$slug) redirect(SITE_URL);

$subcat = $db->query("SELECT s.*, c.name as cat_name, c.slug as cat_slug FROM subcategories s LEFT JOIN categories c ON c.id=s.category_id WHERE s.slug='$slug' AND s.deleted=0")->fetch_assoc();
if(!$subcat) { http_response_code(404); die("Subcategory not found"); }

$page = max(1, intval($_GET['page'] ?? 1));
$perPage = 9; $offset = ($page-1)*$perPage;
$subId = $subcat['id'];

$total = $db->query("SELECT COUNT(*) FROM posts WHERE subcategory_id=$subId AND status='published' AND deleted=0")->fetch_row()[0];
$totalPages = ceil($total/$perPage);
$posts = $db->query("SELECT p.*, c.name as cat_name, c.slug as cat_slug FROM posts p LEFT JOIN categories c ON c.id=p.category_id WHERE p.subcategory_id=$subId AND p.status='published' AND p.deleted=0 ORDER BY p.created_at DESC LIMIT $perPage OFFSET $offset")->fetch_all(MYSQLI_ASSOC);

$pageTitle = htmlspecialchars($subcat['name']) . ' - ' . htmlspecialchars($subcat['cat_name']);
include 'includes/header.php';
?>
<div class="breadcrumb">
    <div class="container">
        <a href="<?php echo SITE_URL; ?>">Home</a><span>&rsaquo;</span>
        <a href="category.php?slug=<?php echo $subcat['cat_slug']; ?>"><?php echo htmlspecialchars($subcat['cat_name']); ?></a><span>&rsaquo;</span>
        <span><?php echo htmlspecialchars($subcat['name']); ?></span>
    </div>
</div>
<div class="main-content">
    <div class="container">
        <div class="row">
            <div class="col-8">
                <div class="section-title"><?php echo htmlspecialchars($subcat['name']); ?> <span style="font-size:14px;font-weight:400;text-transform:none;">(<?php echo $total; ?> articles)</span></div>
                <?php if(empty($posts)): ?>
                <div style="background:#fff;padding:40px;text-align:center;border-radius:6px;"><i class="fas fa-newspaper" style="font-size:48px;color:#ccc;margin-bottom:16px;display:block;"></i><p style="color:var(--text-muted);">No posts found.</p></div>
                <?php else: ?>
                <div class="row">
                    <?php foreach($posts as $post): ?>
                    <div class="col-6">
                        <div class="news-card">
                            <?php if($post['image']): ?><img src="<?php echo UPLOAD_URL.htmlspecialchars($post['image']); ?>" alt="" class="news-card-img"><?php else: ?><div class="no-img"><i class="fas fa-newspaper"></i></div><?php endif; ?>
                            <div class="news-card-body">
                                <div class="news-card-title"><a href="post.php?slug=<?php echo $post['slug']; ?>"><?php echo htmlspecialchars($post['title']); ?></a></div>
                                <p class="news-card-excerpt"><?php echo truncate($post['content'],120); ?></p>
                                <div class="news-card-meta"><span><i class="far fa-calendar"></i> <?php echo timeAgo($post['created_at']); ?></span></div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php if($totalPages>1): ?>
                <div class="pagination">
                    <?php for($i=1;$i<=$totalPages;$i++): ?><a href="?slug=<?php echo $slug; ?>&page=<?php echo $i; ?>" class="page-link <?php echo $i==$page?'active':''; ?>"><?php echo $i; ?></a><?php endfor; ?>
                </div>
                <?php endif; ?>
                <?php endif; ?>
            </div>
            <div class="col-4"><?php include 'includes/sidebar.php'; ?></div>
        </div>
    </div>
</div>
<?php include 'includes/footer.php'; ?>
