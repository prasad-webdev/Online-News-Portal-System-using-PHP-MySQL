<?php
require_once 'includes/config.php';
$db = getDB();

// Must be logged in
if (!isset($_SESSION['user_id'])) {
    $_SESSION['redirect_after_login'] = SITE_URL . '/user-profile.php';
    setFlash('danger', 'Please login to view your profile.');
    redirect(SITE_URL . '/user-login.php');
}

$userId = intval($_SESSION['user_id']);
$user   = $db->query("SELECT * FROM users WHERE id=$userId")->fetch_assoc();

if (!$user) {
    redirect(SITE_URL . '/user-logout.php');
}

$errors  = [];
$success = '';

// ===== HANDLE PROFILE UPDATE =====
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // Update profile info
    if ($action === 'update_profile') {
        $name  = sanitize($_POST['name']  ?? '');
        $email = sanitize($_POST['email'] ?? '');

        if (!$name || !$email) {
            $errors[] = 'Name and email are required.';
        } elseif (!filter_var(htmlspecialchars_decode($email), FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Invalid email address.';
        } elseif ($email !== $user['email']) {
            // Check email not taken by another user
            $check = $db->query("SELECT id FROM users WHERE email='$email' AND id!=$userId");
            if ($check->num_rows > 0) {
                $errors[] = 'This email is already used by another account.';
            }
        }

        if (empty($errors)) {
            $db->query("UPDATE users SET name='$name', email='$email' WHERE id=$userId");
            $_SESSION['user_name']  = $name;
            $_SESSION['user_email'] = $email;
            $user['name']  = $name;
            $user['email'] = $email;
            $success = 'Profile updated successfully!';
        }
    }

    // Change password
    if ($action === 'change_password') {
        $current = $_POST['current_password'] ?? '';
        $new     = $_POST['new_password']     ?? '';
        $confirm = $_POST['confirm_password'] ?? '';

        if (!$current || !$new || !$confirm) {
            $errors[] = 'All password fields are required.';
        } elseif (!password_verify($current, $user['password'])) {
            $errors[] = 'Current password is incorrect.';
        } elseif (strlen($new) < 6) {
            $errors[] = 'New password must be at least 6 characters.';
        } elseif ($new !== $confirm) {
            $errors[] = 'New passwords do not match.';
        } else {
            $hash = password_hash($new, PASSWORD_DEFAULT);
            $db->query("UPDATE users SET password='$hash' WHERE id=$userId");
            $user['password'] = $hash;
            $success = 'Password changed successfully!';
        }
    }
}

// Get user stats
$commentCount = $db->query("SELECT COUNT(*) FROM comments WHERE email='{$db->real_escape_string($user['email'])}'")-> fetch_row()[0];
$memberDays   = (new DateTime())->diff(new DateTime($user['created_at']))->days;

$pageTitle = 'My Profile';
include 'includes/header.php';

// Avatar color based on user id
$avatarColors = ['#e74c3c','#3498db','#27ae60','#f39c12','#9b59b6','#1abc9c','#e67e22','#2ecc71'];
$avatarColor  = $avatarColors[$userId % count($avatarColors)];
?>

<!-- Breadcrumb -->
<div class="breadcrumb">
    <div class="container">
        <a href="<?php echo SITE_URL; ?>">Home</a>
        <span>&rsaquo;</span>
        <span style="color:#333;">My Profile</span>
    </div>
</div>

<div class="main-content">
    <div class="container">

        <?php if (!empty($errors)): ?>
        <div class="alert alert-danger" style="margin-bottom:20px;">
            <i class="fas fa-exclamation-circle"></i>
            <?php echo implode('<br>', $errors); ?>
        </div>
        <?php endif; ?>

        <?php if ($success): ?>
        <div class="alert alert-success" style="margin-bottom:20px;">
            <i class="fas fa-check-circle"></i> <?php echo $success; ?>
        </div>
        <?php endif; ?>

        <div class="row">

            <!-- LEFT: Profile Card -->
            <div class="col-4">

                <!-- Profile Card -->
                <div style="background:#fff;border-radius:10px;box-shadow:var(--shadow);
                            overflow:hidden;margin-bottom:20px;">
                    <!-- Cover -->
                    <div style="height:80px;background:linear-gradient(135deg,var(--primary),#c0392b);"></div>

                    <!-- Avatar + Name -->
                    <div style="text-align:center;padding:0 20px 24px;margin-top:-40px;">
                        <div style="width:80px;height:80px;border-radius:50%;
                                    background:<?php echo $avatarColor; ?>;color:#fff;
                                    display:inline-flex;align-items:center;justify-content:center;
                                    font-size:32px;font-weight:800;
                                    border:4px solid #fff;box-shadow:0 4px 12px rgba(0,0,0,0.15);">
                            <?php echo strtoupper(substr($user['name'], 0, 1)); ?>
                        </div>
                        <h2 style="font-size:18px;font-weight:700;color:var(--secondary);
                                   margin:12px 0 4px;">
                            <?php echo htmlspecialchars($user['name']); ?>
                        </h2>
                        <div style="font-size:13px;color:var(--text-muted);">
                            <?php echo htmlspecialchars($user['email']); ?>
                        </div>
                        <div style="margin-top:10px;">
                            <?php if ($user['status']): ?>
                            <span style="padding:4px 12px;background:#eafaf1;color:#27ae60;
                                         border-radius:20px;font-size:12px;font-weight:600;">
                                <i class="fas fa-circle" style="font-size:8px;"></i> Active
                            </span>
                            <?php else: ?>
                            <span style="padding:4px 12px;background:#fdedec;color:#e74c3c;
                                         border-radius:20px;font-size:12px;font-weight:600;">
                                <i class="fas fa-circle" style="font-size:8px;"></i> Inactive
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Stats Card -->
                <div style="background:#fff;border-radius:10px;box-shadow:var(--shadow);
                            padding:20px;margin-bottom:20px;">
                    <div style="font-size:13px;font-weight:700;color:var(--secondary);
                                text-transform:uppercase;letter-spacing:0.5px;margin-bottom:16px;">
                        Account Stats
                    </div>
                    <div style="display:flex;flex-direction:column;gap:14px;">
                        <div style="display:flex;justify-content:space-between;align-items:center;">
                            <div style="display:flex;align-items:center;gap:10px;">
                                <div style="width:34px;height:34px;background:#ebf5fb;border-radius:8px;
                                            display:flex;align-items:center;justify-content:center;">
                                    <i class="fas fa-calendar-alt" style="color:#3498db;font-size:14px;"></i>
                                </div>
                                <span style="font-size:13px;color:#666;">Member for</span>
                            </div>
                            <strong style="font-size:13px;color:var(--secondary);">
                                <?php echo $memberDays; ?> days
                            </strong>
                        </div>
                        <div style="display:flex;justify-content:space-between;align-items:center;">
                            <div style="display:flex;align-items:center;gap:10px;">
                                <div style="width:34px;height:34px;background:#eafaf1;border-radius:8px;
                                            display:flex;align-items:center;justify-content:center;">
                                    <i class="fas fa-comments" style="color:#27ae60;font-size:14px;"></i>
                                </div>
                                <span style="font-size:13px;color:#666;">Comments</span>
                            </div>
                            <strong style="font-size:13px;color:var(--secondary);">
                                <?php echo number_format($commentCount); ?>
                            </strong>
                        </div>
                        <div style="display:flex;justify-content:space-between;align-items:center;">
                            <div style="display:flex;align-items:center;gap:10px;">
                                <div style="width:34px;height:34px;background:#fef9e7;border-radius:8px;
                                            display:flex;align-items:center;justify-content:center;">
                                    <i class="fas fa-envelope" style="color:#f39c12;font-size:14px;"></i>
                                </div>
                                <span style="font-size:13px;color:#666;">Email verified</span>
                            </div>
                            <strong style="font-size:13px;color:<?php echo $user['email_verified'] ? '#27ae60' : '#e74c3c'; ?>;">
                                <?php echo $user['email_verified'] ? 'Yes' : 'No'; ?>
                            </strong>
                        </div>
                        <div style="display:flex;justify-content:space-between;align-items:center;">
                            <div style="display:flex;align-items:center;gap:10px;">
                                <div style="width:34px;height:34px;background:#fdedec;border-radius:8px;
                                            display:flex;align-items:center;justify-content:center;">
                                    <i class="fas fa-clock" style="color:#e74c3c;font-size:14px;"></i>
                                </div>
                                <span style="font-size:13px;color:#666;">Joined</span>
                            </div>
                            <strong style="font-size:13px;color:var(--secondary);">
                                <?php echo date('M j, Y', strtotime($user['created_at'])); ?>
                            </strong>
                        </div>
                    </div>
                </div>

                <!-- Logout Button -->
                <a href="<?php echo SITE_URL; ?>/user-logout.php"
                   style="display:flex;align-items:center;justify-content:center;gap:8px;
                          padding:12px;background:#fdedec;color:#e74c3c;border-radius:8px;
                          font-size:14px;font-weight:600;transition:all 0.2s;
                          border:2px solid #fadbd8;"
                   onmouseover="this.style.background='#e74c3c';this.style.color='#fff'"
                   onmouseout="this.style.background='#fdedec';this.style.color='#e74c3c'">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>

            </div><!-- end col-4 -->

            <!-- RIGHT: Edit Forms -->
            <div class="col-8">

                <!-- Tabs -->
                <div style="display:flex;gap:0;margin-bottom:20px;background:#fff;
                            border-radius:10px;box-shadow:var(--shadow);overflow:hidden;">
                    <button onclick="showTab('profile')" id="tabProfile"
                            style="flex:1;padding:14px;background:var(--primary);color:#fff;
                                   border:none;font-size:14px;font-weight:600;cursor:pointer;
                                   font-family:inherit;transition:all 0.2s;">
                        <i class="fas fa-user-edit"></i> Edit Profile
                    </button>
                    <button onclick="showTab('password')" id="tabPassword"
                            style="flex:1;padding:14px;background:#f8f9fa;color:#666;
                                   border:none;font-size:14px;font-weight:600;cursor:pointer;
                                   font-family:inherit;transition:all 0.2s;">
                        <i class="fas fa-lock"></i> Change Password
                    </button>
                    <button onclick="showTab('activity')" id="tabActivity"
                            style="flex:1;padding:14px;background:#f8f9fa;color:#666;
                                   border:none;font-size:14px;font-weight:600;cursor:pointer;
                                   font-family:inherit;transition:all 0.2s;">
                        <i class="fas fa-history"></i> My Activity
                    </button>
                </div>

                <!-- TAB: Edit Profile -->
                <div id="tabContentProfile"
                     style="background:#fff;border-radius:10px;box-shadow:var(--shadow);padding:28px;">
                    <h3 style="font-size:18px;color:var(--secondary);margin-bottom:22px;">
                        <i class="fas fa-user-edit" style="color:var(--primary);margin-right:8px;"></i>
                        Edit Profile
                    </h3>
                    <form method="POST">
                        <input type="hidden" name="action" value="update_profile">

                        <div style="margin-bottom:18px;">
                            <label style="display:block;font-size:13px;font-weight:600;
                                          margin-bottom:6px;color:var(--secondary);">
                                Full Name *
                            </label>
                            <div style="position:relative;">
                                <i class="fas fa-user" style="position:absolute;left:14px;top:50%;
                                   transform:translateY(-50%);color:#aaa;"></i>
                                <input type="text" name="name"
                                       value="<?php echo htmlspecialchars($user['name']); ?>"
                                       required placeholder="Your full name"
                                       style="width:100%;padding:11px 14px 11px 40px;
                                              border:2px solid var(--border);border-radius:6px;
                                              font-size:14px;outline:none;font-family:inherit;
                                              box-sizing:border-box;transition:border-color 0.2s;"
                                       onfocus="this.style.borderColor='var(--primary)'"
                                       onblur="this.style.borderColor='var(--border)'">
                            </div>
                        </div>

                        <div style="margin-bottom:24px;">
                            <label style="display:block;font-size:13px;font-weight:600;
                                          margin-bottom:6px;color:var(--secondary);">
                                Email Address *
                            </label>
                            <div style="position:relative;">
                                <i class="fas fa-envelope" style="position:absolute;left:14px;top:50%;
                                   transform:translateY(-50%);color:#aaa;"></i>
                                <input type="email" name="email"
                                       value="<?php echo htmlspecialchars($user['email']); ?>"
                                       required placeholder="your@email.com"
                                       style="width:100%;padding:11px 14px 11px 40px;
                                              border:2px solid var(--border);border-radius:6px;
                                              font-size:14px;outline:none;font-family:inherit;
                                              box-sizing:border-box;transition:border-color 0.2s;"
                                       onfocus="this.style.borderColor='var(--primary)'"
                                       onblur="this.style.borderColor='var(--border)'">
                            </div>
                        </div>

                        <button type="submit"
                                style="padding:12px 28px;background:var(--primary);color:#fff;
                                       border:none;border-radius:6px;font-size:15px;font-weight:600;
                                       cursor:pointer;font-family:inherit;transition:opacity 0.2s;"
                                onmouseover="this.style.opacity='0.85'"
                                onmouseout="this.style.opacity='1'">
                            <i class="fas fa-save"></i> Save Changes
                        </button>
                    </form>
                </div>

                <!-- TAB: Change Password -->
                <div id="tabContentPassword"
                     style="display:none;background:#fff;border-radius:10px;
                            box-shadow:var(--shadow);padding:28px;">
                    <h3 style="font-size:18px;color:var(--secondary);margin-bottom:22px;">
                        <i class="fas fa-lock" style="color:var(--primary);margin-right:8px;"></i>
                        Change Password
                    </h3>

                    <?php if ($user['password'] === ''): ?>
                    <div style="padding:16px;background:#fff8e1;border:1px solid #ffe082;
                                border-radius:8px;font-size:13px;color:#f57c00;margin-bottom:20px;">
                        <i class="fas fa-info-circle"></i>
                        You logged in via social account. Password change is not available for social logins.
                    </div>
                    <?php else: ?>
                    <form method="POST">
                        <input type="hidden" name="action" value="change_password">

                        <div style="margin-bottom:18px;">
                            <label style="display:block;font-size:13px;font-weight:600;
                                          margin-bottom:6px;color:var(--secondary);">
                                Current Password *
                            </label>
                            <div style="position:relative;">
                                <i class="fas fa-lock" style="position:absolute;left:14px;top:50%;
                                   transform:translateY(-50%);color:#aaa;"></i>
                                <input type="password" name="current_password"
                                       required placeholder="Enter current password"
                                       style="width:100%;padding:11px 14px 11px 40px;
                                              border:2px solid var(--border);border-radius:6px;
                                              font-size:14px;outline:none;font-family:inherit;
                                              box-sizing:border-box;transition:border-color 0.2s;"
                                       onfocus="this.style.borderColor='var(--primary)'"
                                       onblur="this.style.borderColor='var(--border)'">
                            </div>
                        </div>

                        <div style="margin-bottom:18px;">
                            <label style="display:block;font-size:13px;font-weight:600;
                                          margin-bottom:6px;color:var(--secondary);">
                                New Password *
                            </label>
                            <div style="position:relative;">
                                <i class="fas fa-key" style="position:absolute;left:14px;top:50%;
                                   transform:translateY(-50%);color:#aaa;"></i>
                                <input type="password" name="new_password" id="newPass"
                                       required placeholder="Min 6 characters"
                                       style="width:100%;padding:11px 14px 11px 40px;
                                              border:2px solid var(--border);border-radius:6px;
                                              font-size:14px;outline:none;font-family:inherit;
                                              box-sizing:border-box;transition:border-color 0.2s;"
                                       onfocus="this.style.borderColor='var(--primary)'"
                                       onblur="this.style.borderColor='var(--border)'"
                                       oninput="checkPasswordStrength(this.value)">
                            </div>
                            <!-- Password strength bar -->
                            <div id="strengthBar" style="margin-top:8px;display:none;">
                                <div style="height:4px;background:#f0f0f0;border-radius:4px;overflow:hidden;">
                                    <div id="strengthFill" style="height:100%;width:0%;border-radius:4px;transition:all 0.3s;"></div>
                                </div>
                                <div id="strengthText" style="font-size:11px;margin-top:4px;"></div>
                            </div>
                        </div>

                        <div style="margin-bottom:24px;">
                            <label style="display:block;font-size:13px;font-weight:600;
                                          margin-bottom:6px;color:var(--secondary);">
                                Confirm New Password *
                            </label>
                            <div style="position:relative;">
                                <i class="fas fa-key" style="position:absolute;left:14px;top:50%;
                                   transform:translateY(-50%);color:#aaa;"></i>
                                <input type="password" name="confirm_password"
                                       required placeholder="Repeat new password"
                                       style="width:100%;padding:11px 14px 11px 40px;
                                              border:2px solid var(--border);border-radius:6px;
                                              font-size:14px;outline:none;font-family:inherit;
                                              box-sizing:border-box;transition:border-color 0.2s;"
                                       onfocus="this.style.borderColor='var(--primary)'"
                                       onblur="this.style.borderColor='var(--border)'">
                            </div>
                        </div>

                        <button type="submit"
                                style="padding:12px 28px;background:var(--primary);color:#fff;
                                       border:none;border-radius:6px;font-size:15px;font-weight:600;
                                       cursor:pointer;font-family:inherit;transition:opacity 0.2s;"
                                onmouseover="this.style.opacity='0.85'"
                                onmouseout="this.style.opacity='1'">
                            <i class="fas fa-key"></i> Change Password
                        </button>
                    </form>
                    <?php endif; ?>
                </div>

                <!-- TAB: My Activity (Comments) -->
                <div id="tabContentActivity"
                     style="display:none;background:#fff;border-radius:10px;
                            box-shadow:var(--shadow);padding:28px;">
                    <h3 style="font-size:18px;color:var(--secondary);margin-bottom:22px;">
                        <i class="fas fa-history" style="color:var(--primary);margin-right:8px;"></i>
                        My Comments
                    </h3>
                    <?php
                    $myComments = $db->query("
                        SELECT c.*, p.title as post_title, p.slug as post_slug
                        FROM comments c
                        LEFT JOIN posts p ON p.id = c.post_id
                        WHERE c.email='{$db->real_escape_string($user['email'])}'
                        ORDER BY c.created_at DESC
                        LIMIT 10
                    ")->fetch_all(MYSQLI_ASSOC);
                    ?>
                    <?php if (empty($myComments)): ?>
                    <div style="text-align:center;padding:40px 20px;color:var(--text-muted);">
                        <i class="fas fa-comments" style="font-size:40px;color:#ddd;
                           display:block;margin-bottom:12px;"></i>
                        <div style="font-size:15px;font-weight:600;margin-bottom:6px;">
                            No comments yet
                        </div>
                        <div style="font-size:13px;">
                            Start commenting on news articles!
                        </div>
                        <a href="<?php echo SITE_URL; ?>"
                           style="display:inline-block;margin-top:14px;padding:9px 20px;
                                  background:var(--primary);color:#fff;border-radius:6px;
                                  font-size:13px;font-weight:600;">
                            Browse News
                        </a>
                    </div>
                    <?php else: ?>
                    <?php foreach ($myComments as $c): ?>
                    <div style="padding:14px;border:1px solid var(--border);border-radius:8px;
                                margin-bottom:12px;transition:box-shadow 0.2s;"
                         onmouseover="this.style.boxShadow='0 4px 12px rgba(0,0,0,0.08)'"
                         onmouseout="this.style.boxShadow='none'">
                        <div style="display:flex;justify-content:space-between;
                                    align-items:flex-start;gap:10px;margin-bottom:8px;">
                            <a href="<?php echo SITE_URL; ?>/post.php?slug=<?php echo $c['post_slug']; ?>"
                               style="font-size:13px;font-weight:600;color:var(--primary);
                                      line-height:1.4;">
                                <i class="fas fa-newspaper" style="margin-right:5px;"></i>
                                <?php echo htmlspecialchars($c['post_title'] ?? 'Deleted Post'); ?>
                            </a>
                            <span style="padding:3px 8px;border-radius:12px;font-size:11px;
                                         font-weight:600;white-space:nowrap;
                                         background:<?php echo $c['status']==='approved'?'#eafaf1':($c['status']==='pending'?'#fef9e7':'#fdedec'); ?>;
                                         color:<?php echo $c['status']==='approved'?'#27ae60':($c['status']==='pending'?'#f39c12':'#e74c3c'); ?>;">
                                <?php echo ucfirst($c['status']); ?>
                            </span>
                        </div>
                        <p style="font-size:13px;color:#555;margin:0 0 8px;line-height:1.5;">
                            "<?php echo htmlspecialchars(mb_substr($c['comment'], 0, 150)); ?><?php echo strlen($c['comment']) > 150 ? '...' : ''; ?>"
                        </p>
                        <div style="font-size:11px;color:var(--text-muted);">
                            <i class="far fa-clock"></i>
                            <?php echo date('M j, Y g:i A', strtotime($c['created_at'])); ?>
                            &nbsp;·&nbsp;
                            <?php echo timeAgo($c['created_at']); ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </div>

            </div><!-- end col-8 -->
        </div><!-- end row -->
    </div><!-- end container -->
</div><!-- end main-content -->

<script>
// ===== TAB SWITCHING =====
function showTab(tab) {
    // Hide all
    document.getElementById('tabContentProfile').style.display  = 'none';
    document.getElementById('tabContentPassword').style.display = 'none';
    document.getElementById('tabContentActivity').style.display = 'none';

    // Reset all tab buttons
    var tabs = ['tabProfile', 'tabPassword', 'tabActivity'];
    tabs.forEach(function(t) {
        var el = document.getElementById(t);
        el.style.background = '#f8f9fa';
        el.style.color      = '#666';
    });

    // Show selected
    document.getElementById('tabContent' + tab.charAt(0).toUpperCase() + tab.slice(1)).style.display = 'block';
    var activeTab = document.getElementById('tab' + tab.charAt(0).toUpperCase() + tab.slice(1));
    activeTab.style.background = 'var(--primary)';
    activeTab.style.color      = '#fff';
}

// ===== PASSWORD STRENGTH =====
function checkPasswordStrength(password) {
    var bar    = document.getElementById('strengthBar');
    var fill   = document.getElementById('strengthFill');
    var text   = document.getElementById('strengthText');

    if (!password) { bar.style.display = 'none'; return; }
    bar.style.display = 'block';

    var strength = 0;
    if (password.length >= 6)  strength++;
    if (password.length >= 10) strength++;
    if (/[A-Z]/.test(password)) strength++;
    if (/[0-9]/.test(password)) strength++;
    if (/[^A-Za-z0-9]/.test(password)) strength++;

    var levels = [
        { color: '#e74c3c', label: 'Very Weak',  width: '20%' },
        { color: '#e67e22', label: 'Weak',        width: '40%' },
        { color: '#f39c12', label: 'Fair',         width: '60%' },
        { color: '#27ae60', label: 'Strong',       width: '80%' },
        { color: '#1abc9c', label: 'Very Strong',  width: '100%' }
    ];
    var level = levels[Math.min(strength - 1, 4)] || levels[0];

    fill.style.width      = level.width;
    fill.style.background = level.color;
    text.style.color      = level.color;
    text.textContent      = level.label;
}

// ===== AUTO SHOW TAB IF ERROR ON PASSWORD =====
<?php if (!empty($errors) && isset($_POST['action']) && $_POST['action'] === 'change_password'): ?>
showTab('password');
<?php endif; ?>
</script>

<?php include 'includes/footer.php'; ?>
