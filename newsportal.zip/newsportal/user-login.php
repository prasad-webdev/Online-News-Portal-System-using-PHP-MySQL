<?php
require_once 'includes/config.php';
$db = getDB();

if(isset($_SESSION['user_id'])) redirect(SITE_URL);

$errors = [];
$success = '';

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // ===== REGISTER =====
    if($action === 'register') {
        $name     = sanitize($_POST['name'] ?? '');
        $email    = sanitize($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirm  = $_POST['confirm_password'] ?? '';

        if(!$name || !$email || !$password) {
            $errors[] = 'All fields are required.';
        } elseif(!filter_var(htmlspecialchars_decode($email), FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Invalid email address.';
        } elseif(strlen($password) < 6) {
            $errors[] = 'Password must be at least 6 characters.';
        } elseif($password !== $confirm) {
            $errors[] = 'Passwords do not match.';
        } elseif($db->query("SELECT id FROM users WHERE email='$email'")->num_rows > 0) {
            $errors[] = 'Email already registered. Please login.';
        } else {
            $hash  = password_hash($password, PASSWORD_DEFAULT);
            $token = bin2hex(random_bytes(32));
            $db->query("INSERT INTO users (name, email, password, token) VALUES ('$name', '$email', '$hash', '$token')");
            $userId = $db->insert_id;
            $_SESSION['user_id']    = $userId;
            $_SESSION['user_name']  = $name;
            $_SESSION['user_email'] = $email;
            setFlash('success', 'Welcome to NewsPortal, ' . $name . '!');
            redirect(SITE_URL);
        }
    }

    // ===== LOGIN =====
    if($action === 'login') {
        $email    = sanitize($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if(!$email || !$password) {
            $errors[] = 'Please enter email and password.';
        } else {
            $user = $db->query("SELECT * FROM users WHERE email='$email' AND status=1")->fetch_assoc();
            if($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id']    = $user['id'];
                $_SESSION['user_name']  = $user['name'];
                $_SESSION['user_email'] = $user['email'];
                setFlash('success', 'Welcome back, ' . $user['name'] . '!');
                $redirect = $_SESSION['redirect_after_login'] ?? SITE_URL;
                unset($_SESSION['redirect_after_login']);
                redirect($redirect);
            } else {
                $errors[] = 'Invalid email or password.';
            }
        }
    }
}

$tab = $_GET['tab'] ?? 'login';
$pageTitle = 'Login / Register';
include 'includes/header.php';
?>

<div class="main-content">
    <div class="container">
        <div style="max-width:480px;margin:0 auto;">

            <?php if(!empty($errors)): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i>
                <?php echo implode('<br>', $errors); ?>
            </div>
            <?php endif; ?>

            <div style="background:#fff;border-radius:10px;box-shadow:var(--shadow-hover);overflow:hidden;">

                <!-- Tabs -->
                <div style="display:flex;">
                    <a href="?tab=login"
                       style="flex:1;text-align:center;padding:16px;font-weight:700;font-size:15px;
                              background:<?php echo $tab==='login'?'var(--primary)':'#f8f9fa'; ?>;
                              color:<?php echo $tab==='login'?'#fff':'#666'; ?>;
                              transition:all 0.2s;">
                        <i class="fas fa-sign-in-alt"></i> Login
                    </a>
                    <a href="?tab=register"
                       style="flex:1;text-align:center;padding:16px;font-weight:700;font-size:15px;
                              background:<?php echo $tab==='register'?'var(--primary)':'#f8f9fa'; ?>;
                              color:<?php echo $tab==='register'?'#fff':'#666'; ?>;
                              transition:all 0.2s;">
                        <i class="fas fa-user-plus"></i> Register
                    </a>
                </div>

                <div style="padding:30px;">
                    <?php if($tab === 'login'): ?>
                    <!-- LOGIN FORM -->
                    <h2 style="font-size:22px;color:var(--secondary);margin-bottom:22px;">
                        Welcome Back!
                    </h2>
                    <form method="POST">
                        <input type="hidden" name="action" value="login">
                        <div style="margin-bottom:16px;">
                            <label style="display:block;font-size:13px;font-weight:600;margin-bottom:6px;color:var(--secondary);">
                                Email Address
                            </label>
                            <div style="position:relative;">
                                <i class="fas fa-envelope" style="position:absolute;left:14px;top:50%;transform:translateY(-50%);color:#aaa;"></i>
                                <input type="email" name="email"
                                       value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"
                                       placeholder="your@email.com" required
                                       style="width:100%;padding:11px 14px 11px 40px;border:2px solid var(--border);border-radius:6px;font-size:14px;outline:none;font-family:inherit;">
                            </div>
                        </div>
                        <div style="margin-bottom:20px;">
                            <label style="display:block;font-size:13px;font-weight:600;margin-bottom:6px;color:var(--secondary);">
                                Password
                            </label>
                            <div style="position:relative;">
                                <i class="fas fa-lock" style="position:absolute;left:14px;top:50%;transform:translateY(-50%);color:#aaa;"></i>
                                <input type="password" name="password"
                                       placeholder="Enter password" required
                                       style="width:100%;padding:11px 14px 11px 40px;border:2px solid var(--border);border-radius:6px;font-size:14px;outline:none;font-family:inherit;">
                            </div>
                        </div>
                        <button type="submit"
                                style="width:100%;padding:13px;background:var(--primary);color:#fff;border:none;border-radius:6px;font-size:15px;font-weight:700;cursor:pointer;">
                            <i class="fas fa-sign-in-alt"></i> Login
                        </button>
                    </form>
                    <p style="text-align:center;margin-top:16px;font-size:13px;color:#888;">
                        Don't have an account?
                        <a href="?tab=register" style="color:var(--primary);font-weight:600;">Register here</a>
                    </p>

                    <?php else: ?>
                    <!-- REGISTER FORM -->
                    <h2 style="font-size:22px;color:var(--secondary);margin-bottom:22px;">
                        Create Account
                    </h2>
                    <form method="POST">
                        <input type="hidden" name="action" value="register">
                        <div style="margin-bottom:16px;">
                            <label style="display:block;font-size:13px;font-weight:600;margin-bottom:6px;color:var(--secondary);">
                                Full Name
                            </label>
                            <div style="position:relative;">
                                <i class="fas fa-user" style="position:absolute;left:14px;top:50%;transform:translateY(-50%);color:#aaa;"></i>
                                <input type="text" name="name"
                                       value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>"
                                       placeholder="Your full name" required
                                       style="width:100%;padding:11px 14px 11px 40px;border:2px solid var(--border);border-radius:6px;font-size:14px;outline:none;font-family:inherit;">
                            </div>
                        </div>
                        <div style="margin-bottom:16px;">
                            <label style="display:block;font-size:13px;font-weight:600;margin-bottom:6px;color:var(--secondary);">
                                Email Address
                            </label>
                            <div style="position:relative;">
                                <i class="fas fa-envelope" style="position:absolute;left:14px;top:50%;transform:translateY(-50%);color:#aaa;"></i>
                                <input type="email" name="email"
                                       value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"
                                       placeholder="your@email.com" required
                                       style="width:100%;padding:11px 14px 11px 40px;border:2px solid var(--border);border-radius:6px;font-size:14px;outline:none;font-family:inherit;">
                            </div>
                        </div>
                        <div style="margin-bottom:16px;">
                            <label style="display:block;font-size:13px;font-weight:600;margin-bottom:6px;color:var(--secondary);">
                                Password
                            </label>
                            <div style="position:relative;">
                                <i class="fas fa-lock" style="position:absolute;left:14px;top:50%;transform:translateY(-50%);color:#aaa;"></i>
                                <input type="password" name="password"
                                       placeholder="Min 6 characters" required
                                       style="width:100%;padding:11px 14px 11px 40px;border:2px solid var(--border);border-radius:6px;font-size:14px;outline:none;font-family:inherit;">
                            </div>
                        </div>
                        <div style="margin-bottom:20px;">
                            <label style="display:block;font-size:13px;font-weight:600;margin-bottom:6px;color:var(--secondary);">
                                Confirm Password
                            </label>
                            <div style="position:relative;">
                                <i class="fas fa-lock" style="position:absolute;left:14px;top:50%;transform:translateY(-50%);color:#aaa;"></i>
                                <input type="password" name="confirm_password"
                                       placeholder="Repeat password" required
                                       style="width:100%;padding:11px 14px 11px 40px;border:2px solid var(--border);border-radius:6px;font-size:14px;outline:none;font-family:inherit;">
                            </div>
                        </div>
                        <button type="submit"
                                style="width:100%;padding:13px;background:var(--primary);color:#fff;border:none;border-radius:6px;font-size:15px;font-weight:700;cursor:pointer;">
                            <i class="fas fa-user-plus"></i> Create Account
                        </button>
                    </form>
                    <p style="text-align:center;margin-top:16px;font-size:13px;color:#888;">
                        Already have an account?
                        <a href="?tab=login" style="color:var(--primary);font-weight:600;">Login here</a>
                    </p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>