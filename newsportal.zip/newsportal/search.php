<?php
require_once 'includes/config.php';
$db = getDB();

$q = isset($_GET['q']) ? trim($_GET['q']) : '';
$page = max(1, intval($_GET['page'] ?? 1));
$perPage = 10; $offset = ($page-1)*$perPage;

$posts = []; $total = 0;
if($q) {
    $sq = $db->real_escape_string($q);
    $total = $db->query("SELECT COUNT(*) FROM posts p WHERE (p.title LIKE '%$sq%' OR p.content LIKE '%$sq%' OR p.tags LIKE '%$sq%') AND p.status='published' AND p.deleted=0")->fetch_row()[0];
    $posts = $db->query("SELECT p.*, c.name as cat_name, c.slug as cat_slug FROM posts p LEFT JOIN categories c ON c.id=p.category_id WHERE (p.title LIKE '%$sq%' OR p.content LIKE '%$sq%' OR p.tags LIKE '%$sq%') AND p.status='published' AND p.deleted=0 ORDER BY p.created_at DESC LIMIT $perPage OFFSET $offset")->fetch_all(MYSQLI_ASSOC);
}
$totalPages = ceil($total/$perPage);
$pageTitle = $q ? 'Search: ' . htmlspecialchars($q) : 'Search';
include 'includes/header.php';
?>
<div class="breadcrumb"><div class="container"><a href="<?php echo SITE_URL; ?>">Home</a><span>&rsaquo;</span><span>Search</span></div></div>
<div class="main-content">
    <div class="container">
        <div class="row">
            <div class="col-8">
                <div style="background:#fff;padding:24px;border-radius:6px;box-shadow:var(--shadow);margin-bottom:24px;">
                    <form action="search.php" method="GET">
                        <div style="display:flex;gap:10px;">
                            <input type="text" name="q" value="<?php echo htmlspecialchars($q); ?>" placeholder="Search for news..." style="flex:1;padding:12px 16px;border:2px solid var(--border);border-radius:5px;font-size:15px;outline:none;">
                            <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> Search</button>
                        </div>
                    </form>
                </div>
                
                <?php if($q): ?>
                <div class="section-title">
                    Search results for "<?php echo htmlspecialchars($q); ?>" 
                    <span style="font-size:14px;font-weight:400;text-transform:none;">(<?php echo $total; ?> results)</span>
                </div>
                <?php if(empty($posts)): ?>
                <div style="background:#fff;padding:40px;text-align:center;border-radius:6px;box-shadow:var(--shadow);">
                    <i class="fas fa-search" style="font-size:48px;color:#ccc;margin-bottom:16px;display:block;"></i>
                    <p style="color:var(--text-muted);">No results found for "<?php echo htmlspecialchars($q); ?>". Try different keywords.</p>
                </div>
                <?php else: ?>
                <?php foreach($posts as $post): ?>
                <div class="news-card" style="display:flex;margin-bottom:16px;">
                    <?php if($post['image']): ?>
                    <img src="<?php echo UPLOAD_URL.htmlspecialchars($post['image']); ?>" alt="" style="width:180px;height:130px;object-fit:cover;flex-shrink:0;border-radius:6px 0 0 6px;">
                    <?php else: ?>
                    <div style="width:180px;height:130px;background:#e0e0e0;display:flex;align-items:center;justify-content:center;flex-shrink:0;border-radius:6px 0 0 6px;"><i class="fas fa-newspaper" style="font-size:28px;color:#bbb;"></i></div>
                    <?php endif; ?>
                    <div class="news-card-body">
                        <a href="category.php?slug=<?php echo $post['cat_slug']; ?>" class="news-card-category"><?php echo htmlspecialchars($post['cat_name']); ?></a>
                        <div class="news-card-title"><a href="post.php?slug=<?php echo $post['slug']; ?>"><?php echo htmlspecialchars($post['title']); ?></a></div>
                        <p class="news-card-excerpt"><?php echo truncate($post['content'],150); ?></p>
                        <div class="news-card-meta">
                            <span><i class="far fa-calendar"></i> <?php echo timeAgo($post['created_at']); ?></span>
                            <span><i class="fas fa-eye"></i> <?php echo number_format($post['views']); ?></span>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
                <?php if($totalPages>1): ?>
                <div class="pagination">
                    <?php for($i=1;$i<=$totalPages;$i++): ?><a href="?q=<?php echo urlencode($q); ?>&page=<?php echo $i; ?>" class="page-link <?php echo $i==$page?'active':''; ?>"><?php echo $i; ?></a><?php endfor; ?>
                </div>
                <?php endif; ?>
                <?php endif; ?>
                <?php endif; ?>
            </div>
            <div class="col-4"><?php include 'includes/sidebar.php'; ?></div>
        </div>
    </div>
</div>
<?php include 'includes/footer.php'; ?>
