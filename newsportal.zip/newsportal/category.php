<?php
require_once 'includes/config.php';
$db = getDB();

$slug = isset($_GET['slug']) ? sanitize($_GET['slug']) : '';
if(!$slug) redirect(SITE_URL);

$category = $db->query("SELECT * FROM categories WHERE slug='$slug' AND deleted=0")->fetch_assoc();
if(!$category) { http_response_code(404); die("Category not found"); }

$page = max(1, intval($_GET['page'] ?? 1));
$perPage = 9;
$offset = ($page - 1) * $perPage;
$catId = $category['id'];

$total = $db->query("SELECT COUNT(*) FROM posts WHERE category_id=$catId AND status='published' AND deleted=0")->fetch_row()[0];
$totalPages = ceil($total / $perPage);

$posts = $db->query("SELECT p.*, c.name as cat_name, c.slug as cat_slug FROM posts p LEFT JOIN categories c ON c.id=p.category_id WHERE p.category_id=$catId AND p.status='published' AND p.deleted=0 ORDER BY p.created_at DESC LIMIT $perPage OFFSET $offset")->fetch_all(MYSQLI_ASSOC);

// Subcategories
$subcats = $db->query("SELECT * FROM subcategories WHERE category_id=$catId AND deleted=0 AND status=1")->fetch_all(MYSQLI_ASSOC);

$pageTitle = htmlspecialchars($category['name']) . ' News';
include 'includes/header.php';
?>

<div class="breadcrumb">
    <div class="container">
        <a href="<?php echo SITE_URL; ?>">Home</a>
        <span>&rsaquo;</span>
        <span><?php echo htmlspecialchars($category['name']); ?></span>
    </div>
</div>

<div class="main-content">
    <div class="container">
        <div class="row">
            <div class="col-8">
                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;">
                    <div class="section-title" style="margin-bottom:0;"><?php echo htmlspecialchars($category['name']); ?> <span style="font-size:14px;font-weight:400;text-transform:none;">(<?php echo $total; ?> articles)</span></div>
                </div>

                <?php if(!empty($subcats)): ?>
                <div style="margin-bottom:20px;display:flex;flex-wrap:wrap;gap:8px;">
                    <?php foreach($subcats as $sub): ?>
                    <a href="subcategory.php?slug=<?php echo $sub['slug']; ?>" class="tag" style="background:var(--primary);color:#fff;border-color:var(--primary);"><?php echo htmlspecialchars($sub['name']); ?></a>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>

                <?php if(empty($posts)): ?>
                <div style="background:#fff;padding:40px;text-align:center;border-radius:6px;box-shadow:var(--shadow);">
                    <i class="fas fa-newspaper" style="font-size:48px;color:#ccc;margin-bottom:16px;display:block;"></i>
                    <p style="color:var(--text-muted);">No posts found in this category yet.</p>
                </div>
                <?php else: ?>
                <div class="row">
                    <?php foreach($posts as $post): ?>
                    <div class="col-6">
                        <div class="news-card">
                            <?php if($post['image']): ?>
                            <img src="<?php echo UPLOAD_URL . htmlspecialchars($post['image']); ?>" alt="" class="news-card-img">
                            <?php else: ?>
                            <div class="no-img"><i class="fas fa-newspaper"></i></div>
                            <?php endif; ?>
                            <div class="news-card-body">
                                <div class="news-card-title">
                                    <a href="post.php?slug=<?php echo $post['slug']; ?>"><?php echo htmlspecialchars($post['title']); ?></a>
                                </div>
                                <p class="news-card-excerpt"><?php echo truncate($post['content'], 120); ?></p>
                                <div class="news-card-meta">
                                    <span><i class="far fa-calendar"></i> <?php echo timeAgo($post['created_at']); ?></span>
                                    <span><i class="fas fa-eye"></i> <?php echo number_format($post['views']); ?></span>
                                </div>
                                <a href="post.php?slug=<?php echo $post['slug']; ?>" class="btn btn-primary btn-sm" style="margin-top:10px;">Read More</a>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>

                <!-- Pagination -->
                <?php if($totalPages > 1): ?>
                <div class="pagination">
                    <?php if($page > 1): ?><a href="?slug=<?php echo $slug; ?>&page=<?php echo $page-1; ?>" class="page-link"><i class="fas fa-chevron-left"></i></a><?php endif; ?>
                    <?php for($i=1;$i<=$totalPages;$i++): ?>
                    <a href="?slug=<?php echo $slug; ?>&page=<?php echo $i; ?>" class="page-link <?php echo $i==$page?'active':''; ?>"><?php echo $i; ?></a>
                    <?php endfor; ?>
                    <?php if($page < $totalPages): ?><a href="?slug=<?php echo $slug; ?>&page=<?php echo $page+1; ?>" class="page-link"><i class="fas fa-chevron-right"></i></a><?php endif; ?>
                </div>
                <?php endif; ?>
                <?php endif; ?>
            </div>
            <div class="col-4"><?php include 'includes/sidebar.php'; ?></div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
