<?php
require_once 'includes/config.php';
$db = getDB();
header('Content-Type: application/json');

$name  = sanitize($_POST['name']  ?? '');
$email = sanitize($_POST['email'] ?? '');

if(!$email) {
    echo json_encode(['success'=>false,'message'=>'Email is required.']);
    exit;
}
if(!filter_var(htmlspecialchars_decode($email), FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success'=>false,'message'=>'Invalid email address.']);
    exit;
}
if($db->query("SELECT id FROM newsletter WHERE email='$email'")->num_rows > 0) {
    echo json_encode(['success'=>false,'message'=>'This email is already subscribed!']);
    exit;
}

$token = bin2hex(random_bytes(32));
$db->query("INSERT INTO newsletter (name, email, token, status) VALUES ('$name','$email','$token','active')");
echo json_encode(['success'=>true,'message'=>'Thank you for subscribing! You will receive the latest news updates.']);