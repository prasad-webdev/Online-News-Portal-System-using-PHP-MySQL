<?php
require_once 'includes/config.php';
$db = getDB();

$slug = isset($_GET['slug']) ? sanitize($_GET['slug']) : '';
if(!$slug) { redirect(SITE_URL); }

$post = $db->query("SELECT p.*, c.name as cat_name, c.slug as cat_slug, a.name as author FROM posts p LEFT JOIN categories c ON c.id=p.category_id LEFT JOIN admins a ON a.id=p.admin_id WHERE p.slug='$slug' AND p.status='published' AND p.deleted=0")->fetch_assoc();
if(!$post) { http_response_code(404); die("Post not found"); }

// Increment views
$db->query("UPDATE posts SET views=views+1 WHERE id={$post['id']}");

$pageTitle = $post['title'];
$metaDesc = truncate($post['content'], 160);

// Related posts
$catId = $post['category_id'];
$postId = $post['id'];
$related = $db->query("SELECT p.title, p.slug, p.image, p.created_at FROM posts p WHERE p.category_id=$catId AND p.id!=$postId AND p.status='published' AND p.deleted=0 ORDER BY p.created_at DESC LIMIT 3")->fetch_all(MYSQLI_ASSOC);

// Approved comments
$comments = $db->query("SELECT * FROM comments WHERE post_id={$post['id']} AND status='approved' ORDER BY created_at ASC")->fetch_all(MYSQLI_ASSOC);
$commentCount = count($comments);

// Handle comment submission
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_comment'])) {
    header('Content-Type: application/json');
    $name = sanitize($_POST['name'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $comment = sanitize($_POST['comment'] ?? '');
    
    if(!$name || !$email || !$comment) {
        echo json_encode(['success'=>false,'message'=>'All fields are required.']);
        exit;
    }
    if(!filter_var(htmlspecialchars_decode($email), FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success'=>false,'message'=>'Please enter a valid email.']);
        exit;
    }
    
    $stmt = $db->prepare("INSERT INTO comments (post_id, name, email, comment, status) VALUES (?, ?, ?, ?, 'pending')");
    $stmt->bind_param('isss', $post['id'], $name, $email, $comment);
    if($stmt->execute()) {
        echo json_encode(['success'=>true]);
    } else {
        echo json_encode(['success'=>false,'message'=>'Failed to submit comment.']);
    }
    exit;
}

include 'includes/header.php';
?>

<!-- Breadcrumb -->
<div class="breadcrumb">
    <div class="container">
        <a href="<?php echo SITE_URL; ?>">Home</a>
        <span>&rsaquo;</span>
        <a href="category.php?slug=<?php echo $post['cat_slug']; ?>"><?php echo htmlspecialchars($post['cat_name']); ?></a>
        <span>&rsaquo;</span>
        <span style="color:#333;"><?php echo htmlspecialchars(mb_substr($post['title'],0,50).'...'); ?></span>
    </div>
</div>

<div class="main-content">
    <div class="container">
        <div class="row">
            <div class="col-8">

                <!-- Post -->
                <div style="background:#fff;padding:28px;border-radius:6px;box-shadow:var(--shadow);margin-bottom:24px;">

                    <!-- Title + Meta -->
                    <div class="post-header">
                        <a href="category.php?slug=<?php echo $post['cat_slug']; ?>" class="news-card-category">
                            <?php echo htmlspecialchars($post['cat_name']); ?>
                        </a>
                        <h1 class="post-title" style="margin-top:10px;">
                            <?php echo htmlspecialchars($post['title']); ?>
                        </h1>
                        <div class="post-meta">
                            <span><i class="fas fa-user"></i> By <strong><?php echo htmlspecialchars($post['author']); ?></strong></span>
                            <span><i class="far fa-calendar-alt"></i> <?php echo date('F j, Y', strtotime($post['created_at'])); ?></span>
                            <span><i class="fas fa-eye"></i> <?php echo number_format($post['views']); ?> Views</span>
                            <span><i class="far fa-comment"></i> <?php echo $commentCount; ?> Comments</span>
                        </div>
                    </div>

                    <!-- Featured Image -->
                    <?php if($post['image']): ?>
                    <img src="<?php echo UPLOAD_URL . htmlspecialchars($post['image']); ?>"
                         alt="<?php echo htmlspecialchars($post['title']); ?>"
                         class="post-featured-img">
                    <?php endif; ?>

                    <!-- ===== AI TOOLBAR ===== -->
                    <div class="ai-toolbar">
                        <div class="ai-toolbar-title">
                            <i class="fas fa-robot"></i> AI Tools — Powered by NewsPortal AI
                        </div>
                        <button class="ai-btn ai-btn-summarize" id="btnSummarize">
                            <i class="fas fa-compress-alt ai-btn-text"></i>
                            <span class="ai-btn-text">Summarize Article</span>
                            <i class="fas fa-spinner ai-spinner"></i>
                        </button>
                        <button class="ai-btn ai-btn-sentiment" id="btnSentiment">
                            <i class="fas fa-chart-bar ai-btn-text"></i>
                            <span class="ai-btn-text">Sentiment Analysis</span>
                            <i class="fas fa-spinner ai-spinner"></i>
                        </button>
                        <button class="ai-btn ai-btn-related" id="btnRelated"
                            data-post-id="<?php echo $post['id']; ?>"
                            data-title="<?php echo htmlspecialchars($post['title']); ?>"
                            data-tags="<?php echo htmlspecialchars($post['tags'] ?? ''); ?>"
                            data-cat-id="<?php echo $post['category_id']; ?>"
                            data-site-url="<?php echo SITE_URL; ?>">
                            <i class="fas fa-network-wired ai-btn-text"></i>
                            <span class="ai-btn-text">Related News</span>
                            <i class="fas fa-spinner ai-spinner"></i>
                        </button>
                    </div>

                    <!-- AI Result: Summary -->
                    <div class="ai-result-box" id="aiSummaryBox">
                        <div class="ai-result-header purple">
                            <span><i class="fas fa-compress-alt"></i> AI Summary</span>
                            <button class="ai-result-close"><i class="fas fa-times"></i></button>
                        </div>
                        <div class="ai-result-body" id="summaryText"></div>
                    </div>

                    <!-- AI Result: Sentiment -->
                    <div class="ai-result-box" id="aiSentimentBox">
                        <div class="ai-result-header orange">
                            <span><i class="fas fa-chart-bar"></i> Sentiment Analysis</span>
                            <button class="ai-result-close"><i class="fas fa-times"></i></button>
                        </div>
                        <div class="ai-result-body" id="sentimentText"></div>
                    </div>

                    <!-- AI Result: Related -->
                    <div class="ai-result-box" id="aiRelatedBox">
                        <div class="ai-result-header teal">
                            <span><i class="fas fa-network-wired"></i> AI Related News</span>
                            <button class="ai-result-close"><i class="fas fa-times"></i></button>
                        </div>
                        <div class="ai-result-body" id="relatedText"></div>
                    </div>

                    <!-- Post Content -->
                    <div class="post-content" id="postContent">
                        <?php echo $post['content']; ?>
                    </div>

                    <!-- Tags -->
                    <?php if($post['tags']): ?>
                    <div class="post-tags" style="margin-top:24px;padding-top:18px;border-top:1px solid var(--border);">
                        <strong><i class="fas fa-tags"></i> Tags:</strong>
                        <?php foreach(array_map('trim', explode(',', $post['tags'])) as $tag): ?>
                        <a href="search.php?q=<?php echo urlencode($tag); ?>" class="tag" style="margin-left:6px;">
                            <?php echo htmlspecialchars($tag); ?>
                        </a>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>

                    <!-- Share Buttons -->
                    <div style="margin-top:20px;padding-top:18px;border-top:1px solid var(--border);">
                        <strong style="margin-right:14px;"><i class="fas fa-share-alt"></i> Share:</strong>
                        <?php
                            $shareUrl   = urlencode(SITE_URL.'/post.php?slug='.$post['slug']);
                            $shareTitle = urlencode($post['title']);
                        ?>
                        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $shareUrl; ?>"
                           target="_blank"
                           style="display:inline-block;padding:6px 14px;background:#1877f2;color:#fff;border-radius:4px;font-size:13px;margin-right:8px;">
                            <i class="fab fa-facebook-f"></i> Facebook
                        </a>
                        <a href="https://twitter.com/intent/tweet?text=<?php echo $shareTitle; ?>&url=<?php echo $shareUrl; ?>"
                           target="_blank"
                           style="display:inline-block;padding:6px 14px;background:#1da1f2;color:#fff;border-radius:4px;font-size:13px;margin-right:8px;">
                            <i class="fab fa-twitter"></i> Twitter
                        </a>
                        <a href="https://wa.me/?text=<?php echo $shareTitle . '%20' . $shareUrl; ?>"
                           target="_blank"
                           style="display:inline-block;padding:6px 14px;background:#25d366;color:#fff;border-radius:4px;font-size:13px;">
                            <i class="fab fa-whatsapp"></i> WhatsApp
                        </a>
                    </div>

                </div><!-- end post wrapper -->

                <!-- Related Posts -->
                <?php if(!empty($related)): ?>
                <div style="margin-bottom:24px;">
                    <div class="section-title">Related News</div>
                    <div class="row">
                        <?php foreach($related as $rp): ?>
                        <div class="col-12" style="width:33.333%;">
                            <div class="news-card">
                                <?php if($rp['image']): ?>
                                <img src="<?php echo UPLOAD_URL . htmlspecialchars($rp['image']); ?>"
                                     alt="" class="news-card-img" style="height:150px;">
                                <?php else: ?>
                                <div class="no-img" style="height:150px;">
                                    <i class="fas fa-newspaper"></i>
                                </div>
                                <?php endif; ?>
                                <div class="news-card-body">
                                    <div class="news-card-title" style="font-size:14px;">
                                        <a href="post.php?slug=<?php echo $rp['slug']; ?>">
                                            <?php echo htmlspecialchars($rp['title']); ?>
                                        </a>
                                    </div>
                                    <div class="news-card-meta" style="margin-top:8px;">
                                        <span><i class="far fa-clock"></i> <?php echo timeAgo($rp['created_at']); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Comments Section -->
                <div class="comments-section">
                    <div class="section-title">
                        <?php echo $commentCount; ?> Comment<?php echo $commentCount!=1?'s':''; ?>
                    </div>

                    <?php if(empty($comments)): ?>
                    <p style="color:var(--text-muted);font-size:14px;margin-bottom:20px;">
                        No comments yet. Be the first to comment!
                    </p>
                    <?php else: ?>
                    <?php foreach($comments as $c): ?>
                    <div class="comment-item">
                        <div class="comment-avatar">
                            <?php echo strtoupper(substr($c['name'],0,1)); ?>
                        </div>
                        <div>
                            <div class="comment-name"><?php echo htmlspecialchars($c['name']); ?></div>
                            <div class="comment-date">
                                <i class="far fa-clock"></i>
                                <?php echo date('M j, Y g:i A', strtotime($c['created_at'])); ?>
                            </div>
                            <div class="comment-text">
                                <?php echo nl2br(htmlspecialchars($c['comment'])); ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    <?php endif; ?>

                    <!-- Comment Form -->
                    <div style="margin-top:24px;padding-top:20px;border-top:2px solid var(--border);">
                        <h3 style="margin-bottom:20px;font-size:18px;color:var(--secondary);">
                            Leave a Comment
                        </h3>
                        <form id="commentForm" class="comment-form"
                              action="post.php?slug=<?php echo $post['slug']; ?>" method="POST">
                            <input type="hidden" name="submit_comment" value="1">
                            <div class="row">
                                <div class="col-6">
                                    <input type="text" name="name" placeholder="Your Name *" required>
                                </div>
                                <div class="col-6">
                                    <input type="email" name="email" placeholder="Your Email *" required>
                                </div>
                            </div>
                            <textarea name="comment"
                                      placeholder="Write your comment here *" required></textarea>
                            <p style="font-size:12px;color:var(--text-muted);margin-bottom:14px;">
                                <i class="fas fa-info-circle"></i>
                                Your comment will appear after moderation.
                            </p>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-paper-plane"></i> Post Comment
                            </button>
                        </form>
                    </div>

                </div><!-- end comments -->

            </div><!-- end col-8 -->

            <!-- Sidebar -->
            <div class="col-4">
                <?php include 'includes/sidebar.php'; ?>
            </div>

        </div><!-- end row -->
    </div><!-- end container -->
</div><!-- end main-content -->

<?php include 'includes/footer.php'; ?>