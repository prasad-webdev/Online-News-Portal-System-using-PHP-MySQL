<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'includes/config.php';

$_SESSION = [];
session_destroy();

header('Location: ' . SITE_URL);
exit;