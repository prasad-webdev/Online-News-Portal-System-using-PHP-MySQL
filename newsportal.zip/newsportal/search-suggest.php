<?php
require_once 'includes/config.php';
$db = getDB();
header('Content-Type: application/json');
$q = isset($_GET['q']) ? $db->real_escape_string(trim($_GET['q'])) : '';
if(strlen($q) < 2) { echo '[]'; exit; }
$results = $db->query("SELECT title, slug FROM posts WHERE title LIKE '%$q%' AND status='published' AND deleted=0 ORDER BY created_at DESC LIMIT 5")->fetch_all(MYSQLI_ASSOC);
echo json_encode($results);
