-- ============================================
-- NewsPortal1 - Complete Database SQL
-- Drop old database and recreate everything
-- ============================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

CREATE DATABASE IF NOT EXISTS `newsportal` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `newsportal`;

-- ============================================
-- TABLE: admins
-- ============================================
CREATE TABLE IF NOT EXISTS `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','subadmin') NOT NULL DEFAULT 'subadmin',
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Default admin: admin@news.com / password
INSERT INTO `admins` (`name`, `email`, `password`, `role`, `status`) VALUES
('Super Admin', 'admin@news.com', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', 'admin', 1);

-- ============================================
-- TABLE: categories
-- ============================================
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `slug` varchar(120) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `categories` (`name`, `slug`, `status`) VALUES
('Politics', 'politics', 1),
('Technology', 'technology', 1),
('Sports', 'sports', 1),
('Business', 'business', 1),
('Entertainment', 'entertainment', 1),
('Health', 'health', 1),
('Science', 'science', 1),
('World', 'world', 1);

-- ============================================
-- TABLE: subcategories
-- ============================================
CREATE TABLE IF NOT EXISTS `subcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `slug` varchar(120) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `subcategories` (`category_id`, `name`, `slug`) VALUES
(1, 'Local Politics', 'local-politics'),
(1, 'International Politics', 'international-politics'),
(2, 'Gadgets', 'gadgets'),
(2, 'Software', 'software'),
(3, 'Football', 'football'),
(3, 'Cricket', 'cricket'),
(4, 'Stock Market', 'stock-market'),
(5, 'Movies', 'movies');

-- ============================================
-- TABLE: posts
-- ============================================
CREATE TABLE IF NOT EXISTS `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `subcategory_id` int(11) DEFAULT NULL,
  `admin_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(280) NOT NULL,
  `content` longtext NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `tags` varchar(500) DEFAULT NULL,
  `status` enum('published','draft') NOT NULL DEFAULT 'draft',
  `views` int(11) NOT NULL DEFAULT 0,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `category_id` (`category_id`),
  KEY `admin_id` (`admin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `posts` (`category_id`, `subcategory_id`, `admin_id`, `title`, `slug`, `content`, `tags`, `status`, `views`) VALUES
(2, 3, 1, 'Latest Advancements in Artificial Intelligence', 'latest-advancements-in-artificial-intelligence', '<p>Artificial Intelligence continues to evolve at a rapid pace. From large language models to computer vision, the field is transforming industries worldwide.</p><p>Researchers have made significant breakthroughs in natural language processing, enabling machines to understand and generate human-like text with unprecedented accuracy. These developments have opened new possibilities in healthcare, finance, education, and beyond.</p><p>Machine learning algorithms are now capable of diagnosing diseases from medical images, predicting stock market trends, and even composing music. The integration of AI into everyday applications has become seamless, with virtual assistants becoming more intelligent and responsive.</p><p>However, these advancements also raise important ethical questions about privacy, job displacement, and the need for regulatory frameworks to ensure responsible AI development and deployment.</p>', 'AI, Technology, Machine Learning', 'published', 245),
(3, 5, 1, 'Champions League: Top Teams Battle for Glory', 'champions-league-top-teams-battle-for-glory', '<p>The UEFA Champions League is heating up as the world''s top football clubs compete for European supremacy. This season has already produced some remarkable matches.</p><p>Several underdog teams have surprised fans by defeating established giants, showcasing the unpredictable nature of knockout football. Goal-scoring records have been broken, and new stars have emerged on the international stage.</p><p>The tactical battles between managers have been as fascinating as the on-field action. High pressing, counter-attacking football, and set-piece specializations have all played crucial roles in determining outcomes.</p><p>As the tournament progresses towards the final, football fans around the world are eagerly anticipating what promises to be a memorable conclusion to this year''s competition.</p>', 'Football, Champions League, Sports', 'published', 189),
(4, 7, 1, 'Global Markets See Surge Amid Economic Recovery', 'global-markets-see-surge-amid-economic-recovery', '<p>Financial markets worldwide experienced significant gains this week as economic indicators point to a stronger-than-expected recovery. Major indices across Asia, Europe, and North America all posted impressive returns.</p><p>The technology sector led the charge, with several major companies reporting quarterly earnings that exceeded analyst expectations. Consumer spending data also came in higher than anticipated, suggesting renewed confidence among households.</p><p>Central banks have maintained their supportive monetary policies, providing a favorable backdrop for equity markets. Inflation concerns, while still present, appear to be moderating, reducing pressure for aggressive interest rate hikes.</p><p>Analysts caution that volatility could return as geopolitical tensions and supply chain disruptions remain unresolved issues that could dampen the recovery momentum.</p>', 'Business, Markets, Economy', 'published', 312),
(1, 1, 1, 'Government Announces New Infrastructure Investment Plan', 'government-announces-new-infrastructure-investment-plan', '<p>The government today unveiled a comprehensive infrastructure investment plan worth billions of dollars aimed at modernizing the nation''s roads, bridges, and digital networks.</p><p>The multi-year program will focus on repairing aging transportation infrastructure, expanding broadband access to rural areas, and investing in clean energy projects. Officials say the plan will create hundreds of thousands of jobs.</p><p>Opposition parties have offered mixed reactions, with some supporting the investment while others question the funding mechanisms and potential impact on the national debt.</p><p>Infrastructure experts have largely welcomed the announcement, noting that delayed maintenance has led to increased costs and safety concerns over the years.</p>', 'Politics, Government, Infrastructure', 'published', 156),
(6, NULL, 1, 'New Study Reveals Benefits of Mediterranean Diet', 'new-study-reveals-benefits-of-mediterranean-diet', '<p>A comprehensive new study published in a leading medical journal confirms that the Mediterranean diet offers significant health benefits, including reduced risk of heart disease, stroke, and certain types of cancer.</p><p>The research, which tracked over 25,000 participants for more than a decade, found that those who closely followed the Mediterranean diet had a 25% lower risk of cardiovascular events compared to those on standard Western diets.</p><p>The diet emphasizes fruits, vegetables, whole grains, legumes, nuts, and olive oil, while limiting red meat and processed foods. Moderate consumption of red wine is also considered part of the dietary pattern.</p><p>Nutritionists and healthcare professionals are encouraged by the findings, though they emphasize that dietary changes should be part of a broader healthy lifestyle approach.</p>', 'Health, Diet, Nutrition', 'published', 98),
(7, NULL, 1, 'Scientists Discover New Exoplanet That Could Support Life', 'scientists-discover-new-exoplanet-support-life', '<p>Astronomers have announced the discovery of a new exoplanet located in the habitable zone of its star, raising exciting possibilities for the existence of extraterrestrial life.</p><p>The planet, designated Kepler-452d, is roughly 1.5 times the size of Earth and orbits a Sun-like star approximately 1,400 light-years away. Its position in the habitable zone means liquid water could potentially exist on its surface.</p><p>Using advanced spectroscopic analysis, scientists have detected the presence of oxygen and methane in the planet''s atmosphere — two gases that on Earth are strongly associated with biological processes.</p><p>While researchers caution that much more study is needed before any conclusions can be drawn about life, the discovery is being hailed as one of the most significant in the history of exoplanet research.</p>', 'Science, Space, Discovery', 'published', 421),
(5, 8, 1, 'Blockbuster Season: Most Anticipated Movies of the Year', 'blockbuster-season-most-anticipated-movies', '<p>Hollywood is gearing up for one of its most exciting release seasons in years, with a lineup of blockbusters that promise to break box office records and dazzle audiences worldwide.</p><p>From superhero epics to animated adventures and dramatic thrillers, the upcoming slate has something for every type of moviegoer. Several highly anticipated sequels are set to conclude long-running franchises, while fresh original stories aim to capture audiences'' imaginations.</p><p>Streaming platforms continue to invest heavily in original content, blurring the line between theatrical and home viewing experiences. This year''s awards season is expected to be particularly competitive given the sheer volume of quality productions.</p><p>Industry analysts predict record-breaking revenues as pent-up demand from audiences eager for big-screen experiences continues to drive ticket sales to new highs.</p>', 'Entertainment, Movies, Hollywood', 'published', 203),
(8, NULL, 1, 'Climate Summit Reaches Historic Agreement on Carbon Emissions', 'climate-summit-historic-agreement-carbon-emissions', '<p>World leaders gathered at the international climate summit have reached a landmark agreement to reduce carbon emissions by 50% before 2035, in what experts are calling the most ambitious climate deal in history.</p><p>The agreement, signed by 190 countries, includes binding commitments to phase out coal-fired power plants, accelerate the transition to renewable energy, and establish a $100 billion annual fund to help developing nations adapt to climate change.</p><p>Environmental groups have cautiously welcomed the deal while emphasizing that implementation will be critical. Several major economies made last-minute pledges to increase their emission reduction targets, breaking a deadlock that threatened to derail the negotiations.</p><p>Scientists say that if fully implemented, the agreement could limit global warming to 1.5 degrees Celsius above pre-industrial levels, avoiding the most catastrophic consequences of climate change.</p>', 'World, Climate, Environment', 'published', 534);

-- ============================================
-- TABLE: comments
-- ============================================
CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `comment` text NOT NULL,
  `status` enum('approved','pending','rejected') NOT NULL DEFAULT 'pending',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `post_id` (`post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `comments` (`post_id`, `name`, `email`, `comment`, `status`) VALUES
(1, 'John Doe', 'john@example.com', 'Great article! AI is really changing the world in amazing ways.', 'approved'),
(1, 'Jane Smith', 'jane@example.com', 'Very informative. I especially liked the part about healthcare applications.', 'approved'),
(2, 'Mike Wilson', 'mike@example.com', 'This season has been incredible! Can''t wait for the finals.', 'approved'),
(3, 'Sarah Johnson', 'sarah@example.com', 'Interesting analysis of the market trends. Very helpful for investors.', 'pending'),
(6, 'Ravi Kumar', 'ravi@example.com', 'Mind-blowing discovery! The universe never ceases to amaze.', 'approved'),
(8, 'Emma Davis', 'emma@example.com', 'Finally some good news on climate change. Hope countries follow through.', 'approved');

-- ============================================
-- TABLE: pages
-- ============================================
CREATE TABLE IF NOT EXISTS `pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_name` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` longtext NOT NULL,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `page_name` (`page_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `pages` (`page_name`, `title`, `content`) VALUES
('about', 'About Us', '<h2>Welcome to News Portal</h2><p>News Portal is your trusted source for the latest news and information from around the world. We are committed to delivering accurate, timely, and comprehensive news coverage across a wide range of topics including politics, technology, sports, business, and entertainment.</p><p>Our team of experienced journalists and reporters work around the clock to bring you breaking news and in-depth analysis. We believe in the power of informed citizens and strive to make quality journalism accessible to everyone.</p><p>Founded with the mission of providing unbiased and factual reporting, News Portal has grown to become one of the most reliable news sources online. We adhere to the highest standards of journalistic integrity and ethics.</p><h3>Our Mission</h3><p>To inform, educate, and empower our readers with accurate and timely news coverage that matters to their lives and communities.</p><h3>Our Values</h3><ul><li>Accuracy and Truthfulness</li><li>Independence and Impartiality</li><li>Transparency and Accountability</li><li>Community Service</li></ul>'),
('contact', 'Contact Us', '<h2>Get In Touch</h2><p>We value your feedback and are always looking to improve our service. Whether you have a news tip, a correction to report, or just want to say hello, we''d love to hear from you.</p><h3>Contact Information</h3><p><strong>Email:</strong> info@newsportal.com</p><p><strong>Phone:</strong> +1 (555) 123-4567</p><p><strong>Address:</strong> 123 News Street, Media City, NY 10001</p><h3>News Tips</h3><p>Have a story we should cover? Send your tips to: tips@newsportal.com</p><h3>Advertising</h3><p>For advertising inquiries, please contact: ads@newsportal.com</p><h3>Editorial Team</h3><p>For editorial matters: editor@newsportal.com</p>');

-- ============================================
-- TABLE: users (NEW)
-- ============================================
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `email_verified` tinyint(1) NOT NULL DEFAULT 0,
  `token` varchar(64) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- TABLE: notifications (NEW)
-- ============================================
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `type` enum('breaking','info','warning','success') NOT NULL DEFAULT 'info',
  `link` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `notifications` (`title`, `message`, `type`, `link`) VALUES
('Welcome to NewsPortal!', 'Stay updated with the latest breaking news from around the world.', 'info', NULL),
('New Feature: AI Tools', 'Try our AI article summarizer and sentiment analyzer on any news post!', 'success', NULL),
('Breaking: Climate Agreement', 'World leaders sign historic carbon emissions deal. Read more now.', 'breaking', 'post.php?slug=climate-summit-historic-agreement-carbon-emissions');

-- ============================================
-- TABLE: user_notifications (NEW)
-- ============================================
CREATE TABLE IF NOT EXISTS `user_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `notification_id` int(11) NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- TABLE: polls (NEW)
-- ============================================
CREATE TABLE IF NOT EXISTS `polls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(500) NOT NULL,
  `status` enum('active','closed') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `polls` (`question`, `status`) VALUES
('Which news category do you read most?', 'active');

-- ============================================
-- TABLE: poll_options (NEW)
-- ============================================
CREATE TABLE IF NOT EXISTS `poll_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `poll_id` int(11) NOT NULL,
  `option_text` varchar(255) NOT NULL,
  `votes` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `poll_id` (`poll_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `poll_options` (`poll_id`, `option_text`, `votes`) VALUES
(1, 'Politics', 24),
(1, 'Technology', 38),
(1, 'Sports', 31),
(1, 'Business', 17),
(1, 'Entertainment', 22);

-- ============================================
-- TABLE: poll_votes (NEW)
-- ============================================
CREATE TABLE IF NOT EXISTS `poll_votes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `poll_id` int(11) NOT NULL,
  `option_id` int(11) NOT NULL,
  `voter_ip` varchar(45) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- TABLE: newsletter (NEW)
-- ============================================
CREATE TABLE IF NOT EXISTS `newsletter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(150) NOT NULL,
  `status` enum('active','unsubscribed') NOT NULL DEFAULT 'active',
  `token` varchar(64) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- FOREIGN KEY CONSTRAINTS
-- ============================================
ALTER TABLE `subcategories`
  ADD CONSTRAINT `fk_subcat_cat` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;

ALTER TABLE `posts`
  ADD CONSTRAINT `fk_post_cat` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `fk_post_admin` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`);

ALTER TABLE `comments`
  ADD CONSTRAINT `fk_comment_post` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE;

COMMIT;

-- ============================================
-- DONE! All tables created.
-- Admin login: admin@news.com / password
-- ============================================