-- News Portal Database
-- phpMyAdmin SQL Dump

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

CREATE DATABASE IF NOT EXISTS `newsportal1` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `newsportal1`;

-- --------------------------------------------------------
-- Table structure for table `admins`
CREATE TABLE `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','subadmin') NOT NULL DEFAULT 'subadmin',
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Default admin: admin@news.com / password
-- Password hash below is bcrypt of 'password'
INSERT INTO `admins` (`name`, `email`, `password`, `role`, `status`) VALUES
('Super Admin', 'admin@news.com', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', 'admin', 1);

-- --------------------------------------------------------
-- Table structure for table `categories`
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `slug` varchar(120) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `categories` (`name`, `slug`, `status`) VALUES
('Politics', 'politics', 1),
('Technology', 'technology', 1),
('Sports', 'sports', 1),
('Business', 'business', 1),
('Entertainment', 'entertainment', 1),
('Health', 'health', 1),
('Science', 'science', 1),
('World', 'world', 1);

-- --------------------------------------------------------
-- Table structure for table `subcategories`
CREATE TABLE `subcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `slug` varchar(120) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `subcategories` (`category_id`, `name`, `slug`) VALUES
(1, 'Local Politics', 'local-politics'),
(1, 'International Politics', 'international-politics'),
(2, 'Gadgets', 'gadgets'),
(2, 'Software', 'software'),
(3, 'Football', 'football'),
(3, 'Cricket', 'cricket'),
(4, 'Stock Market', 'stock-market'),
(5, 'Movies', 'movies');

-- --------------------------------------------------------
-- Table structure for table `posts`
CREATE TABLE `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `subcategory_id` int(11) DEFAULT NULL,
  `admin_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(280) NOT NULL,
  `content` longtext NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `tags` varchar(500) DEFAULT NULL,
  `status` enum('published','draft') NOT NULL DEFAULT 'draft',
  `views` int(11) NOT NULL DEFAULT 0,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `category_id` (`category_id`),
  KEY `admin_id` (`admin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `posts` (`category_id`, `subcategory_id`, `admin_id`, `title`, `slug`, `content`, `tags`, `status`) VALUES
(2, 3, 1, 'Latest Advancements in Artificial Intelligence', 'latest-advancements-in-artificial-intelligence', '<p>Artificial Intelligence continues to evolve at a rapid pace. From large language models to computer vision, the field is transforming industries worldwide.</p><p>Researchers have made significant breakthroughs in natural language processing, enabling machines to understand and generate human-like text with unprecedented accuracy. These developments have opened new possibilities in healthcare, finance, education, and beyond.</p><p>Machine learning algorithms are now capable of diagnosing diseases from medical images, predicting stock market trends, and even composing music. The integration of AI into everyday applications has become seamless, with virtual assistants becoming more intelligent and responsive.</p><p>However, these advancements also raise important ethical questions about privacy, job displacement, and the need for regulatory frameworks to ensure responsible AI development and deployment.</p>', 'AI, Technology, Machine Learning', 'published'),
(3, 5, 1, 'Champions League: Top Teams Battle for Glory', 'champions-league-top-teams-battle-for-glory', '<p>The UEFA Champions League is heating up as the world''s top football clubs compete for European supremacy. This season has already produced some remarkable matches.</p><p>Several underdog teams have surprised fans by defeating established giants, showcasing the unpredictable nature of knockout football. Goal-scoring records have been broken, and new stars have emerged on the international stage.</p><p>The tactical battles between managers have been as fascinating as the on-field action. High pressing, counter-attacking football, and set-piece specializations have all played crucial roles in determining outcomes.</p><p>As the tournament progresses towards the final, football fans around the world are eagerly anticipating what promises to be a memorable conclusion to this year''s competition.</p>', 'Football, Champions League, Sports', 'published'),
(4, 7, 1, 'Global Markets See Surge Amid Economic Recovery', 'global-markets-see-surge-amid-economic-recovery', '<p>Financial markets worldwide experienced significant gains this week as economic indicators point to a stronger-than-expected recovery. Major indices across Asia, Europe, and North America all posted impressive returns.</p><p>The technology sector led the charge, with several major companies reporting quarterly earnings that exceeded analyst expectations. Consumer spending data also came in higher than anticipated, suggesting renewed confidence among households.</p><p>Central banks have maintained their supportive monetary policies, providing a favorable backdrop for equity markets. Inflation concerns, while still present, appear to be moderating, reducing pressure for aggressive interest rate hikes.</p><p>Analysts caution that volatility could return as geopolitical tensions and supply chain disruptions remain unresolved issues that could dampen the recovery momentum.</p>', 'Business, Markets, Economy', 'published'),
(1, 1, 1, 'Government Announces New Infrastructure Investment Plan', 'government-announces-new-infrastructure-investment-plan', '<p>The government today unveiled a comprehensive infrastructure investment plan worth billions of dollars aimed at modernizing the nation''s roads, bridges, and digital networks.</p><p>The multi-year program will focus on repairing aging transportation infrastructure, expanding broadband access to rural areas, and investing in clean energy projects. Officials say the plan will create hundreds of thousands of jobs.</p><p>Opposition parties have offered mixed reactions, with some supporting the investment while others question the funding mechanisms and potential impact on the national debt.</p><p>Infrastructure experts have largely welcomed the announcement, noting that delayed maintenance has led to increased costs and safety concerns over the years.</p>', 'Politics, Government, Infrastructure', 'published'),
(6, NULL, 1, 'New Study Reveals Benefits of Mediterranean Diet', 'new-study-reveals-benefits-of-mediterranean-diet', '<p>A comprehensive new study published in a leading medical journal confirms that the Mediterranean diet offers significant health benefits, including reduced risk of heart disease, stroke, and certain types of cancer.</p><p>The research, which tracked over 25,000 participants for more than a decade, found that those who closely followed the Mediterranean diet had a 25% lower risk of cardiovascular events compared to those on standard Western diets.</p><p>The diet emphasizes fruits, vegetables, whole grains, legumes, nuts, and olive oil, while limiting red meat and processed foods. Moderate consumption of red wine is also considered part of the dietary pattern.</p><p>Nutritionists and healthcare professionals are encouraged by the findings, though they emphasize that dietary changes should be part of a broader healthy lifestyle approach.</p>', 'Health, Diet, Nutrition', 'published');

-- --------------------------------------------------------
-- Table structure for table `comments`
CREATE TABLE `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `comment` text NOT NULL,
  `status` enum('approved','pending','rejected') NOT NULL DEFAULT 'pending',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `post_id` (`post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `comments` (`post_id`, `name`, `email`, `comment`, `status`) VALUES
(1, 'John Doe', 'john@example.com', 'Great article! AI is really changing the world in amazing ways.', 'approved'),
(1, 'Jane Smith', 'jane@example.com', 'Very informative. I especially liked the part about healthcare applications.', 'approved'),
(2, 'Mike Wilson', 'mike@example.com', 'This season has been incredible! Can''t wait for the finals.', 'approved'),
(3, 'Sarah Johnson', 'sarah@example.com', 'Interesting analysis of the market trends. Very helpful for investors.', 'pending');

-- --------------------------------------------------------
-- Table structure for table `pages`
CREATE TABLE `pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_name` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` longtext NOT NULL,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `page_name` (`page_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `pages` (`page_name`, `title`, `content`) VALUES
('about', 'About Us', '<h2>Welcome to News Portal</h2><p>News Portal is your trusted source for the latest news and information from around the world. We are committed to delivering accurate, timely, and comprehensive news coverage across a wide range of topics including politics, technology, sports, business, and entertainment.</p><p>Our team of experienced journalists and reporters work around the clock to bring you breaking news and in-depth analysis. We believe in the power of informed citizens and strive to make quality journalism accessible to everyone.</p><p>Founded with the mission of providing unbiased and factual reporting, News Portal has grown to become one of the most reliable news sources online. We adhere to the highest standards of journalistic integrity and ethics.</p><h3>Our Mission</h3><p>To inform, educate, and empower our readers with accurate and timely news coverage that matters to their lives and communities.</p><h3>Our Values</h3><ul><li>Accuracy and Truthfulness</li><li>Independence and Impartiality</li><li>Transparency and Accountability</li><li>Community Service</li></ul>'),
('contact', 'Contact Us', '<h2>Get In Touch</h2><p>We value your feedback and are always looking to improve our service. Whether you have a news tip, a correction to report, or just want to say hello, we''d love to hear from you.</p><h3>Contact Information</h3><p><strong>Email:</strong> info@newsportal.com</p><p><strong>Phone:</strong> +1 (555) 123-4567</p><p><strong>Address:</strong> 123 News Street, Media City, NY 10001</p><h3>News Tips</h3><p>Have a story we should cover? Send your tips to: tips@newsportal.com</p><h3>Advertising</h3><p>For advertising inquiries, please contact: ads@newsportal.com</p><h3>Editorial Team</h3><p>For editorial matters: editor@newsportal.com</p>');

-- --------------------------------------------------------
-- Add foreign key constraints
ALTER TABLE `subcategories`
  ADD CONSTRAINT `fk_subcat_cat` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;

ALTER TABLE `posts`
  ADD CONSTRAINT `fk_post_cat` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `fk_post_admin` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`);

ALTER TABLE `comments`
  ADD CONSTRAINT `fk_comment_post` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE;

COMMIT;
