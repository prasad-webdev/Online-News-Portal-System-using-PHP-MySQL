// ===== AI FEATURES JAVASCRIPT =====

var AI_URL = document.querySelector('meta[name="site-url"]') 
    ? document.querySelector('meta[name="site-url"]').content + '/includes/ai-features.php'
    : '/newsportal/includes/ai-features.php';

$(document).ready(function() {

    // ==========================================
    // AI TOOLBAR - Post Page Features
    // ==========================================

    // 1. SUMMARIZER
    $('#btnSummarize').on('click', function() {
        var $btn = $(this);
        var content = $('#postContent').text();
        if (!content) return;

        $btn.addClass('loading');
        $('#aiSummaryBox').removeClass('show');

        $.ajax({
            url: AI_URL,
            type: 'POST',
            data: { action: 'summarize', content: content },
            dataType: 'json',
            success: function(res) {
                if (res.success) {
                    $('#summaryText').html(
                        '<p>' + res.summary + '</p>' +
                        '<div style="margin-top:10px;font-size:12px;color:#888;">' +
                        '<i class="fas fa-info-circle"></i> ' +
                        'Original article: <strong>' + res.words + ' words</strong>' +
                        '</div>'
                    );
                    $('#aiSummaryBox').addClass('show');
                    $('html,body').animate({ scrollTop: $('#aiSummaryBox').offset().top - 80 }, 400);
                }
            },
            complete: function() { $btn.removeClass('loading'); }
        });
    });

    // 2. SENTIMENT ANALYZER
    $('#btnSentiment').on('click', function() {
        var $btn = $(this);
        var content = $('#postContent').text();
        if (!content) return;

        $btn.addClass('loading');
        $('#aiSentimentBox').removeClass('show');

        $.ajax({
            url: AI_URL,
            type: 'POST',
            data: { action: 'sentiment', content: content },
            dataType: 'json',
            success: function(res) {
                if (res.success) {
                    var d = res.data;
                    var html = '<div class="sentiment-display">' +
                        '<div class="sentiment-icon">' + d.icon + '</div>' +
                        '<div>' +
                        '<div class="sentiment-label" style="color:' + d.color + '">' + d.sentiment + '</div>' +
                        '<div style="font-size:13px;color:#888;">Tone Analysis</div>' +
                        '</div>' +
                        '<div class="sentiment-bar-wrap">' +
                        '<div class="sentiment-bar-label"><span>Negative</span><span>Positive</span></div>' +
                        '<div class="sentiment-bar-bg">' +
                        '<div class="sentiment-bar-fill" style="width:' + d.score + '%;background:' + d.color + ';"></div>' +
                        '</div>' +
                        '<div class="sentiment-counts">' +
                        '<span class="sentiment-pos"><i class="fas fa-smile"></i> ' + d.positive + ' positive signals</span>' +
                        '<span class="sentiment-neg"><i class="fas fa-frown"></i> ' + d.negative + ' negative signals</span>' +
                        '</div>' +
                        '</div>' +
                        '</div>';
                    $('#sentimentText').html(html);
                    $('#aiSentimentBox').addClass('show');
                    $('html,body').animate({ scrollTop: $('#aiSentimentBox').offset().top - 80 }, 400);
                }
            },
            complete: function() { $btn.removeClass('loading'); }
        });
    });

    // 3. RELATED NEWS
    $('#btnRelated').on('click', function() {
        var $btn = $(this);
        var postId = $btn.data('post-id');
        var title  = $btn.data('title');
        var tags   = $btn.data('tags');
        var catId  = $btn.data('cat-id');

        $btn.addClass('loading');
        $('#aiRelatedBox').removeClass('show');

        $.ajax({
            url: AI_URL,
            type: 'POST',
            data: { action: 'related', post_id: postId, title: title, tags: tags, category_id: catId },
            dataType: 'json',
            success: function(res) {
                if (res.success && res.posts.length > 0) {
                    var SITE_URL = $btn.data('site-url');
                    var html = '<div class="ai-related-grid">';
                    $.each(res.posts, function(i, post) {
                        html += '<a href="' + SITE_URL + '/post.php?slug=' + post.slug + '" class="ai-related-item">';
                        if (post.image) {
                            html += '<img src="' + SITE_URL + '/uploads/news/' + post.image + '" class="ai-related-img" alt="">';
                        } else {
                            html += '<div class="ai-related-no-img"><i class="fas fa-newspaper"></i></div>';
                        }
                        html += '<div class="ai-related-title">' + post.title + '</div>';
                        html += '</a>';
                    });
                    html += '</div>';
                    $('#relatedText').html(html);
                    $('#aiRelatedBox').addClass('show');
                    $('html,body').animate({ scrollTop: $('#aiRelatedBox').offset().top - 80 }, 400);
                } else {
                    $('#relatedText').html('<p style="color:#888;">No related articles found.</p>');
                    $('#aiRelatedBox').addClass('show');
                }
            },
            complete: function() { $btn.removeClass('loading'); }
        });
    });

    // Close AI result boxes
    $(document).on('click', '.ai-result-close', function() {
        $(this).closest('.ai-result-box').removeClass('show');
    });

    // ==========================================
    // CHATBOT
    // ==========================================
    var chatOpen = false;

    // Toggle chatbot
    $('#chatbotToggle').on('click', function() {
        chatOpen = !chatOpen;
        if (chatOpen) {
            $('#chatbotWindow').addClass('open');
            $('#chatbotToggle i').removeClass('fa-robot').addClass('fa-times');
            $('.chatbot-badge').hide();
            $('#chatbotInput').focus();
        } else {
            $('#chatbotWindow').removeClass('open');
            $('#chatbotToggle i').removeClass('fa-times').addClass('fa-robot');
        }
    });

    $('#chatbotClose').on('click', function() {
        chatOpen = false;
        $('#chatbotWindow').removeClass('open');
        $('#chatbotToggle i').removeClass('fa-times').addClass('fa-robot');
    });

    // Send message
    function sendChatMessage(message) {
        if (!message.trim()) return;

        // Add user message
        appendMessage('user', message);
        $('#chatbotInput').val('');

        // Remove quick replies
        $('.quick-replies').remove();

        // Show typing
        var typingHtml = '<div class="chat-msg bot" id="typingMsg">' +
            '<div class="chat-msg-avatar"><i class="fas fa-robot"></i></div>' +
            '<div class="typing-indicator">' +
            '<div class="typing-dot"></div>' +
            '<div class="typing-dot"></div>' +
            '<div class="typing-dot"></div>' +
            '</div></div>';
        $('#chatMessages').append(typingHtml);
        scrollChat();

        $.ajax({
            url: AI_URL,
            type: 'POST',
            data: { action: 'chatbot', message: message },
            dataType: 'json',
            success: function(res) {
                $('#typingMsg').remove();
                if (res.success) {
                    appendMessage('bot', res.response);
                } else {
                    appendMessage('bot', 'Sorry, something went wrong. Please try again.');
                }
            },
            error: function() {
                $('#typingMsg').remove();
                appendMessage('bot', 'Connection error. Please try again.');
            }
        });
    }

    function appendMessage(type, text) {
        var icon = type === 'bot' ? 'fa-robot' : 'fa-user';
        var html = '<div class="chat-msg ' + type + '">' +
            '<div class="chat-msg-avatar"><i class="fas ' + icon + '"></i></div>' +
            '<div class="chat-msg-bubble">' + text.replace(/\n/g, '<br>') + '</div>' +
            '</div>';
        $('#chatMessages').append(html);
        scrollChat();
    }

    function scrollChat() {
        var $msgs = $('#chatMessages');
        $msgs.scrollTop($msgs[0].scrollHeight);
    }

    // Send on button click
    $('#chatbotSend').on('click', function() {
        sendChatMessage($('#chatbotInput').val());
    });

    // Send on Enter key
    $('#chatbotInput').on('keypress', function(e) {
        if (e.which === 13) {
            sendChatMessage($(this).val());
        }
    });

    // Quick reply chips
    $(document).on('click', '.quick-chip', function() {
        sendChatMessage($(this).text());
    });

});