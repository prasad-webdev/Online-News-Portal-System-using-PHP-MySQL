// ============================================
// assets/js/main.js
// NOTE: Dark mode is handled in header.php
// DO NOT add dark mode code here
// ============================================

$(document).ready(function () {

    // ===== READING PROGRESS BAR =====
    $(window).on('scroll', function () {
        var scrollTop    = $(window).scrollTop();
        var docHeight    = $(document).height() - $(window).height();
        var scrollPercent = docHeight > 0 ? (scrollTop / docHeight) * 100 : 0;
        $('#readingProgress').css('width', scrollPercent + '%');
    });

    // ===== SEARCH SUGGESTIONS =====
    var searchTimer;
    $('#headerSearch').on('keyup', function () {
        var query = $(this).val().trim();
        clearTimeout(searchTimer);

        if (query.length < 2) {
            $('#searchSuggestions').hide().html('');
            return;
        }

        searchTimer = setTimeout(function () {
            $.ajax({
                url: $('#headerSearch').closest('form').attr('action').replace('search.php', 'search-suggest.php'),
                type: 'GET',
                data: { q: query },
                success: function (data) {
                    if (data.trim()) {
                        $('#searchSuggestions').html(data).show();
                    } else {
                        $('#searchSuggestions').hide().html('');
                    }
                }
            });
        }, 300);
    });

    // Hide suggestions on outside click
    $(document).on('click', function (e) {
        if (!$(e.target).closest('.header-search').length) {
            $('#searchSuggestions').hide().html('');
        }
    });

    // ===== BREAKING NEWS TICKER =====
    var $ticker = $('.breaking-ticker-inner');
    if ($ticker.length) {
        var tickerWidth = $ticker.outerWidth();
        var wrapWidth   = $('.breaking-ticker').outerWidth();
        if (tickerWidth > wrapWidth) {
            $ticker.addClass('animate');
        }
    }

    // ===== COMMENT FORM AJAX =====
    $('#commentForm').on('submit', function (e) {
        e.preventDefault();
        var $form   = $(this);
        var $btn    = $form.find('button[type="submit"]');
        var origTxt = $btn.html();

        $btn.html('<i class="fas fa-spinner fa-spin"></i> Submitting...').prop('disabled', true);

        $.ajax({
            url:      $form.attr('action'),
            type:     'POST',
            data:     $form.serialize(),
            dataType: 'json',
            success: function (res) {
                if (res.success) {
                    $form[0].reset();
                    showAlert('success', '<i class="fas fa-check-circle"></i> Your comment has been submitted and is awaiting moderation. Thank you!');
                    $('html,body').animate({ scrollTop: $('.comments-section').offset().top - 80 }, 400);
                } else {
                    showAlert('danger', '<i class="fas fa-exclamation-circle"></i> ' + (res.message || 'Something went wrong.'));
                }
            },
            error: function () {
                showAlert('danger', '<i class="fas fa-exclamation-circle"></i> Connection error. Please try again.');
            },
            complete: function () {
                $btn.html(origTxt).prop('disabled', false);
            }
        });
    });

    function showAlert(type, message) {
        var $alert = $('<div class="alert alert-' + type + '" style="margin-top:12px;">' + message + '</div>');
        $('#commentForm').before($alert);
        setTimeout(function () { $alert.fadeOut(400, function () { $(this).remove(); }); }, 5000);
    }

    // ===== CONFIRM DELETE =====
    $(document).on('click', '.confirm-delete', function (e) {
        if (!confirm('Are you sure you want to delete this? This action cannot be undone.')) {
            e.preventDefault();
        }
    });

    // ===== SMOOTH SCROLL for anchor links =====
    $(document).on('click', 'a[href^="#"]', function (e) {
        var target = $(this.getAttribute('href'));
        if (target.length) {
            e.preventDefault();
            $('html,body').animate({ scrollTop: target.offset().top - 80 }, 400);
        }
    });

    // ===== LAZY LOAD IMAGES =====
    if ('IntersectionObserver' in window) {
        var imgObserver = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    var img = entry.target;
                    if (img.dataset.src) {
                        img.src = img.dataset.src;
                        img.removeAttribute('data-src');
                        imgObserver.unobserve(img);
                    }
                }
            });
        });
        document.querySelectorAll('img[data-src]').forEach(function (img) {
            imgObserver.observe(img);
        });
    }

    // ===== BACK TO TOP BUTTON =====
    var $backToTop = $('<button id="backToTop" title="Back to top" ' +
        'style="position:fixed;bottom:24px;right:24px;width:42px;height:42px;' +
        'background:var(--primary);color:#fff;border:none;border-radius:50%;' +
        'font-size:16px;cursor:pointer;display:none;z-index:8000;' +
        'box-shadow:0 4px 12px rgba(0,0,0,0.2);transition:all 0.2s;">' +
        '<i class="fas fa-arrow-up"></i></button>');
    $('body').append($backToTop);

    $(window).on('scroll', function () {
        if ($(this).scrollTop() > 400) {
            $backToTop.fadeIn(200);
        } else {
            $backToTop.fadeOut(200);
        }
    });

    $backToTop.on('click', function () {
        $('html,body').animate({ scrollTop: 0 }, 400);
    });

    // ===== NEWS CARD HOVER EFFECT =====
    $(document).on('mouseenter', '.news-card', function () {
        $(this).find('.news-card-title a').css('color', 'var(--primary)');
    }).on('mouseleave', '.news-card', function () {
        $(this).find('.news-card-title a').css('color', '');
    });

    // ===== AUTO HIDE FLASH MESSAGES =====
    setTimeout(function () {
        $('.alert').not('.alert-permanent').fadeOut(500, function () {
            $(this).remove();
        });
    }, 5000);

});