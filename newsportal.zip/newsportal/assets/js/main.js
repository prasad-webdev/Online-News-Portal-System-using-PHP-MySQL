// News Portal - Main JavaScript

$(document).ready(function() {

    // Auto-hide alerts
    setTimeout(function() {
        $('.alert').fadeOut(600);
    }, 4000);

    // Comment form AJAX submission
    $('#commentForm').on('submit', function(e) {
        e.preventDefault();
        var $form = $(this);
        var $btn = $form.find('button[type=submit]');
        $btn.prop('disabled', true).text('Submitting...');
        
        $.ajax({
            url: $form.attr('action'),
            type: 'POST',
            data: $form.serialize(),
            dataType: 'json',
            success: function(res) {
                if (res.success) {
                    showAlert('success', 'Your comment has been submitted and is awaiting moderation. Thank you!');
                    $form[0].reset();
                } else {
                    showAlert('danger', res.message || 'An error occurred. Please try again.');
                }
            },
            error: function() {
                showAlert('danger', 'Network error. Please try again.');
            },
            complete: function() {
                $btn.prop('disabled', false).text('Post Comment');
            }
        });
    });

    // Search suggestions (simple)
    var searchTimer;
    $('#headerSearch').on('input', function() {
        clearTimeout(searchTimer);
        var q = $(this).val().trim();
        if (q.length < 2) { $('#searchSuggestions').hide(); return; }
        searchTimer = setTimeout(function() {
            $.get('search-suggest.php', {q: q}, function(data) {
                if (data && data.length) {
                    var html = '';
                    $.each(data, function(i, item) {
                        html += '<a href="post.php?slug=' + item.slug + '">' + item.title + '</a>';
                    });
                    $('#searchSuggestions').html(html).show();
                } else {
                    $('#searchSuggestions').hide();
                }
            }, 'json');
        }, 300);
    });

    $(document).on('click', function(e) {
        if (!$(e.target).closest('.header-search').length) {
            $('#searchSuggestions').hide();
        }
    });

    function showAlert(type, message) {
        var $alert = $('<div class="alert alert-' + type + '">' + message + '</div>');
        $('#commentForm').before($alert);
        setTimeout(function() { $alert.fadeOut(function() { $(this).remove(); }); }, 5000);
    }

    // Lazy load images
    if ('IntersectionObserver' in window) {
        var lazyImages = document.querySelectorAll('img[data-src]');
        var observer = new IntersectionObserver(function(entries) {
            entries.forEach(function(entry) {
                if (entry.isIntersecting) {
                    var img = entry.target;
                    img.src = img.dataset.src;
                    img.removeAttribute('data-src');
                    observer.unobserve(img);
                }
            });
        });
        lazyImages.forEach(function(img) { observer.observe(img); });
    }

    // Mobile nav toggle
    $('#navToggle').on('click', function() {
        $('#mainNavList').toggleClass('open');
    });

    // Back to top
    $(window).on('scroll', function() {
        if ($(this).scrollTop() > 300) {
            $('#backToTop').fadeIn();
        } else {
            $('#backToTop').fadeOut();
        }
    });
    $('#backToTop').on('click', function() {
        $('html, body').animate({ scrollTop: 0 }, 600);
    });

    // Reading progress bar
    $(window).on('scroll', function() {
        if ($('#readingProgress').length) {
            var scrollTop = $(window).scrollTop();
            var docHeight = $(document).height() - $(window).height();
            var progress = (scrollTop / docHeight) * 100;
            $('#readingProgress').css('width', progress + '%');
        }
    });
});
