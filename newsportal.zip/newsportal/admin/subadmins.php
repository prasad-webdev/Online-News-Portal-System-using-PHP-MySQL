<?php
require_once 'includes/auth.php';
requireAdminRole(); // Only admin can access
$db = getDB();
$pageTitle = 'Manage Sub-Admins';

// Handle actions
if(isset($_GET['action']) && isset($_GET['id'])) {
    $id = intval($_GET['id']); $action = $_GET['action'];
    if($id === intval($_SESSION['admin_id'])) { setFlash('danger','Cannot modify own account here.'); redirect(ADMIN_URL.'/subadmins.php'); }
    if($action === 'delete') { $db->query("DELETE FROM admins WHERE id=$id AND role='subadmin'"); setFlash('success','Sub-admin deleted.'); }
    elseif($action === 'toggle') { $admin = $db->query("SELECT status FROM admins WHERE id=$id")->fetch_assoc(); $new = $admin['status'] ? 0 : 1; $db->query("UPDATE admins SET status=$new WHERE id=$id"); setFlash('success','Status updated.'); }
    redirect(ADMIN_URL.'/subadmins.php');
}

$errors = [];
if($_SERVER['REQUEST_METHOD']==='POST') {
    $action = $_POST['action']??'';
    $name = sanitize($_POST['name']??'');
    $email = sanitize($_POST['email']??'');
    $password = $_POST['password']??'';
    
    if($action === 'add') {
        if(!$name||!$email||!$password) $errors[] = 'All fields required.';
        elseif(!filter_var(htmlspecialchars_decode($email), FILTER_VALIDATE_EMAIL)) $errors[] = 'Invalid email.';
        elseif(strlen($password)<6) $errors[] = 'Password must be at least 6 characters.';
        else {
            if($db->query("SELECT id FROM admins WHERE email='$email'")->num_rows) $errors[] = 'Email already exists.';
            else {
                $hash = password_hash($password, PASSWORD_DEFAULT);
                $db->query("INSERT INTO admins (name, email, password, role) VALUES ('$name', '$email', '$hash', 'subadmin')");
                setFlash('success','Sub-admin added!');
                redirect(ADMIN_URL.'/subadmins.php');
            }
        }
    } elseif($action === 'edit') {
        $id = intval($_POST['id']??0);
        if(!$id||!$name||!$email) $errors[] = 'Required fields missing.';
        else {
            $db->query("UPDATE admins SET name='$name', email='$email' WHERE id=$id AND role='subadmin'");
            if(!empty($password) && strlen($password)>=6) {
                $hash = password_hash($password, PASSWORD_DEFAULT);
                $db->query("UPDATE admins SET password='$hash' WHERE id=$id");
            }
            setFlash('success','Sub-admin updated!');
            redirect(ADMIN_URL.'/subadmins.php');
        }
    }
}

$subadmins = $db->query("SELECT * FROM admins WHERE role='subadmin' ORDER BY created_at DESC")->fetch_all(MYSQLI_ASSOC);

include 'includes/header.php';
?>

<?php if(!empty($errors)): ?><div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo implode('<br>',$errors); ?></div><?php endif; ?>

<div style="display:grid;grid-template-columns:1fr 2fr;gap:24px;">
    <div>
        <div class="card">
            <div class="card-header"><div class="card-title"><i class="fas fa-user-plus"></i> Add Sub-Admin</div></div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="action" value="add">
                    <div class="form-group"><label class="form-label">Full Name *</label><input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($_POST['name']??''); ?>" required></div>
                    <div class="form-group"><label class="form-label">Email *</label><input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($_POST['email']??''); ?>" required></div>
                    <div class="form-group"><label class="form-label">Password *</label><input type="password" name="password" class="form-control" placeholder="Min 6 characters" required></div>
                    <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;"><i class="fas fa-save"></i> Add Sub-Admin</button>
                </form>
            </div>
        </div>
    </div>
    
    <div>
        <div class="card">
            <div class="card-header"><div class="card-title">Sub-Admins (<?php echo count($subadmins); ?>)</div></div>
            <table class="table">
                <thead><tr><th>#</th><th>Name</th><th>Email</th><th>Status</th><th>Created</th><th>Actions</th></tr></thead>
                <tbody>
                    <?php if(empty($subadmins)): ?><tr><td colspan="6" style="text-align:center;padding:30px;color:var(--text-muted);">No sub-admins found.</td></tr>
                    <?php else: ?>
                    <?php foreach($subadmins as $i=>$sa): ?>
                    <tr>
                        <td><?php echo $i+1; ?></td>
                        <td>
                            <div style="display:flex;align-items:center;gap:10px;">
                                <div style="width:34px;height:34px;background:var(--secondary);color:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700;"><?php echo strtoupper(substr($sa['name'],0,1)); ?></div>
                                <strong><?php echo htmlspecialchars($sa['name']); ?></strong>
                            </div>
                        </td>
                        <td style="font-size:13px;"><?php echo htmlspecialchars($sa['email']); ?></td>
                        <td><span class="badge badge-<?php echo $sa['status']?'success':'danger'; ?>"><?php echo $sa['status']?'Active':'Inactive'; ?></span></td>
                        <td style="font-size:12px;color:var(--text-muted);"><?php echo date('M j, Y', strtotime($sa['created_at'])); ?></td>
                        <td>
                            <button onclick="editAdmin(<?php echo $sa['id']; ?>, '<?php echo addslashes($sa['name']); ?>', '<?php echo addslashes($sa['email']); ?>')" class="btn btn-warning btn-xs"><i class="fas fa-edit"></i></button>
                            <a href="subadmins.php?action=toggle&id=<?php echo $sa['id']; ?>" class="btn btn-<?php echo $sa['status']?'secondary':'success'; ?> btn-xs" title="<?php echo $sa['status']?'Deactivate':'Activate'; ?>"><i class="fas fa-<?php echo $sa['status']?'user-slash':'user-check'; ?>"></i></a>
                            <a href="subadmins.php?action=delete&id=<?php echo $sa['id']; ?>" class="btn btn-danger btn-xs confirm-delete"><i class="fas fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div id="editModal" style="display:none;position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.5);z-index:9999;align-items:center;justify-content:center;">
    <div style="background:#fff;border-radius:8px;padding:28px;width:400px;box-shadow:0 10px 40px rgba(0,0,0,0.3);">
        <h3 style="margin-bottom:20px;">Edit Sub-Admin</h3>
        <form method="POST">
            <input type="hidden" name="action" value="edit">
            <input type="hidden" name="id" id="editId">
            <div class="form-group"><label class="form-label">Full Name *</label><input type="text" name="name" id="editName" class="form-control" required></div>
            <div class="form-group"><label class="form-label">Email *</label><input type="email" name="email" id="editEmail" class="form-control" required></div>
            <div class="form-group"><label class="form-label">New Password</label><input type="password" name="password" class="form-control" placeholder="Leave blank to keep current"></div>
            <div style="display:flex;gap:10px;">
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Update</button>
                <button type="button" onclick="document.getElementById('editModal').style.display='none'" class="btn btn-secondary">Cancel</button>
            </div>
        </form>
    </div>
</div>
<script>
function editAdmin(id, name, email) {
    document.getElementById('editId').value = id;
    document.getElementById('editName').value = name;
    document.getElementById('editEmail').value = email;
    document.getElementById('editModal').style.display = 'flex';
}
</script>
<?php include 'includes/footer.php'; ?>
