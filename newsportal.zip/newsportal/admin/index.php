<?php
require_once '../includes/config.php';
if(isAdminLoggedIn()) {
    redirect(ADMIN_URL . '/dashboard.php');
} else {
    redirect(ADMIN_URL . '/login.php');
}
