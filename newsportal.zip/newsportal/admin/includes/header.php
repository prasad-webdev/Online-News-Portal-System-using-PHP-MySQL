<?php
$currentAdmin = getCurrentAdmin();
$db = getDB();

// Pending comments count for badge
$pendingComments = $db->query("SELECT COUNT(*) FROM comments WHERE status='pending'")->fetch_row()[0];
$currentPage = basename($_SERVER['PHP_SELF'], '.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? htmlspecialchars($pageTitle) . ' | Admin' : 'News Portal Admin'; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo ADMIN_URL; ?>/assets/admin.css">
    <?php if(isset($extraCSS)) echo $extraCSS; ?>
</head>
<body>
<div class="admin-wrapper">
    <!-- Sidebar -->

    <aside class="sidebar" id="sidebar">
        <div class="sidebar-logo">
            <i class="fas fa-newspaper"></i>
            <div>
                <div>NewsPortal</div>
                <span><?php echo isAdmin() ? 'Admin Panel' : 'Sub-Admin Panel'; ?></span>
            </div>
        </div>
        
        <nav class="sidebar-nav">
            
            <div class="nav-section">Dashboard</div>
            <a href="<?php echo ADMIN_URL; ?>/dashboard.php" class="nav-link <?php echo $currentPage=='dashboard'?'active':''; ?>">
                <i class="fas fa-tachometer-alt"></i> Dashboard
            </a>
            <a href="<?php echo ADMIN_URL; ?>/notifications.php" class="nav-link <?php echo $currentPage=='notifications'?'active':''; ?>">
    <i class="fas fa-bell"></i> Notifications
</a>
            <div class="nav-section">Content</div>
            <a href="<?php echo ADMIN_URL; ?>/posts.php" class="nav-link <?php echo in_array($currentPage,['posts','post-add','post-edit'])?'active':''; ?>">
                <i class="fas fa-newspaper"></i> Posts
            </a>
            <a href="<?php echo ADMIN_URL; ?>/categories.php" class="nav-link <?php echo $currentPage=='categories'?'active':''; ?>">
                <i class="fas fa-folder"></i> Categories
            </a>
            <a href="<?php echo ADMIN_URL; ?>/subcategories.php" class="nav-link <?php echo $currentPage=='subcategories'?'active':''; ?>">
                <i class="fas fa-folder-open"></i> Sub-Categories
            </a>
            
            <div class="nav-section">Moderation</div>
            <a href="<?php echo ADMIN_URL; ?>/comments.php" class="nav-link <?php echo $currentPage=='comments'?'active':''; ?>">
                <i class="fas fa-comments"></i> Comments
                <?php if($pendingComments > 0): ?>
                <span class="nav-badge"><?php echo $pendingComments; ?></span>
                <?php endif; ?>
            </a>
            
            <div class="nav-section">Pages</div>
            <a href="<?php echo ADMIN_URL; ?>/pages.php" class="nav-link <?php echo $currentPage=='pages'?'active':''; ?>">
                <i class="fas fa-file-alt"></i> Manage Pages
            </a>
            
            <?php if(isAdmin()): ?>
            <div class="nav-section">Administration</div>
            <a href="<?php echo ADMIN_URL; ?>/subadmins.php" class="nav-link <?php echo $currentPage=='subadmins'?'active':''; ?>">
                <i class="fas fa-users-cog"></i> Sub-Admins
            </a>
            <!-- Add under MODERATION section -->
<a href="<?php echo ADMIN_URL; ?>/users.php"
   class="nav-link <?php echo $currentPage=='users'?'active':''; ?>">
    <i class="fas fa-users"></i> Manage Users
</a>

<!-- Add under PAGES section -->
<a href="<?php echo ADMIN_URL; ?>/newsletter.php"
   class="nav-link <?php echo $currentPage=='newsletter'?'active':''; ?>">
    <i class="fas fa-envelope-open-text"></i> Newsletter
</a>
            <?php endif; ?>
            
            <div class="nav-section">Account</div>
            <a href="<?php echo ADMIN_URL; ?>/profile.php" class="nav-link <?php echo $currentPage=='profile'?'active':''; ?>">
                <i class="fas fa-user-circle"></i> My Profile
            </a>
            <a href="<?php echo SITE_URL; ?>" class="nav-link" target="_blank">
                <i class="fas fa-external-link-alt"></i> View Website
            </a>
            <a href="<?php echo ADMIN_URL; ?>/logout.php" class="nav-link" style="color:#e74c3c;">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </nav>
    </aside>
    
    <!-- Main -->
    <div class="main-content">
        <!-- Topbar -->
        <div class="topbar">
            <div style="display:flex;align-items:center;gap:14px;">
                <button id="sidebarToggle" style="background:none;border:none;font-size:20px;cursor:pointer;color:var(--secondary);padding:4px;">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="topbar-title"><?php echo isset($pageTitle) ? htmlspecialchars($pageTitle) : 'Dashboard'; ?></div>
            </div>
            <div class="topbar-user">
                <div class="user-avatar"><?php echo strtoupper(substr($currentAdmin['name'],0,1)); ?></div>
                <div>
                    <div style="font-weight:600;"><?php echo htmlspecialchars($currentAdmin['name']); ?></div>
                    <div style="font-size:11px;color:var(--text-muted);text-transform:capitalize;"><?php echo $currentAdmin['role']; ?></div>
                </div>
                <a href="logout.php"><i class="fas fa-sign-out-alt"></i></a>
            </div>
        </div>
        
        <div class="page-content">
        <?php $flash = getFlash(); if($flash): ?>
        <div class="alert alert-<?php echo $flash['type']; ?>">
            <i class="fas fa-info-circle"></i> <?php echo htmlspecialchars($flash['message']); ?>
        </div>
        <?php endif; ?>
