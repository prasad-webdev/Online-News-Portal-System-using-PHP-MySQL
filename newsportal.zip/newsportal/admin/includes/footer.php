        </div><!-- end page-content -->
    </div><!-- end main-content -->
</div><!-- end admin-wrapper -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
$(document).ready(function() {
    // Sidebar toggle
    $('#sidebarToggle').on('click', function() {
        $('#sidebar').toggleClass('open');
    });
    
    // Auto-hide alerts
    setTimeout(function() { $('.alert').fadeOut(600); }, 4000);
    
    // Confirm delete
    $(document).on('click', '.confirm-delete', function(e) {
        if (!confirm('Are you sure you want to delete this? This action cannot be undone.')) {
            e.preventDefault();
        }
    });
    
    // Confirm restore
    $(document).on('click', '.confirm-restore', function(e) {
        if (!confirm('Restore this item?')) {
            e.preventDefault();
        }
    });
    
    // Image preview
    $('#imageInput').on('change', function() {
        var file = this.files[0];
        if (file) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#imagePreview').attr('src', e.target.result).show();
            };
            reader.readAsDataURL(file);
        }
    });
    
    // Select all checkboxes
    $('#selectAll').on('change', function() {
        $('input[name="ids[]"]').prop('checked', $(this).prop('checked'));
    });
});
</script>
<?php if(isset($extraJS)) echo $extraJS; ?>
</body>
</html>
