<?php
require_once __DIR__ . '/../../includes/config.php';

function requireAdminLogin() {
    if (!isAdminLoggedIn()) {
        redirect(ADMIN_URL . '/login.php');
    }
}

function requireAdminRole() {
    requireAdminLogin();
    if (!isAdmin()) {
        setFlash('danger', 'Access denied. Admin privileges required.');
        redirect(ADMIN_URL . '/dashboard.php');
    }
}

function getCurrentAdmin() {
    if (!isAdminLoggedIn()) return null;
    $db = getDB();
    $id = intval($_SESSION['admin_id']);
    return $db->query("SELECT * FROM admins WHERE id=$id")->fetch_assoc();
}
