<?php
require_once 'includes/auth.php';
requireAdminLogin();
$db = getDB();
$pageTitle = 'Manage Notifications';

if(isset($_GET['action']) && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    if($_GET['action']==='delete') $db->query("DELETE FROM notifications WHERE id=$id");
    elseif($_GET['action']==='toggle') { $n=$db->query("SELECT is_active FROM notifications WHERE id=$id")->fetch_assoc(); $db->query("UPDATE notifications SET is_active=".($n['is_active']?0:1)." WHERE id=$id"); }
    redirect(ADMIN_URL.'/notifications.php');
}

if($_SERVER['REQUEST_METHOD']==='POST') {
    $title   = sanitize($_POST['title']   ?? '');
    $message = sanitize($_POST['message'] ?? '');
    $type    = sanitize($_POST['type']    ?? 'info');
    $link    = sanitize($_POST['link']    ?? '');
    if($title && $message) {
        $db->query("INSERT INTO notifications (title, message, type, link) VALUES ('$title','$message','$type','$link')");
        setFlash('success','Notification created!');
        redirect(ADMIN_URL.'/notifications.php');
    }
}

$notifications = $db->query("SELECT * FROM notifications ORDER BY created_at DESC")->fetch_all(MYSQLI_ASSOC);
include 'includes/header.php';
?>

<div style="display:grid;grid-template-columns:1fr 2fr;gap:24px;">
    <div>
        <div class="card">
            <div class="card-header"><div class="card-title"><i class="fas fa-plus-circle"></i> New Notification</div></div>
            <div class="card-body">
                <form method="POST">
                    <div class="form-group">
                        <label class="form-label">Title *</label>
                        <input type="text" name="title" class="form-control" placeholder="Notification title" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Message *</label>
                        <textarea name="message" class="form-control" rows="3" placeholder="Notification message" required></textarea>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Type</label>
                        <select name="type" class="form-control">
                            <option value="info">Info</option>
                            <option value="breaking">Breaking</option>
                            <option value="success">Success</option>
                            <option value="warning">Warning</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Link (optional)</label>
                        <input type="text" name="link" class="form-control" placeholder="https://...">
                    </div>
                    <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;"><i class="fas fa-save"></i> Create</button>
                </form>
            </div>
        </div>
    </div>
    <div>
        <div class="card">
            <div class="card-header"><div class="card-title">All Notifications</div></div>
            <table class="table">
                <thead><tr><th>Title</th><th>Type</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead>
                <tbody>
                    <?php foreach($notifications as $n): ?>
                    <tr>
                        <td>
                            <strong style="font-size:13px;"><?php echo htmlspecialchars($n['title']); ?></strong>
                            <div style="font-size:12px;color:var(--text-muted);"><?php echo htmlspecialchars(mb_substr($n['message'],0,60)); ?></div>
                        </td>
                        <td><span class="badge badge-info"><?php echo ucfirst($n['type']); ?></span></td>
                        <td><span class="badge badge-<?php echo $n['is_active']?'success':'secondary'; ?>"><?php echo $n['is_active']?'Active':'Inactive'; ?></span></td>
                        <td style="font-size:12px;color:var(--text-muted);"><?php echo date('M j, Y', strtotime($n['created_at'])); ?></td>
                        <td>
                            <a href="notifications.php?action=toggle&id=<?php echo $n['id']; ?>" class="btn btn-warning btn-xs"><i class="fas fa-toggle-on"></i></a>
                            <a href="notifications.php?action=delete&id=<?php echo $n['id']; ?>" class="btn btn-danger btn-xs confirm-delete"><i class="fas fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>