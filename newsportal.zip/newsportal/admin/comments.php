<?php
require_once 'includes/auth.php';
requireAdminLogin();
$db = getDB();
$pageTitle = 'Manage Comments';

// Handle actions
if(isset($_GET['action']) && isset($_GET['id'])) {
    $id = intval($_GET['id']); $action = $_GET['action'];
    if($action === 'approve') $db->query("UPDATE comments SET status='approved' WHERE id=$id");
    elseif($action === 'reject') $db->query("UPDATE comments SET status='rejected' WHERE id=$id");
    elseif($action === 'delete') $db->query("DELETE FROM comments WHERE id=$id");
    elseif($action === 'pending') $db->query("UPDATE comments SET status='pending' WHERE id=$id");
    setFlash('success','Comment updated.');
    redirect(ADMIN_URL.'/comments.php?status='.($_GET['filter']??''));
}

// Bulk action
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['bulk_action']) && !empty($_POST['ids'])) {
    $ids = array_map('intval', $_POST['ids']);
    $idsStr = implode(',', $ids);
    if($_POST['bulk_action'] === 'approve') $db->query("UPDATE comments SET status='approved' WHERE id IN ($idsStr)");
    elseif($_POST['bulk_action'] === 'reject') $db->query("UPDATE comments SET status='rejected' WHERE id IN ($idsStr)");
    elseif($_POST['bulk_action'] === 'delete') $db->query("DELETE FROM comments WHERE id IN ($idsStr)");
    setFlash('success','Bulk action performed.');
    redirect(ADMIN_URL.'/comments.php');
}

$filter = isset($_GET['status']) ? sanitize($_GET['status']) : '';
$page = max(1, intval($_GET['page']??1));
$perPage = 20; $offset = ($page-1)*$perPage;

$where = $filter ? "WHERE cm.status='$filter'" : '';
$total = $db->query("SELECT COUNT(*) FROM comments cm $where")->fetch_row()[0];
$totalPages = ceil($total/$perPage);
$comments = $db->query("SELECT cm.*, p.title as post_title, p.slug as post_slug FROM comments cm LEFT JOIN posts p ON p.id=cm.post_id $where ORDER BY cm.created_at DESC LIMIT $perPage OFFSET $offset")->fetch_all(MYSQLI_ASSOC);

$allCount = $db->query("SELECT COUNT(*) FROM comments")->fetch_row()[0];
$pendingCount = $db->query("SELECT COUNT(*) FROM comments WHERE status='pending'")->fetch_row()[0];
$approvedCount = $db->query("SELECT COUNT(*) FROM comments WHERE status='approved'")->fetch_row()[0];
$rejectedCount = $db->query("SELECT COUNT(*) FROM comments WHERE status='rejected'")->fetch_row()[0];

include 'includes/header.php';
?>

<div class="card">
    <div class="card-header"><div class="card-title"><i class="fas fa-comments"></i> Comments</div></div>
    <div class="card-body">
        <div style="display:flex;gap:8px;margin-bottom:16px;flex-wrap:wrap;">
            <a href="comments.php" class="btn btn-sm <?php echo !$filter?'btn-primary':'btn-secondary'; ?>">All (<?php echo $allCount; ?>)</a>
            <a href="comments.php?status=pending" class="btn btn-sm <?php echo $filter==='pending'?'btn-primary':'btn-warning'; ?>">Pending (<?php echo $pendingCount; ?>)</a>
            <a href="comments.php?status=approved" class="btn btn-sm <?php echo $filter==='approved'?'btn-primary':'btn-success'; ?>">Approved (<?php echo $approvedCount; ?>)</a>
            <a href="comments.php?status=rejected" class="btn btn-sm <?php echo $filter==='rejected'?'btn-primary':'btn-danger'; ?>">Rejected (<?php echo $rejectedCount; ?>)</a>
        </div>
    </div>
    
    <form method="POST">
        <div class="card-body" style="border-top:1px solid var(--border);padding:12px 20px;">
            <div style="display:flex;align-items:center;gap:10px;">
                <select name="bulk_action" class="form-control" style="width:180px;">
                    <option value="">Bulk Actions</option>
                    <option value="approve">Approve Selected</option>
                    <option value="reject">Reject Selected</option>
                    <option value="delete">Delete Selected</option>
                </select>
                <button type="submit" class="btn btn-secondary btn-sm">Apply</button>
            </div>
        </div>
        
        <table class="table">
            <thead><tr><th style="width:30px;"><input type="checkbox" id="selectAll"></th><th>Comment</th><th>Post</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead>
            <tbody>
                <?php if(empty($comments)): ?>
                <tr><td colspan="6" style="text-align:center;padding:30px;color:var(--text-muted);"><i class="fas fa-comments" style="font-size:32px;margin-bottom:8px;display:block;"></i>No comments found.</td></tr>
                <?php else: ?>
                <?php foreach($comments as $c): ?>
                <tr>
                    <td><input type="checkbox" name="ids[]" value="<?php echo $c['id']; ?>"></td>
                    <td>
                        <div style="display:flex;align-items:flex-start;gap:10px;">
                            <div style="width:36px;height:36px;background:var(--primary);color:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700;flex-shrink:0;"><?php echo strtoupper(substr($c['name'],0,1)); ?></div>
                            <div>
                                <div style="font-weight:600;font-size:13px;"><?php echo htmlspecialchars($c['name']); ?> <span style="font-size:11px;font-weight:400;color:var(--text-muted);">&lt;<?php echo htmlspecialchars($c['email']); ?>&gt;</span></div>
                                <div style="font-size:13px;color:#555;margin-top:3px;"><?php echo htmlspecialchars(mb_substr($c['comment'],0,150)); ?></div>
                            </div>
                        </div>
                    </td>
                    <td style="max-width:180px;">
                        <a href="<?php echo SITE_URL.'/post.php?slug='.$c['post_slug']; ?>" target="_blank" style="font-size:12px;color:var(--primary);"><?php echo htmlspecialchars(mb_substr($c['post_title']??'',0,45)); ?></a>
                    </td>
                    <td><span class="badge badge-<?php echo $c['status']==='approved'?'success':($c['status']==='pending'?'warning':'danger'); ?>"><?php echo ucfirst($c['status']); ?></span></td>
                    <td style="font-size:12px;color:var(--text-muted);"><?php echo date('M j, Y', strtotime($c['created_at'])); ?><br><?php echo date('g:i A', strtotime($c['created_at'])); ?></td>
                    <td>
                        <?php if($c['status']!=='approved'): ?><a href="comments.php?action=approve&id=<?php echo $c['id']; ?>&filter=<?php echo $filter; ?>" class="btn btn-success btn-xs" title="Approve"><i class="fas fa-check"></i></a><?php endif; ?>
                        <?php if($c['status']!=='rejected'): ?><a href="comments.php?action=reject&id=<?php echo $c['id']; ?>&filter=<?php echo $filter; ?>" class="btn btn-warning btn-xs" title="Reject"><i class="fas fa-ban"></i></a><?php endif; ?>
                        <?php if($c['status']!=='pending'): ?><a href="comments.php?action=pending&id=<?php echo $c['id']; ?>&filter=<?php echo $filter; ?>" class="btn btn-info btn-xs" title="Set Pending"><i class="fas fa-clock"></i></a><?php endif; ?>
                        <a href="comments.php?action=delete&id=<?php echo $c['id']; ?>&filter=<?php echo $filter; ?>" class="btn btn-danger btn-xs confirm-delete" title="Delete"><i class="fas fa-trash"></i></a>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </form>
    
    <?php if($totalPages>1): ?>
    <div class="card-body" style="border-top:1px solid var(--border);">
        <div class="pagination">
            <?php for($i=1;$i<=$totalPages;$i++): ?><a href="?status=<?php echo $filter; ?>&page=<?php echo $i; ?>" class="page-link <?php echo $i==$page?'active':''; ?>"><?php echo $i; ?></a><?php endfor; ?>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
