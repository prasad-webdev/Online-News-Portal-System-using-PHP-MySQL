<?php
require_once 'includes/auth.php';
requireAdminLogin();

$db = getDB();
$pageTitle = 'Dashboard';

// Stats
$totalPosts = $db->query("SELECT COUNT(*) FROM posts WHERE deleted=0")->fetch_row()[0];
$publishedPosts = $db->query("SELECT COUNT(*) FROM posts WHERE status='published' AND deleted=0")->fetch_row()[0];
$draftPosts = $db->query("SELECT COUNT(*) FROM posts WHERE status='draft' AND deleted=0")->fetch_row()[0];
$trashedPosts = $db->query("SELECT COUNT(*) FROM posts WHERE deleted=1")->fetch_row()[0];
$totalCategories = $db->query("SELECT COUNT(*) FROM categories WHERE deleted=0")->fetch_row()[0];
$totalSubcats = $db->query("SELECT COUNT(*) FROM subcategories WHERE deleted=0")->fetch_row()[0];
$totalComments = $db->query("SELECT COUNT(*) FROM comments")->fetch_row()[0];
$pendingComments = $db->query("SELECT COUNT(*) FROM comments WHERE status='pending'")->fetch_row()[0];
$totalViews = $db->query("SELECT SUM(views) FROM posts WHERE deleted=0")->fetch_row()[0] ?? 0;
$totalAdmins = $db->query("SELECT COUNT(*) FROM admins")->fetch_row()[0];

// Recent posts
$recentPosts = $db->query("SELECT p.*, c.name as cat_name, a.name as author FROM posts p LEFT JOIN categories c ON c.id=p.category_id LEFT JOIN admins a ON a.id=p.admin_id WHERE p.deleted=0 ORDER BY p.created_at DESC LIMIT 8")->fetch_all(MYSQLI_ASSOC);

// Recent comments
$recentComments = $db->query("SELECT cm.*, p.title as post_title, p.slug as post_slug FROM comments cm LEFT JOIN posts p ON p.id=cm.post_id ORDER BY cm.created_at DESC LIMIT 5")->fetch_all(MYSQLI_ASSOC);

include 'includes/header.php';
?>

<div class="stats-grid">
    <div class="stat-card primary">
        <div class="stat-icon"><i class="fas fa-newspaper"></i></div>
        <div>
            <div class="stat-number"><?php echo $publishedPosts; ?></div>
            <div class="stat-label">Published Posts</div>
        </div>
    </div>
    <div class="stat-card warning">
        <div class="stat-icon"><i class="fas fa-edit"></i></div>
        <div>
            <div class="stat-number"><?php echo $draftPosts; ?></div>
            <div class="stat-label">Draft Posts</div>
        </div>
    </div>
    <div class="stat-card success">
        <div class="stat-icon"><i class="fas fa-folder"></i></div>
        <div>
            <div class="stat-number"><?php echo $totalCategories; ?></div>
            <div class="stat-label">Categories</div>
        </div>
    </div>
    <div class="stat-card info">
        <div class="stat-icon"><i class="fas fa-comments"></i></div>
        <div>
            <div class="stat-number"><?php echo $pendingComments; ?></div>
            <div class="stat-label">Pending Comments</div>
        </div>
    </div>
    <div class="stat-card primary">
        <div class="stat-icon"><i class="fas fa-eye"></i></div>
        <div>
            <div class="stat-number"><?php echo number_format($totalViews); ?></div>
            <div class="stat-label">Total Views</div>
        </div>
    </div>
    <div class="stat-card danger">
        <div class="stat-icon" style="background:#e74c3c;"><i class="fas fa-trash"></i></div>
        <div>
            <div class="stat-number"><?php echo $trashedPosts; ?></div>
            <div class="stat-label">Trashed Posts</div>
        </div>
    </div>
    <div class="stat-card success">
        <div class="stat-icon"><i class="fas fa-tags"></i></div>
        <div>
            <div class="stat-number"><?php echo $totalSubcats; ?></div>
            <div class="stat-label">Sub-Categories</div>
        </div>
    </div>
    <div class="stat-card info">
        <div class="stat-icon"><i class="fas fa-users"></i></div>
        <div>
            <div class="stat-number"><?php echo $totalAdmins; ?></div>
            <div class="stat-label">Admin Users</div>
        </div>
    </div>
</div>

<!-- Quick Actions -->
<div class="card" style="margin-bottom:24px;">
    <div class="card-header"><div class="card-title"><i class="fas fa-bolt"></i> Quick Actions</div></div>
    <div class="card-body" style="display:flex;gap:12px;flex-wrap:wrap;">
        <a href="post-add.php" class="btn btn-primary"><i class="fas fa-plus"></i> New Post</a>
        <a href="categories.php" class="btn btn-success"><i class="fas fa-folder-plus"></i> Manage Categories</a>
        <a href="comments.php?status=pending" class="btn btn-warning"><i class="fas fa-comments"></i> Pending Comments <?php if($pendingComments>0): ?><span style="background:rgba(0,0,0,0.2);border-radius:10px;padding:1px 7px;font-size:11px;"><?php echo $pendingComments; ?></span><?php endif; ?></a>
        <a href="posts.php?status=trash" class="btn btn-secondary"><i class="fas fa-trash"></i> Trash (<?php echo $trashedPosts; ?>)</a>
        <a href="<?php echo SITE_URL; ?>" target="_blank" class="btn btn-info"><i class="fas fa-external-link-alt"></i> View Website</a>
    </div>
</div>

<div style="display:grid;grid-template-columns:2fr 1fr;gap:24px;flex-wrap:wrap;">
    <!-- Recent Posts -->
    <div class="card">
        <div class="card-header">
            <div class="card-title"><i class="fas fa-newspaper"></i> Recent Posts</div>
            <a href="posts.php" class="btn btn-primary btn-sm">View All</a>
        </div>
        <table class="table">
            <thead><tr><th>Title</th><th>Category</th><th>Status</th><th>Date</th><th>Action</th></tr></thead>
            <tbody>
                <?php foreach($recentPosts as $p): ?>
                <tr>
                    <td style="max-width:200px;">
                        <a href="post-edit.php?id=<?php echo $p['id']; ?>" style="color:var(--secondary);font-weight:600;font-size:13px;"><?php echo htmlspecialchars(mb_substr($p['title'],0,50).'...'); ?></a>
                    </td>
                    <td><span class="badge badge-info"><?php echo htmlspecialchars($p['cat_name']); ?></span></td>
                    <td><span class="badge badge-<?php echo $p['status']=='published'?'success':'warning'; ?>"><?php echo ucfirst($p['status']); ?></span></td>
                    <td style="font-size:12px;color:var(--text-muted);"><?php echo date('M j, Y', strtotime($p['created_at'])); ?></td>
                    <td>
                        <a href="post-edit.php?id=<?php echo $p['id']; ?>" class="btn btn-warning btn-xs"><i class="fas fa-edit"></i></a>
                        <a href="<?php echo SITE_URL; ?>/post.php?slug=<?php echo $p['slug']; ?>" target="_blank" class="btn btn-info btn-xs"><i class="fas fa-eye"></i></a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Recent Comments -->
    <div class="card">
        <div class="card-header">
            <div class="card-title"><i class="fas fa-comments"></i> Recent Comments</div>
            <a href="comments.php" class="btn btn-primary btn-sm">View All</a>
        </div>
        <div class="card-body" style="padding:0;">
            <?php foreach($recentComments as $c): ?>
            <div style="padding:14px 16px;border-bottom:1px solid var(--border);">
                <div style="display:flex;justify-content:space-between;margin-bottom:4px;">
                    <strong style="font-size:13px;"><?php echo htmlspecialchars($c['name']); ?></strong>
                    <span class="badge badge-<?php echo $c['status']=='approved'?'success':($c['status']=='pending'?'warning':'danger'); ?>"><?php echo ucfirst($c['status']); ?></span>
                </div>
                <div style="font-size:12px;color:var(--text-muted);margin-bottom:4px;"><?php echo htmlspecialchars(mb_substr($c['comment'],0,60).'...'); ?></div>
                <div style="font-size:11px;color:#aaa;">on: <a href="<?php echo SITE_URL; ?>/post.php?slug=<?php echo $c['post_slug']; ?>" style="color:var(--primary);"><?php echo htmlspecialchars(mb_substr($c['post_title']??'',0,40)); ?></a></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
