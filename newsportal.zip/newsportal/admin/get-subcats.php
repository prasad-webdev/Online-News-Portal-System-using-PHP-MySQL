<?php
require_once '../includes/config.php';
header('Content-Type: application/json');
$catId = intval($_GET['cat_id'] ?? 0);
if(!$catId) { echo '[]'; exit; }
$db = getDB();
$result = $db->query("SELECT id, name FROM subcategories WHERE category_id=$catId AND deleted=0 AND status=1 ORDER BY name ASC")->fetch_all(MYSQLI_ASSOC);
echo json_encode($result);
