<?php
require_once 'includes/auth.php';
requireAdminLogin();
$db = getDB();

$id = intval($_GET['id'] ?? 0);
if(!$id) redirect(ADMIN_URL.'/posts.php');

$post = $db->query("SELECT * FROM posts WHERE id=$id AND deleted=0")->fetch_assoc();
if(!$post) { setFlash('danger','Post not found.'); redirect(ADMIN_URL.'/posts.php'); }

$pageTitle = 'Edit Post';
$categories = getCategories();

// Get subcategories for current category
$subcats = $db->query("SELECT * FROM subcategories WHERE category_id={$post['category_id']} AND deleted=0 AND status=1")->fetch_all(MYSQLI_ASSOC);

$errors = [];
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = sanitize($_POST['title'] ?? '');
    $catId = intval($_POST['category_id'] ?? 0);
    $subcatId = intval($_POST['subcategory_id'] ?? 0) ?: null;
    $content = $_POST['content'] ?? '';
    $tags = sanitize($_POST['tags'] ?? '');
    $status = in_array($_POST['status'] ?? '', ['published','draft']) ? $_POST['status'] : 'draft';
    
    if(!$title) $errors[] = 'Title is required.';
    if(!$catId) $errors[] = 'Category is required.';
    if(!$content) $errors[] = 'Content is required.';
    
    $image = $post['image'];
    if(!empty($_FILES['image']['name'])) {
        $upload = uploadImage($_FILES['image'], $post['image']);
        if(isset($upload['error'])) $errors[] = $upload['error'];
        else $image = $upload['success'];
    }
    if(isset($_POST['remove_image']) && $image) {
        if(file_exists(UPLOAD_PATH.$image)) unlink(UPLOAD_PATH.$image);
        $image = null;
    }
    
    if(empty($errors)) {
        // Update slug only if title changed
        $slug = $post['slug'];
        if($title !== $post['title']) {
            $newSlug = createSlug($title);
            $origSlug = $newSlug; $i = 1;
            while($db->query("SELECT id FROM posts WHERE slug='$newSlug' AND id!=$id")->num_rows > 0) {
                $newSlug = $origSlug . '-' . $i++;
            }
            $slug = $newSlug;
        }
        $content = $db->real_escape_string($content);
        $subcatSql = $subcatId ? $subcatId : 'NULL';
        $imageSql = $image ? "'$image'" : 'NULL';
        $db->query("UPDATE posts SET title='$title', slug='$slug', category_id=$catId, subcategory_id=$subcatSql, content='$content', image=$imageSql, tags='$tags', status='$status' WHERE id=$id");
        setFlash('success', 'Post updated successfully!');
        redirect(ADMIN_URL.'/posts.php');
    }
    // Update post var with form data for re-display
    $post = array_merge($post, ['title'=>$_POST['title']??'','category_id'=>$catId,'content'=>$_POST['content']??'','tags'=>$_POST['tags']??'','status'=>$status]);
    $subcats = $db->query("SELECT * FROM subcategories WHERE category_id=$catId AND deleted=0 AND status=1")->fetch_all(MYSQLI_ASSOC);
}

$extraCSS = '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.18/summernote-lite.min.css">';
$extraJS = '<script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.18/summernote-lite.min.js"></script>
<script>
$(document).ready(function() {
    $("#content").summernote({ height: 350, toolbar: [["style",["style"]],["font",["bold","underline","italic","clear"]],["color",["color"]],["para",["ul","ol","paragraph"]],["table",["table"]],["insert",["link","picture"]],["view",["fullscreen","codeview"]]] });
    $("#category_id").on("change", function() {
        var catId = $(this).val();
        if(!catId) { $("#subcategory_id").html(\'<option value="">-- No Subcategory --</option>\'); return; }
        $.get("get-subcats.php", {cat_id: catId}, function(data) {
            var html = \'<option value="">-- No Subcategory --</option>\';
            $.each(data, function(i, s) { html += \'<option value="\' + s.id + \'">\' + s.name + \'</option>\'; });
            $("#subcategory_id").html(html);
        }, "json");
    });
});
</script>';

include 'includes/header.php';
?>

<div style="max-width:1000px;">
    <?php if(!empty($errors)): ?>
    <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo implode('<br>', $errors); ?></div>
    <?php endif; ?>
    
    <form method="POST" enctype="multipart/form-data">
        <div style="display:grid;grid-template-columns:2fr 1fr;gap:24px;">
            <div>
                <div class="card">
                    <div class="card-header"><div class="card-title">Post Content</div></div>
                    <div class="card-body">
                        <div class="form-group">
                            <label class="form-label">Post Title *</label>
                            <input type="text" name="title" class="form-control" value="<?php echo htmlspecialchars($post['title']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Content *</label>
                            <textarea name="content" id="content" class="form-control"><?php echo htmlspecialchars($post['content']); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Tags</label>
                            <input type="text" name="tags" class="form-control" value="<?php echo htmlspecialchars($post['tags']??''); ?>">
                        </div>
                    </div>
                </div>
            </div>
            
            <div>
                <div class="card">
                    <div class="card-header"><div class="card-title">Update</div></div>
                    <div class="card-body">
                        <div class="form-group">
                            <label class="form-label">Status</label>
                            <select name="status" class="form-control">
                                <option value="draft" <?php echo $post['status']==='draft'?'selected':''; ?>>Draft</option>
                                <option value="published" <?php echo $post['status']==='published'?'selected':''; ?>>Published</option>
                            </select>
                        </div>
                        <div style="display:flex;gap:10px;">
                            <button type="submit" class="btn btn-primary" style="flex:1;justify-content:center;"><i class="fas fa-save"></i> Update</button>
                            <a href="posts.php" class="btn btn-secondary">Cancel</a>
                        </div>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header"><div class="card-title">Category</div></div>
                    <div class="card-body">
                        <div class="form-group">
                            <label class="form-label">Category *</label>
                            <select name="category_id" id="category_id" class="form-control" required>
                                <?php foreach($categories as $cat): ?>
                                <option value="<?php echo $cat['id']; ?>" <?php echo $post['category_id']==$cat['id']?'selected':''; ?>><?php echo htmlspecialchars($cat['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Sub-Category</label>
                            <select name="subcategory_id" id="subcategory_id" class="form-control">
                                <option value="">-- No Subcategory --</option>
                                <?php foreach($subcats as $sub): ?>
                                <option value="<?php echo $sub['id']; ?>" <?php echo $post['subcategory_id']==$sub['id']?'selected':''; ?>><?php echo htmlspecialchars($sub['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header"><div class="card-title">Featured Image</div></div>
                    <div class="card-body">
                        <?php if($post['image']): ?>
                        <div style="margin-bottom:12px;">
                            <img src="<?php echo UPLOAD_URL.htmlspecialchars($post['image']); ?>" class="img-preview" style="display:block;">
                            <label style="margin-top:8px;display:flex;align-items:center;gap:6px;font-size:13px;cursor:pointer;">
                                <input type="checkbox" name="remove_image" value="1"> Remove current image
                            </label>
                        </div>
                        <?php endif; ?>
                        <input type="file" id="imageInput" name="image" class="form-control" accept="image/*">
                        <div class="form-text">Upload new image to replace current</div>
                        <img id="imagePreview" src="" class="img-preview" style="display:none;margin-top:10px;">
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header"><div class="card-title">Quick Links</div></div>
                    <div class="card-body" style="display:flex;flex-direction:column;gap:8px;">
                        <a href="<?php echo SITE_URL.'/post.php?slug='.$post['slug']; ?>" target="_blank" class="btn btn-info btn-sm"><i class="fas fa-eye"></i> View Post</a>
                        <a href="posts.php?action=delete&id=<?php echo $id; ?>" class="btn btn-danger btn-sm confirm-delete"><i class="fas fa-trash"></i> Move to Trash</a>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

<?php include 'includes/footer.php'; ?>
