<?php
require_once 'includes/auth.php';
requireAdminLogin();
$db = getDB();
$pageTitle = 'My Profile';
$admin = getCurrentAdmin();

$errors = []; $success = '';
if($_SERVER['REQUEST_METHOD']==='POST') {
    $action = $_POST['action']??'';
    if($action === 'update_profile') {
        $name = sanitize($_POST['name']??'');
        $email = sanitize($_POST['email']??'');
        if(!$name||!$email) { $errors[] = 'Name and email required.'; }
        elseif(!filter_var(htmlspecialchars_decode($email), FILTER_VALIDATE_EMAIL)) { $errors[] = 'Invalid email.'; }
        else {
            $id = intval($_SESSION['admin_id']);
            if($db->query("SELECT id FROM admins WHERE email='$email' AND id!=$id")->num_rows) $errors[] = 'Email already in use.';
            else {
                $db->query("UPDATE admins SET name='$name', email='$email' WHERE id=$id");
                $_SESSION['admin_name'] = $name;
                $_SESSION['admin_email'] = $email;
                setFlash('success', 'Profile updated!');
                redirect(ADMIN_URL.'/profile.php');
            }
        }
    } elseif($action === 'change_password') {
        $current = $_POST['current_password']??'';
        $new = $_POST['new_password']??'';
        $confirm = $_POST['confirm_password']??'';
        if(!$current||!$new||!$confirm) $errors[] = 'All password fields required.';
        elseif(!password_verify($current, $admin['password'])) $errors[] = 'Current password is incorrect.';
        elseif(strlen($new)<6) $errors[] = 'New password must be at least 6 characters.';
        elseif($new !== $confirm) $errors[] = 'New passwords do not match.';
        else {
            $hash = password_hash($new, PASSWORD_DEFAULT);
            $id = intval($_SESSION['admin_id']);
            $db->query("UPDATE admins SET password='$hash' WHERE id=$id");
            setFlash('success', 'Password changed successfully!');
            redirect(ADMIN_URL.'/profile.php');
        }
    }
}
include 'includes/header.php';
?>

<div style="max-width:700px;">
    <?php if(!empty($errors)): ?><div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo implode('<br>',$errors); ?></div><?php endif; ?>
    
    <div class="card" style="margin-bottom:24px;">
        <div class="card-header">
            <div class="card-title"><i class="fas fa-user-circle"></i> Profile Information</div>
            <span class="badge badge-<?php echo isAdmin()?'danger':'info'; ?>"><?php echo ucfirst($admin['role']); ?></span>
        </div>
        <div class="card-body">
            <form method="POST">
                <input type="hidden" name="action" value="update_profile">
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Full Name *</label>
                        <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($admin['name']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Email Address *</label>
                        <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($admin['email']); ?>" required>
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">Role</label>
                    <input type="text" class="form-control" value="<?php echo ucfirst($admin['role']); ?>" disabled style="background:#f5f5f5;">
                </div>
                <div class="form-group">
                    <label class="form-label">Member Since</label>
                    <input type="text" class="form-control" value="<?php echo date('F j, Y', strtotime($admin['created_at'])); ?>" disabled style="background:#f5f5f5;">
                </div>
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Update Profile</button>
            </form>
        </div>
    </div>
    
    <div class="card">
        <div class="card-header"><div class="card-title"><i class="fas fa-lock"></i> Change Password</div></div>
        <div class="card-body">
            <form method="POST">
                <input type="hidden" name="action" value="change_password">
                <div class="form-group"><label class="form-label">Current Password *</label><input type="password" name="current_password" class="form-control" required></div>
                <div class="form-row">
                    <div class="form-group"><label class="form-label">New Password *</label><input type="password" name="new_password" class="form-control" placeholder="Min 6 chars" required></div>
                    <div class="form-group"><label class="form-label">Confirm Password *</label><input type="password" name="confirm_password" class="form-control" required></div>
                </div>
                <button type="submit" class="btn btn-warning"><i class="fas fa-key"></i> Change Password</button>
            </form>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
