<?php
require_once 'includes/auth.php';
requireAdminLogin();
$db = getDB();
$pageTitle = 'Add New Post';
$categories = getCategories();

$errors = [];
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = sanitize($_POST['title'] ?? '');
    $catId = intval($_POST['category_id'] ?? 0);
    $subcatId = intval($_POST['subcategory_id'] ?? 0) ?: null;
    $content = $_POST['content'] ?? '';
    $tags = sanitize($_POST['tags'] ?? '');
    $status = in_array($_POST['status'] ?? '', ['published','draft']) ? $_POST['status'] : 'draft';
    
    if(!$title) $errors[] = 'Title is required.';
    if(!$catId) $errors[] = 'Category is required.';
    if(!$content) $errors[] = 'Content is required.';
    
    $image = null;
    if(!empty($_FILES['image']['name'])) {
        $upload = uploadImage($_FILES['image']);
        if(isset($upload['error'])) $errors[] = $upload['error'];
        else $image = $upload['success'];
    }
    
    if(empty($errors)) {
        $slug = createSlug($title);
        // Ensure unique slug
        $origSlug = $slug; $i = 1;
        while($db->query("SELECT id FROM posts WHERE slug='$slug'")->num_rows > 0) {
            $slug = $origSlug . '-' . $i++;
        }
        $adminId = intval($_SESSION['admin_id']);
        $content = $db->real_escape_string($content);
        $subcatSql = $subcatId ? $subcatId : 'NULL';
        $imageSql = $image ? "'$image'" : 'NULL';
        
        $db->query("INSERT INTO posts (category_id, subcategory_id, admin_id, title, slug, content, image, tags, status) VALUES ($catId, $subcatSql, $adminId, '$title', '$slug', '$content', $imageSql, '$tags', '$status')");
        setFlash('success', 'Post added successfully!');
        redirect(ADMIN_URL.'/posts.php');
    }
}

$extraCSS = '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.18/summernote-lite.min.css">';
$extraJS = '<script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.18/summernote-lite.min.js"></script>
<script>
$(document).ready(function() {
    $("#content").summernote({
        height: 350,
        toolbar: [
            ["style", ["style"]],
            ["font", ["bold", "underline", "italic", "clear"]],
            ["color", ["color"]],
            ["para", ["ul", "ol", "paragraph"]],
            ["table", ["table"]],
            ["insert", ["link", "picture"]],
            ["view", ["fullscreen", "codeview"]]
        ]
    });
    
    $("#category_id").on("change", function() {
        var catId = $(this).val();
        if(!catId) { $("#subcategory_id").html(\'<option value="">-- No Subcategory --</option>\'); return; }
        $.get("get-subcats.php", {cat_id: catId}, function(data) {
            var html = \'<option value="">-- No Subcategory --</option>\';
            $.each(data, function(i, s) { html += \'<option value="\' + s.id + \'">\' + s.name + \'</option>\'; });
            $("#subcategory_id").html(html);
        }, "json");
    });
});
</script>';

include 'includes/header.php';
?>

<div style="max-width:1000px;">
    <?php if(!empty($errors)): ?>
    <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo implode('<br>', $errors); ?></div>
    <?php endif; ?>
    
    <form method="POST" enctype="multipart/form-data">
        <div style="display:grid;grid-template-columns:2fr 1fr;gap:24px;">
            <div>
                <div class="card">
                    <div class="card-header"><div class="card-title">Post Content</div></div>
                    <div class="card-body">
                        <div class="form-group">
                            <label class="form-label">Post Title *</label>
                            <input type="text" name="title" class="form-control" value="<?php echo htmlspecialchars($_POST['title']??''); ?>" placeholder="Enter post title..." required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Content *</label>
                            <textarea name="content" id="content" class="form-control"><?php echo htmlspecialchars($_POST['content']??''); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Tags</label>
                            <input type="text" name="tags" class="form-control" value="<?php echo htmlspecialchars($_POST['tags']??''); ?>" placeholder="tag1, tag2, tag3">
                            <div class="form-text">Comma-separated tags</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div>
                <div class="card">
                    <div class="card-header"><div class="card-title">Publish</div></div>
                    <div class="card-body">
                        <div class="form-group">
                            <label class="form-label">Status</label>
                            <select name="status" class="form-control">
                                <option value="draft" <?php echo ($_POST['status']??'')==='draft'?'selected':''; ?>>Draft</option>
                                <option value="published" <?php echo ($_POST['status']??'')==='published'?'selected':''; ?>>Published</option>
                            </select>
                        </div>
                        <div style="display:flex;gap:10px;">
                            <button type="submit" class="btn btn-primary" style="flex:1;justify-content:center;"><i class="fas fa-save"></i> Publish</button>
                            <a href="posts.php" class="btn btn-secondary">Cancel</a>
                        </div>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header"><div class="card-title">Category</div></div>
                    <div class="card-body">
                        <div class="form-group">
                            <label class="form-label">Category *</label>
                            <select name="category_id" id="category_id" class="form-control" required>
                                <option value="">-- Select Category --</option>
                                <?php foreach($categories as $cat): ?>
                                <option value="<?php echo $cat['id']; ?>" <?php echo ($_POST['category_id']??'')==$cat['id']?'selected':''; ?>><?php echo htmlspecialchars($cat['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Sub-Category</label>
                            <select name="subcategory_id" id="subcategory_id" class="form-control">
                                <option value="">-- No Subcategory --</option>
                            </select>
                        </div>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header"><div class="card-title">Featured Image</div></div>
                    <div class="card-body">
                        <div class="form-group">
                            <input type="file" id="imageInput" name="image" class="form-control" accept="image/*">
                            <div class="form-text">Max 5MB. JPG, PNG, GIF, WEBP</div>
                            <img id="imagePreview" src="" class="img-preview" style="display:none;margin-top:10px;">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

<?php include 'includes/footer.php'; ?>
