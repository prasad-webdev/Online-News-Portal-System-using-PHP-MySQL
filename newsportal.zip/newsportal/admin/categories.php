<?php
require_once 'includes/auth.php';
requireAdminLogin();
$db = getDB();
$pageTitle = 'Manage Categories';

// Handle actions
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if($action === 'add') {
        $name = sanitize($_POST['name'] ?? '');
        if(!$name) { setFlash('danger','Name is required.'); }
        else {
            $slug = createSlug($name);
            $origSlug = $slug; $i = 1;
            while($db->query("SELECT id FROM categories WHERE slug='$slug'")->num_rows > 0) $slug = $origSlug.'-'.$i++;
            $db->query("INSERT INTO categories (name, slug) VALUES ('$name', '$slug')");
            setFlash('success','Category added successfully!');
        }
    } elseif($action === 'edit') {
        $id = intval($_POST['id']); $name = sanitize($_POST['name'] ?? '');
        if(!$id || !$name) { setFlash('danger','Invalid data.'); }
        else {
            $slug = createSlug($name);
            $origSlug = $slug; $i = 1;
            while($db->query("SELECT id FROM categories WHERE slug='$slug' AND id!=$id")->num_rows > 0) $slug = $origSlug.'-'.$i++;
            $status = intval($_POST['status'] ?? 1);
            $db->query("UPDATE categories SET name='$name', slug='$slug', status=$status WHERE id=$id");
            setFlash('success','Category updated!');
        }
    }
    redirect(ADMIN_URL.'/categories.php');
}

if(isset($_GET['action']) && isset($_GET['id'])) {
    $id = intval($_GET['id']); $action = $_GET['action'];
    if($action === 'delete') { $db->query("UPDATE categories SET deleted=1 WHERE id=$id"); setFlash('success','Category deleted.'); }
    elseif($action === 'restore') { $db->query("UPDATE categories SET deleted=0 WHERE id=$id"); setFlash('success','Category restored.'); }
    redirect(ADMIN_URL.'/categories.php'.(isset($_GET['trash'])?'?trash=1':''));
}

$showTrash = isset($_GET['trash']);
$cats = $db->query("SELECT c.*, COUNT(p.id) as post_count FROM categories c LEFT JOIN posts p ON p.category_id=c.id AND p.deleted=0 WHERE c.deleted=".($showTrash?'1':'0')." GROUP BY c.id ORDER BY c.name ASC")->fetch_all(MYSQLI_ASSOC);

include 'includes/header.php';
?>

<div style="display:grid;grid-template-columns:1fr 2fr;gap:24px;">
    <!-- Add Form -->
    <div>
        <div class="card">
            <div class="card-header"><div class="card-title"><i class="fas fa-plus-circle"></i> Add New Category</div></div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="action" value="add">
                    <div class="form-group">
                        <label class="form-label">Category Name *</label>
                        <input type="text" name="name" class="form-control" placeholder="e.g., Technology" required>
                    </div>
                    <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;"><i class="fas fa-save"></i> Add Category</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Category List -->
    <div>
        <div class="card">
            <div class="card-header">
                <div class="card-title"><?php echo $showTrash ? 'Deleted Categories' : 'All Categories'; ?></div>
                <a href="categories.php<?php echo $showTrash?'':'?trash=1'; ?>" class="btn btn-secondary btn-sm">
                    <?php echo $showTrash ? '<i class="fas fa-list"></i> Active' : '<i class="fas fa-trash"></i> Trash'; ?>
                </a>
            </div>
            <table class="table">
                <thead><tr><th>#</th><th>Name</th><th>Slug</th><th>Posts</th><th>Status</th><th>Actions</th></tr></thead>
                <tbody>
                    <?php if(empty($cats)): ?>
                    <tr><td colspan="6" style="text-align:center;padding:24px;color:var(--text-muted);">No categories found.</td></tr>
                    <?php else: ?>
                    <?php foreach($cats as $i=>$cat): ?>
                    <tr>
                        <td><?php echo $i+1; ?></td>
                        <td><strong><?php echo htmlspecialchars($cat['name']); ?></strong></td>
                        <td><code style="font-size:12px;background:#f1f1f1;padding:2px 6px;border-radius:3px;"><?php echo $cat['slug']; ?></code></td>
                        <td><span class="badge badge-info"><?php echo $cat['post_count']; ?></span></td>
                        <td>
                            <?php if($cat['deleted']): ?>
                            <span class="badge badge-danger">Deleted</span>
                            <?php else: ?>
                            <span class="badge badge-<?php echo $cat['status']?'success':'warning'; ?>"><?php echo $cat['status']?'Active':'Inactive'; ?></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($cat['deleted']): ?>
                            <a href="categories.php?action=restore&id=<?php echo $cat['id']; ?>&trash=1" class="btn btn-success btn-xs confirm-restore"><i class="fas fa-undo"></i> Restore</a>
                            <?php else: ?>
                            <button onclick="editCategory(<?php echo $cat['id']; ?>, '<?php echo addslashes($cat['name']); ?>', <?php echo $cat['status']; ?>)" class="btn btn-warning btn-xs"><i class="fas fa-edit"></i></button>
                            <a href="categories.php?action=delete&id=<?php echo $cat['id']; ?>" class="btn btn-danger btn-xs confirm-delete"><i class="fas fa-trash"></i></a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Edit Modal -->
<div id="editModal" style="display:none;position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.5);z-index:9999;align-items:center;justify-content:center;">
    <div style="background:#fff;border-radius:8px;padding:28px;width:400px;box-shadow:0 10px 40px rgba(0,0,0,0.3);">
        <h3 style="margin-bottom:20px;color:var(--secondary);">Edit Category</h3>
        <form method="POST">
            <input type="hidden" name="action" value="edit">
            <input type="hidden" name="id" id="editId">
            <div class="form-group">
                <label class="form-label">Category Name *</label>
                <input type="text" name="name" id="editName" class="form-control" required>
            </div>
            <div class="form-group">
                <label class="form-label">Status</label>
                <select name="status" id="editStatus" class="form-control">
                    <option value="1">Active</option>
                    <option value="0">Inactive</option>
                </select>
            </div>
            <div style="display:flex;gap:10px;">
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Update</button>
                <button type="button" onclick="document.getElementById('editModal').style.display='none'" class="btn btn-secondary">Cancel</button>
            </div>
        </form>
    </div>
</div>

<script>
function editCategory(id, name, status) {
    document.getElementById('editId').value = id;
    document.getElementById('editName').value = name;
    document.getElementById('editStatus').value = status;
    document.getElementById('editModal').style.display = 'flex';
}
</script>

<?php include 'includes/footer.php'; ?>
