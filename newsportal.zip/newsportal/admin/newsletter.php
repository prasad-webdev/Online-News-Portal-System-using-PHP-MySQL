<?php
require_once 'includes/auth.php';
requireAdminLogin();
$db = getDB();
$pageTitle = 'Newsletter Subscribers';

// Handle actions
if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    if ($_GET['action'] === 'delete') {
        $db->query("DELETE FROM newsletter WHERE id=$id");
        setFlash('success', 'Subscriber removed.');
    } elseif ($_GET['action'] === 'unsubscribe') {
        $db->query("UPDATE newsletter SET status='unsubscribed' WHERE id=$id");
        setFlash('success', 'Subscriber unsubscribed.');
    } elseif ($_GET['action'] === 'reactivate') {
        $db->query("UPDATE newsletter SET status='active' WHERE id=$id");
        setFlash('success', 'Subscriber reactivated.');
    }
    redirect(ADMIN_URL . '/newsletter.php');
}

$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';
$filter = isset($_GET['filter']) ? sanitize($_GET['filter']) : 'all';

$where = "WHERE 1=1";
if ($search) $where .= " AND (name LIKE '%$search%' OR email LIKE '%$search%')";
if ($filter === 'active')       $where .= " AND status='active'";
if ($filter === 'unsubscribed') $where .= " AND status='unsubscribed'";

$perPage     = 20;
$currentPage = max(1, intval($_GET['page'] ?? 1));
$offset      = ($currentPage - 1) * $perPage;
$total       = $db->query("SELECT COUNT(*) FROM newsletter $where")->fetch_row()[0];
$totalPages  = ceil($total / $perPage);
$subscribers = $db->query("SELECT * FROM newsletter $where ORDER BY created_at DESC LIMIT $perPage OFFSET $offset")->fetch_all(MYSQLI_ASSOC);

$totalCount  = $db->query("SELECT COUNT(*) FROM newsletter")->fetch_row()[0];
$activeCount = $db->query("SELECT COUNT(*) FROM newsletter WHERE status='active'")->fetch_row()[0];
$unsubCount  = $db->query("SELECT COUNT(*) FROM newsletter WHERE status='unsubscribed'")->fetch_row()[0];
$todayCount  = $db->query("SELECT COUNT(*) FROM newsletter WHERE DATE(created_at)=CURDATE()")->fetch_row()[0];

include 'includes/header.php';
?>

<!-- Stats -->
<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-bottom:24px;">
    <div style="background:#fff;border-radius:8px;padding:20px;box-shadow:var(--shadow);border-left:4px solid #3498db;display:flex;align-items:center;gap:16px;">
        <div style="width:48px;height:48px;background:#ebf5fb;border-radius:8px;display:flex;align-items:center;justify-content:center;">
            <i class="fas fa-envelope" style="color:#3498db;font-size:20px;"></i>
        </div>
        <div>
            <div style="font-size:26px;font-weight:800;color:#2c3e50;"><?php echo number_format($totalCount); ?></div>
            <div style="font-size:12px;color:#888;">Total Subscribers</div>
        </div>
    </div>
    <div style="background:#fff;border-radius:8px;padding:20px;box-shadow:var(--shadow);border-left:4px solid #27ae60;display:flex;align-items:center;gap:16px;">
        <div style="width:48px;height:48px;background:#eafaf1;border-radius:8px;display:flex;align-items:center;justify-content:center;">
            <i class="fas fa-check-circle" style="color:#27ae60;font-size:20px;"></i>
        </div>
        <div>
            <div style="font-size:26px;font-weight:800;color:#2c3e50;"><?php echo number_format($activeCount); ?></div>
            <div style="font-size:12px;color:#888;">Active</div>
        </div>
    </div>
    <div style="background:#fff;border-radius:8px;padding:20px;box-shadow:var(--shadow);border-left:4px solid #e74c3c;display:flex;align-items:center;gap:16px;">
        <div style="width:48px;height:48px;background:#fdedec;border-radius:8px;display:flex;align-items:center;justify-content:center;">
            <i class="fas fa-user-minus" style="color:#e74c3c;font-size:20px;"></i>
        </div>
        <div>
            <div style="font-size:26px;font-weight:800;color:#2c3e50;"><?php echo number_format($unsubCount); ?></div>
            <div style="font-size:12px;color:#888;">Unsubscribed</div>
        </div>
    </div>
    <div style="background:#fff;border-radius:8px;padding:20px;box-shadow:var(--shadow);border-left:4px solid #f39c12;display:flex;align-items:center;gap:16px;">
        <div style="width:48px;height:48px;background:#fef9e7;border-radius:8px;display:flex;align-items:center;justify-content:center;">
            <i class="fas fa-star" style="color:#f39c12;font-size:20px;"></i>
        </div>
        <div>
            <div style="font-size:26px;font-weight:800;color:#2c3e50;"><?php echo number_format($todayCount); ?></div>
            <div style="font-size:12px;color:#888;">Joined Today</div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <div class="card-title">
            <i class="fas fa-envelope-open-text"></i> Newsletter Subscribers
            <span style="font-size:13px;font-weight:400;color:#888;margin-left:8px;">(<?php echo number_format($total); ?> found)</span>
        </div>
        <form method="GET" style="display:flex;gap:10px;align-items:center;">
            <div style="position:relative;">
                <i class="fas fa-search" style="position:absolute;left:10px;top:50%;transform:translateY(-50%);color:#aaa;font-size:13px;"></i>
                <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>"
                       placeholder="Search..."
                       style="padding:8px 12px 8px 32px;border:1px solid var(--border);border-radius:6px;font-size:13px;outline:none;width:200px;">
            </div>
            <select name="filter" style="padding:8px 12px;border:1px solid var(--border);border-radius:6px;font-size:13px;outline:none;background:#fff;">
                <option value="all"          <?php echo $filter==='all'?'selected':''; ?>>All</option>
                <option value="active"       <?php echo $filter==='active'?'selected':''; ?>>Active</option>
                <option value="unsubscribed" <?php echo $filter==='unsubscribed'?'selected':''; ?>>Unsubscribed</option>
            </select>
            <button type="submit" class="btn btn-primary" style="padding:8px 16px;">
                <i class="fas fa-filter"></i> Filter
            </button>
            <?php if ($search || $filter !== 'all'): ?>
            <a href="newsletter.php" class="btn btn-secondary" style="padding:8px 16px;">
                <i class="fas fa-times"></i> Clear
            </a>
            <?php endif; ?>
        </form>
    </div>

    <?php if (empty($subscribers)): ?>
    <div style="text-align:center;padding:60px 20px;color:#888;">
        <i class="fas fa-envelope" style="font-size:48px;color:#ddd;display:block;margin-bottom:16px;"></i>
        <div style="font-size:16px;font-weight:600;margin-bottom:8px;">No subscribers found</div>
        <div style="font-size:13px;">Newsletter subscribers will appear here once people subscribe.</div>
    </div>
    <?php else: ?>
    <table class="table">
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Email</th>
                <th>Status</th>
                <th>Subscribed</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($subscribers as $i => $sub): ?>
            <tr>
                <td style="color:#aaa;font-size:12px;"><?php echo $offset + $i + 1; ?></td>
                <td style="font-size:14px;font-weight:500;color:#2c3e50;">
                    <?php echo $sub['name'] ? htmlspecialchars($sub['name']) : '<span style="color:#bbb;font-style:italic;">No name</span>'; ?>
                </td>
                <td style="font-size:13px;color:#555;">
                    <i class="fas fa-envelope" style="color:#aaa;margin-right:5px;"></i>
                    <?php echo htmlspecialchars($sub['email']); ?>
                </td>
                <td>
                    <?php if ($sub['status'] === 'active'): ?>
                    <span style="padding:4px 10px;background:#eafaf1;color:#27ae60;border-radius:20px;font-size:12px;font-weight:600;">
                        Active
                    </span>
                    <?php else: ?>
                    <span style="padding:4px 10px;background:#fdedec;color:#e74c3c;border-radius:20px;font-size:12px;font-weight:600;">
                        Unsubscribed
                    </span>
                    <?php endif; ?>
                </td>
                <td style="font-size:12px;color:#888;">
                    <?php echo date('M j, Y', strtotime($sub['created_at'])); ?>
                    <div style="font-size:11px;color:#bbb;"><?php echo timeAgo($sub['created_at']); ?></div>
                </td>
                <td>
                    <div style="display:flex;gap:6px;">
                        <?php if ($sub['status'] === 'active'): ?>
                        <a href="newsletter.php?action=unsubscribe&id=<?php echo $sub['id']; ?>"
                           title="Unsubscribe"
                           style="display:inline-flex;align-items:center;justify-content:center;width:32px;height:32px;background:#fef9e7;color:#f39c12;border-radius:6px;"
                           onmouseover="this.style.background='#f39c12';this.style.color='#fff'"
                           onmouseout="this.style.background='#fef9e7';this.style.color='#f39c12'">
                            <i class="fas fa-ban" style="font-size:13px;"></i>
                        </a>
                        <?php else: ?>
                        <a href="newsletter.php?action=reactivate&id=<?php echo $sub['id']; ?>"
                           title="Reactivate"
                           style="display:inline-flex;align-items:center;justify-content:center;width:32px;height:32px;background:#eafaf1;color:#27ae60;border-radius:6px;"
                           onmouseover="this.style.background='#27ae60';this.style.color='#fff'"
                           onmouseout="this.style.background='#eafaf1';this.style.color='#27ae60'">
                            <i class="fas fa-check" style="font-size:13px;"></i>
                        </a>
                        <?php endif; ?>
                        <a href="mailto:<?php echo htmlspecialchars($sub['email']); ?>"
                           title="Send Email"
                           style="display:inline-flex;align-items:center;justify-content:center;width:32px;height:32px;background:#ebf5fb;color:#3498db;border-radius:6px;"
                           onmouseover="this.style.background='#3498db';this.style.color='#fff'"
                           onmouseout="this.style.background='#ebf5fb';this.style.color='#3498db'">
                            <i class="fas fa-envelope" style="font-size:13px;"></i>
                        </a>
                        <a href="newsletter.php?action=delete&id=<?php echo $sub['id']; ?>"
                           title="Delete" class="confirm-delete"
                           style="display:inline-flex;align-items:center;justify-content:center;width:32px;height:32px;background:#fdedec;color:#e74c3c;border-radius:6px;"
                           onmouseover="this.style.background='#e74c3c';this.style.color='#fff'"
                           onmouseout="this.style.background='#fdedec';this.style.color='#e74c3c'">
                            <i class="fas fa-trash" style="font-size:13px;"></i>
                        </a>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <?php if ($totalPages > 1): ?>
    <div style="padding:16px 20px;border-top:1px solid var(--border);display:flex;justify-content:space-between;align-items:center;">
        <div style="font-size:13px;color:#888;">
            Showing <?php echo $offset+1; ?>–<?php echo min($offset+$perPage,$total); ?> of <?php echo number_format($total); ?>
        </div>
        <div style="display:flex;gap:6px;">
            <?php for ($p = 1; $p <= $totalPages; $p++): ?>
            <a href="?page=<?php echo $p; ?>&search=<?php echo urlencode($search); ?>&filter=<?php echo $filter; ?>"
               style="display:inline-flex;align-items:center;justify-content:center;width:34px;height:34px;border-radius:6px;font-size:13px;font-weight:600;
                      background:<?php echo $p==$currentPage?'var(--primary)':'#f8f9fa'; ?>;
                      color:<?php echo $p==$currentPage?'#fff':'#555'; ?>;
                      border:1px solid <?php echo $p==$currentPage?'var(--primary)':'var(--border)'; ?>;">
                <?php echo $p; ?>
            </a>
            <?php endfor; ?>
        </div>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
