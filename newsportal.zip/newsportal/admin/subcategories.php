<?php
require_once 'includes/auth.php';
requireAdminLogin();
$db = getDB();
$pageTitle = 'Manage Sub-Categories';
$categories = getCategories();

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if($action === 'add') {
        $name = sanitize($_POST['name'] ?? '');
        $catId = intval($_POST['category_id'] ?? 0);
        if(!$name || !$catId) setFlash('danger','All fields required.');
        else {
            $slug = createSlug($name); $orig = $slug; $i = 1;
            while($db->query("SELECT id FROM subcategories WHERE slug='$slug'")->num_rows > 0) $slug = $orig.'-'.$i++;
            $db->query("INSERT INTO subcategories (category_id, name, slug) VALUES ($catId, '$name', '$slug')");
            setFlash('success','Sub-category added!');
        }
    } elseif($action === 'edit') {
        $id = intval($_POST['id']); $name = sanitize($_POST['name']??''); $catId = intval($_POST['category_id']??0); $status = intval($_POST['status']??1);
        if($id && $name && $catId) {
            $slug = createSlug($name); $orig = $slug; $i = 1;
            while($db->query("SELECT id FROM subcategories WHERE slug='$slug' AND id!=$id")->num_rows > 0) $slug = $orig.'-'.$i++;
            $db->query("UPDATE subcategories SET category_id=$catId, name='$name', slug='$slug', status=$status WHERE id=$id");
            setFlash('success','Sub-category updated!');
        }
    }
    redirect(ADMIN_URL.'/subcategories.php');
}
if(isset($_GET['action']) && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    if($_GET['action'] === 'delete') { $db->query("UPDATE subcategories SET deleted=1 WHERE id=$id"); setFlash('success','Deleted.'); }
    elseif($_GET['action'] === 'restore') { $db->query("UPDATE subcategories SET deleted=0 WHERE id=$id"); setFlash('success','Restored.'); }
    redirect(ADMIN_URL.'/subcategories.php'.(isset($_GET['trash'])?'?trash=1':''));
}

$showTrash = isset($_GET['trash']);
$subcats = $db->query("SELECT s.*, c.name as cat_name FROM subcategories s LEFT JOIN categories c ON c.id=s.category_id WHERE s.deleted=".($showTrash?'1':'0')." ORDER BY c.name, s.name ASC")->fetch_all(MYSQLI_ASSOC);

include 'includes/header.php';
?>
<div style="display:grid;grid-template-columns:1fr 2fr;gap:24px;">
    <div>
        <div class="card">
            <div class="card-header"><div class="card-title"><i class="fas fa-plus-circle"></i> Add Sub-Category</div></div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="action" value="add">
                    <div class="form-group">
                        <label class="form-label">Parent Category *</label>
                        <select name="category_id" class="form-control" required>
                            <option value="">-- Select --</option>
                            <?php foreach($categories as $c): ?><option value="<?php echo $c['id']; ?>"><?php echo htmlspecialchars($c['name']); ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Name *</label>
                        <input type="text" name="name" class="form-control" placeholder="Sub-category name" required>
                    </div>
                    <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;"><i class="fas fa-save"></i> Add</button>
                </form>
            </div>
        </div>
    </div>
    <div>
        <div class="card">
            <div class="card-header">
                <div class="card-title"><?php echo $showTrash?'Deleted':'All'; ?> Sub-Categories</div>
                <a href="subcategories.php<?php echo $showTrash?'':'?trash=1'; ?>" class="btn btn-secondary btn-sm"><?php echo $showTrash?'Active':'Trash'; ?></a>
            </div>
            <table class="table">
                <thead><tr><th>#</th><th>Name</th><th>Category</th><th>Status</th><th>Actions</th></tr></thead>
                <tbody>
                    <?php if(empty($subcats)): ?><tr><td colspan="5" style="text-align:center;padding:24px;color:var(--text-muted);">No sub-categories found.</td></tr>
                    <?php else: ?>
                    <?php foreach($subcats as $i=>$s): ?>
                    <tr>
                        <td><?php echo $i+1; ?></td>
                        <td><strong><?php echo htmlspecialchars($s['name']); ?></strong></td>
                        <td><span class="badge badge-info"><?php echo htmlspecialchars($s['cat_name']); ?></span></td>
                        <td><span class="badge badge-<?php echo $s['deleted']?'danger':($s['status']?'success':'warning'); ?>"><?php echo $s['deleted']?'Deleted':($s['status']?'Active':'Inactive'); ?></span></td>
                        <td>
                            <?php if($s['deleted']): ?>
                            <a href="subcategories.php?action=restore&id=<?php echo $s['id']; ?>&trash=1" class="btn btn-success btn-xs confirm-restore"><i class="fas fa-undo"></i></a>
                            <?php else: ?>
                            <button onclick="editSub(<?php echo $s['id']; ?>, '<?php echo addslashes($s['name']); ?>', <?php echo $s['category_id']; ?>, <?php echo $s['status']; ?>)" class="btn btn-warning btn-xs"><i class="fas fa-edit"></i></button>
                            <a href="subcategories.php?action=delete&id=<?php echo $s['id']; ?>" class="btn btn-danger btn-xs confirm-delete"><i class="fas fa-trash"></i></a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div id="editModal" style="display:none;position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.5);z-index:9999;align-items:center;justify-content:center;">
    <div style="background:#fff;border-radius:8px;padding:28px;width:420px;box-shadow:0 10px 40px rgba(0,0,0,0.3);">
        <h3 style="margin-bottom:20px;">Edit Sub-Category</h3>
        <form method="POST">
            <input type="hidden" name="action" value="edit">
            <input type="hidden" name="id" id="editId">
            <div class="form-group">
                <label class="form-label">Parent Category *</label>
                <select name="category_id" id="editCatId" class="form-control">
                    <?php foreach($categories as $c): ?><option value="<?php echo $c['id']; ?>"><?php echo htmlspecialchars($c['name']); ?></option><?php endforeach; ?>
                </select>
            </div>
            <div class="form-group"><label class="form-label">Name *</label><input type="text" name="name" id="editName" class="form-control" required></div>
            <div class="form-group"><label class="form-label">Status</label><select name="status" id="editStatus" class="form-control"><option value="1">Active</option><option value="0">Inactive</option></select></div>
            <div style="display:flex;gap:10px;">
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Update</button>
                <button type="button" onclick="document.getElementById('editModal').style.display='none'" class="btn btn-secondary">Cancel</button>
            </div>
        </form>
    </div>
</div>
<script>
function editSub(id, name, catId, status) {
    document.getElementById('editId').value = id;
    document.getElementById('editName').value = name;
    document.getElementById('editCatId').value = catId;
    document.getElementById('editStatus').value = status;
    document.getElementById('editModal').style.display = 'flex';
}
</script>
<?php include 'includes/footer.php'; ?>
