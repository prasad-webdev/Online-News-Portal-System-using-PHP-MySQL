<?php
require_once '../includes/config.php';

// Redirect if already logged in
if(isAdminLoggedIn()) redirect(ADMIN_URL . '/dashboard.php');

$error = '';
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitize($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if(!$email || !$password) {
        $error = 'Please enter both email and password.';
    } else {
        $db = getDB();
        $admin = $db->query("SELECT * FROM admins WHERE email='$email' AND status=1")->fetch_assoc();
        
        if($admin && password_verify($password, $admin['password'])) {
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_name'] = $admin['name'];
            $_SESSION['admin_role'] = $admin['role'];
            $_SESSION['admin_email'] = $admin['email'];
            redirect(ADMIN_URL . '/dashboard.php');
        } else {
            $error = 'Invalid email or password. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login | <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, #1e2a3a 0%, #2c3e50 50%, #c0392b 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-wrapper {
            width: 100%;
            max-width: 420px;
            padding: 20px;
        }
        .login-logo {
            text-align: center;
            margin-bottom: 30px;
            color: #fff;
        }
        .login-logo i { font-size: 50px; margin-bottom: 10px; display: block; }
        .login-logo h1 { font-size: 28px; font-weight: 800; }
        .login-logo p { font-size: 14px; opacity: 0.7; margin-top: 6px; }
        .login-card {
            background: #fff;
            border-radius: 12px;
            padding: 36px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }
        .login-card h2 { font-size: 22px; font-weight: 700; color: #2c3e50; margin-bottom: 24px; }
        .form-group { margin-bottom: 18px; }
        label { display: block; margin-bottom: 6px; font-size: 13px; font-weight: 600; color: #2c3e50; }
        .input-wrap { position: relative; }
        .input-wrap i { position: absolute; left: 14px; top: 50%; transform: translateY(-50%); color: #aaa; font-size: 15px; }
        input {
            width: 100%;
            padding: 12px 14px 12px 40px;
            border: 2px solid #dee2e6;
            border-radius: 6px;
            font-size: 14px;
            outline: none;
            transition: border-color 0.2s;
        }
        input:focus { border-color: #c0392b; }
        .btn-login {
            width: 100%;
            padding: 13px;
            background: #c0392b;
            color: #fff;
            border: none;
            border-radius: 6px;
            font-size: 15px;
            font-weight: 700;
            cursor: pointer;
            transition: background 0.2s;
            margin-top: 8px;
        }
        .btn-login:hover { background: #96281b; }
        .alert { padding: 12px 16px; background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; border-radius: 5px; margin-bottom: 16px; font-size: 14px; }
        .demo-info { background: #e8f5e9; border: 1px solid #c8e6c9; border-radius: 6px; padding: 12px; margin-top: 20px; font-size: 13px; color: #2e7d32; }
        .demo-info strong { display: block; margin-bottom: 4px; }
        .back-link { text-align: center; margin-top: 16px; font-size: 13px; color: #999; }
        .back-link a { color: #c0392b; }
    </style>
</head>
<body>
<div class="login-wrapper">
    <div class="login-logo">
        <i class="fas fa-newspaper"></i>
        <h1>NewsPortal</h1>
        <p>Content Management System</p>
    </div>
    <div class="login-card">
        <h2><i class="fas fa-lock" style="color:#c0392b;margin-right:8px;"></i>Admin Login</h2>
        
        <?php if($error): ?>
        <div class="alert"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="form-group">
                <label>Email Address</label>
                <div class="input-wrap">
                    <i class="fas fa-envelope"></i>
                    <input type="email" name="email" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" placeholder="Enter your email" required>
                </div>
            </div>
            <div class="form-group">
                <label>Password</label>
                <div class="input-wrap">
                    <i class="fas fa-lock"></i>
                    <input type="password" name="password" placeholder="Enter your password" required>
                </div>
            </div>
            <button type="submit" class="btn-login"><i class="fas fa-sign-in-alt"></i> Login to Admin Panel</button>
        </form>
        
        
    </div>
    <div class="back-link"><a href="<?php echo SITE_URL; ?>"><i class="fas fa-arrow-left"></i> Back to Website</a></div>
</div>
</body>
</html>
