<?php
require_once 'includes/auth.php';
requireAdminLogin();
$db = getDB();
$pageTitle = 'Manage Posts';

$status = isset($_GET['status']) ? sanitize($_GET['status']) : 'all';
$catFilter = isset($_GET['cat']) ? intval($_GET['cat']) : 0;
$search = isset($_GET['q']) ? sanitize($_GET['q']) : '';
$page = max(1, intval($_GET['page'] ?? 1));
$perPage = 15; $offset = ($page-1)*$perPage;

// Build query
$where = [];
if($status === 'trash') $where[] = "p.deleted=1";
else { $where[] = "p.deleted=0"; if($status === 'published') $where[] = "p.status='published'"; elseif($status === 'draft') $where[] = "p.status='draft'"; }
if($catFilter) $where[] = "p.category_id=$catFilter";
if($search) { $sq = $db->real_escape_string($search); $where[] = "(p.title LIKE '%$sq%' OR p.content LIKE '%$sq%')"; }
$whereStr = $where ? 'WHERE '.implode(' AND ', $where) : '';

$total = $db->query("SELECT COUNT(*) FROM posts p $whereStr")->fetch_row()[0];
$totalPages = ceil($total/$perPage);
$posts = $db->query("SELECT p.*, c.name as cat_name, a.name as author FROM posts p LEFT JOIN categories c ON c.id=p.category_id LEFT JOIN admins a ON a.id=p.admin_id $whereStr ORDER BY p.created_at DESC LIMIT $perPage OFFSET $offset")->fetch_all(MYSQLI_ASSOC);
$categories = getCategories();

// Handle actions
if(isset($_GET['action']) && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $action = $_GET['action'];
    if($action === 'delete') {
        $db->query("UPDATE posts SET deleted=1 WHERE id=$id");
        setFlash('success', 'Post moved to trash.');
    } elseif($action === 'restore') {
        $db->query("UPDATE posts SET deleted=0 WHERE id=$id");
        setFlash('success', 'Post restored successfully.');
    } elseif($action === 'delete_permanent') {
        $post = $db->query("SELECT image FROM posts WHERE id=$id")->fetch_assoc();
        if($post && $post['image'] && file_exists(UPLOAD_PATH.$post['image'])) unlink(UPLOAD_PATH.$post['image']);
        $db->query("DELETE FROM posts WHERE id=$id");
        setFlash('success', 'Post permanently deleted.');
    } elseif($action === 'toggle_status') {
        $p = $db->query("SELECT status FROM posts WHERE id=$id")->fetch_assoc();
        $newStatus = $p['status'] === 'published' ? 'draft' : 'published';
        $db->query("UPDATE posts SET status='$newStatus' WHERE id=$id");
        setFlash('success', 'Post status updated.');
    }
    redirect(ADMIN_URL.'/posts.php?status='.$status);
}

include 'includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <div class="card-title">
            <?php echo $status==='trash' ? 'Trashed Posts' : 'All Posts'; ?>
            <span style="font-size:13px;font-weight:400;color:var(--text-muted);">(<?php echo $total; ?> posts)</span>
        </div>
        <?php if($status!=='trash'): ?>
        <a href="post-add.php" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Add New Post</a>
        <?php endif; ?>
    </div>
    <div class="card-body">
        <!-- Status Tabs -->
        <div style="display:flex;gap:8px;margin-bottom:16px;flex-wrap:wrap;">
            <?php
            $allCount = $db->query("SELECT COUNT(*) FROM posts WHERE deleted=0")->fetch_row()[0];
            $pubCount = $db->query("SELECT COUNT(*) FROM posts WHERE status='published' AND deleted=0")->fetch_row()[0];
            $draftCount = $db->query("SELECT COUNT(*) FROM posts WHERE status='draft' AND deleted=0")->fetch_row()[0];
            $trashCount = $db->query("SELECT COUNT(*) FROM posts WHERE deleted=1")->fetch_row()[0];
            ?>
            <a href="posts.php" class="btn btn-sm <?php echo $status==='all'?'btn-primary':'btn-secondary'; ?>">All (<?php echo $allCount; ?>)</a>
            <a href="posts.php?status=published" class="btn btn-sm <?php echo $status==='published'?'btn-primary':'btn-secondary'; ?>">Published (<?php echo $pubCount; ?>)</a>
            <a href="posts.php?status=draft" class="btn btn-sm <?php echo $status==='draft'?'btn-primary':'btn-secondary'; ?>">Drafts (<?php echo $draftCount; ?>)</a>
            <a href="posts.php?status=trash" class="btn btn-sm <?php echo $status==='trash'?'btn-danger':'btn-secondary'; ?>">Trash (<?php echo $trashCount; ?>)</a>
        </div>
        
        <!-- Filters -->
        <form method="GET" action="posts.php">
            <input type="hidden" name="status" value="<?php echo htmlspecialchars($status); ?>">
            <div class="filter-bar">
                <input type="text" name="q" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search posts..." class="form-control" style="width:220px;">
                <select name="cat" class="form-control">
                    <option value="0">All Categories</option>
                    <?php foreach($categories as $cat): ?>
                    <option value="<?php echo $cat['id']; ?>" <?php echo $catFilter==$cat['id']?'selected':''; ?>><?php echo htmlspecialchars($cat['name']); ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-search"></i> Filter</button>
                <a href="posts.php" class="btn btn-secondary btn-sm">Clear</a>
            </div>
        </form>
    </div>
    
    <table class="table">
        <thead>
            <tr>
                <th style="width:30px;"><input type="checkbox" id="selectAll"></th>
                <th>Title</th>
                <th>Category</th>
                <th>Author</th>
                <th>Status</th>
                <th>Views</th>
                <th>Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if(empty($posts)): ?>
            <tr><td colspan="8" style="text-align:center;padding:30px;color:var(--text-muted);"><i class="fas fa-newspaper" style="font-size:32px;margin-bottom:8px;display:block;"></i>No posts found.</td></tr>
            <?php else: ?>
            <?php foreach($posts as $p): ?>
            <tr>
                <td><input type="checkbox" name="ids[]" value="<?php echo $p['id']; ?>"></td>
                <td>
                    <div style="display:flex;align-items:center;gap:10px;">
                        <?php if($p['image']): ?>
                        <img src="<?php echo UPLOAD_URL.htmlspecialchars($p['image']); ?>" style="width:50px;height:40px;object-fit:cover;border-radius:4px;flex-shrink:0;">
                        <?php else: ?>
                        <div style="width:50px;height:40px;background:#e0e0e0;border-radius:4px;display:flex;align-items:center;justify-content:center;flex-shrink:0;"><i class="fas fa-newspaper" style="color:#bbb;"></i></div>
                        <?php endif; ?>
                        <div>
                            <div style="font-weight:600;font-size:13px;color:var(--secondary);"><?php echo htmlspecialchars(mb_substr($p['title'],0,55).(strlen($p['title'])>55?'...':'')); ?></div>
                            <div style="font-size:11px;color:var(--text-muted);">ID: <?php echo $p['id']; ?></div>
                        </div>
                    </div>
                </td>
                <td><span class="badge badge-info"><?php echo htmlspecialchars($p['cat_name']); ?></span></td>
                <td style="font-size:13px;"><?php echo htmlspecialchars($p['author']); ?></td>
                <td>
                    <?php if($p['deleted']): ?>
                    <span class="badge badge-danger">Trashed</span>
                    <?php else: ?>
                    <a href="posts.php?action=toggle_status&id=<?php echo $p['id']; ?>&status=<?php echo $status; ?>" style="text-decoration:none;">
                        <span class="badge badge-<?php echo $p['status']=='published'?'success':'warning'; ?>"><?php echo ucfirst($p['status']); ?></span>
                    </a>
                    <?php endif; ?>
                </td>
                <td style="font-size:13px;"><?php echo number_format($p['views']); ?></td>
                <td style="font-size:12px;color:var(--text-muted);"><?php echo date('M j, Y', strtotime($p['created_at'])); ?></td>
                <td>
                    <?php if($p['deleted']): ?>
                    <a href="posts.php?action=restore&id=<?php echo $p['id']; ?>&status=trash" class="btn btn-success btn-xs confirm-restore" title="Restore"><i class="fas fa-undo"></i></a>
                    <a href="posts.php?action=delete_permanent&id=<?php echo $p['id']; ?>&status=trash" class="btn btn-danger btn-xs confirm-delete" title="Delete Permanently"><i class="fas fa-times"></i></a>
                    <?php else: ?>
                    <a href="post-edit.php?id=<?php echo $p['id']; ?>" class="btn btn-warning btn-xs" title="Edit"><i class="fas fa-edit"></i></a>
                    <a href="<?php echo SITE_URL; ?>/post.php?slug=<?php echo $p['slug']; ?>" target="_blank" class="btn btn-info btn-xs" title="View"><i class="fas fa-eye"></i></a>
                    <a href="posts.php?action=delete&id=<?php echo $p['id']; ?>" class="btn btn-danger btn-xs confirm-delete" title="Trash"><i class="fas fa-trash"></i></a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
    
    <?php if($totalPages > 1): ?>
    <div class="card-body" style="border-top:1px solid var(--border);">
        <div class="pagination">
            <?php if($page>1): ?><a href="?status=<?php echo $status; ?>&page=<?php echo $page-1; ?>" class="page-link"><i class="fas fa-chevron-left"></i></a><?php endif; ?>
            <?php for($i=1;$i<=$totalPages;$i++): ?><a href="?status=<?php echo $status; ?>&page=<?php echo $i; ?>" class="page-link <?php echo $i==$page?'active':''; ?>"><?php echo $i; ?></a><?php endfor; ?>
            <?php if($page<$totalPages): ?><a href="?status=<?php echo $status; ?>&page=<?php echo $page+1; ?>" class="page-link"><i class="fas fa-chevron-right"></i></a><?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
