<?php
require_once 'includes/auth.php';
requireAdminLogin();
$db = getDB();
$pageTitle = 'Manage Users';

// Handle actions
if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    switch ($_GET['action']) {
        case 'delete':
            $db->query("DELETE FROM users WHERE id=$id");
            setFlash('success', 'User deleted successfully.');
            break;
        case 'activate':
            $db->query("UPDATE users SET status=1 WHERE id=$id");
            setFlash('success', 'User activated successfully.');
            break;
        case 'deactivate':
            $db->query("UPDATE users SET status=0 WHERE id=$id");
            setFlash('success', 'User deactivated successfully.');
            break;
    }
    redirect(ADMIN_URL . '/users.php');
}

// Search & filter
$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';
$filter = isset($_GET['filter']) ? sanitize($_GET['filter']) : 'all';

$where = "WHERE 1=1";
if ($search) {
    $where .= " AND (name LIKE '%$search%' OR email LIKE '%$search%')";
}
if ($filter === 'active')   $where .= " AND status=1";
if ($filter === 'inactive') $where .= " AND status=0";

// Pagination
$perPage     = 15;
$currentPage = max(1, intval($_GET['page'] ?? 1));
$offset      = ($currentPage - 1) * $perPage;

$totalUsers  = $db->query("SELECT COUNT(*) FROM users $where")->fetch_row()[0];
$totalPages  = ceil($totalUsers / $perPage);

$users = $db->query("SELECT * FROM users $where ORDER BY created_at DESC LIMIT $perPage OFFSET $offset")->fetch_all(MYSQLI_ASSOC);

// Stats
$totalCount    = $db->query("SELECT COUNT(*) FROM users")->fetch_row()[0];
$activeCount   = $db->query("SELECT COUNT(*) FROM users WHERE status=1")->fetch_row()[0];
$inactiveCount = $db->query("SELECT COUNT(*) FROM users WHERE status=0")->fetch_row()[0];
$todayCount    = $db->query("SELECT COUNT(*) FROM users WHERE DATE(created_at)=CURDATE()")->fetch_row()[0];

include 'includes/header.php';
?>

<!-- Stats Cards -->
<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-bottom:24px;">
    <div style="background:#fff;border-radius:8px;padding:20px;box-shadow:var(--shadow);
                border-left:4px solid #3498db;display:flex;align-items:center;gap:16px;">
        <div style="width:48px;height:48px;background:#ebf5fb;border-radius:8px;
                    display:flex;align-items:center;justify-content:center;">
            <i class="fas fa-users" style="color:#3498db;font-size:20px;"></i>
        </div>
        <div>
            <div style="font-size:26px;font-weight:800;color:#2c3e50;"><?php echo number_format($totalCount); ?></div>
            <div style="font-size:12px;color:#888;">Total Users</div>
        </div>
    </div>
    <div style="background:#fff;border-radius:8px;padding:20px;box-shadow:var(--shadow);
                border-left:4px solid #27ae60;display:flex;align-items:center;gap:16px;">
        <div style="width:48px;height:48px;background:#eafaf1;border-radius:8px;
                    display:flex;align-items:center;justify-content:center;">
            <i class="fas fa-user-check" style="color:#27ae60;font-size:20px;"></i>
        </div>
        <div>
            <div style="font-size:26px;font-weight:800;color:#2c3e50;"><?php echo number_format($activeCount); ?></div>
            <div style="font-size:12px;color:#888;">Active Users</div>
        </div>
    </div>
    <div style="background:#fff;border-radius:8px;padding:20px;box-shadow:var(--shadow);
                border-left:4px solid #e74c3c;display:flex;align-items:center;gap:16px;">
        <div style="width:48px;height:48px;background:#fdedec;border-radius:8px;
                    display:flex;align-items:center;justify-content:center;">
            <i class="fas fa-user-times" style="color:#e74c3c;font-size:20px;"></i>
        </div>
        <div>
            <div style="font-size:26px;font-weight:800;color:#2c3e50;"><?php echo number_format($inactiveCount); ?></div>
            <div style="font-size:12px;color:#888;">Inactive Users</div>
        </div>
    </div>
    <div style="background:#fff;border-radius:8px;padding:20px;box-shadow:var(--shadow);
                border-left:4px solid #f39c12;display:flex;align-items:center;gap:16px;">
        <div style="width:48px;height:48px;background:#fef9e7;border-radius:8px;
                    display:flex;align-items:center;justify-content:center;">
            <i class="fas fa-user-plus" style="color:#f39c12;font-size:20px;"></i>
        </div>
        <div>
            <div style="font-size:26px;font-weight:800;color:#2c3e50;"><?php echo number_format($todayCount); ?></div>
            <div style="font-size:12px;color:#888;">Joined Today</div>
        </div>
    </div>
</div>

<!-- Main Card -->
<div class="card">
    <div class="card-header">
        <div class="card-title">
            <i class="fas fa-users"></i> Registered Users
            <span style="font-size:13px;font-weight:400;color:#888;margin-left:8px;">
                (<?php echo number_format($totalUsers); ?> found)
            </span>
        </div>
        <!-- Search & Filter -->
        <form method="GET" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
            <div style="position:relative;">
                <i class="fas fa-search" style="position:absolute;left:10px;top:50%;
                   transform:translateY(-50%);color:#aaa;font-size:13px;"></i>
                <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>"
                       placeholder="Search name or email..."
                       style="padding:8px 12px 8px 32px;border:1px solid var(--border);
                              border-radius:6px;font-size:13px;outline:none;width:220px;">
            </div>
            <select name="filter"
                    style="padding:8px 12px;border:1px solid var(--border);border-radius:6px;
                           font-size:13px;outline:none;background:#fff;">
                <option value="all"      <?php echo $filter==='all'      ?'selected':''; ?>>All Users</option>
                <option value="active"   <?php echo $filter==='active'   ?'selected':''; ?>>Active</option>
                <option value="inactive" <?php echo $filter==='inactive' ?'selected':''; ?>>Inactive</option>
            </select>
            <button type="submit" class="btn btn-primary" style="padding:8px 16px;">
                <i class="fas fa-filter"></i> Filter
            </button>
            <?php if ($search || $filter !== 'all'): ?>
            <a href="users.php" class="btn btn-secondary" style="padding:8px 16px;">
                <i class="fas fa-times"></i> Clear
            </a>
            <?php endif; ?>
        </form>
    </div>

    <?php if (empty($users)): ?>
    <div style="text-align:center;padding:60px 20px;color:#888;">
        <i class="fas fa-users" style="font-size:48px;color:#ddd;display:block;margin-bottom:16px;"></i>
        <div style="font-size:16px;font-weight:600;margin-bottom:8px;">No users found</div>
        <div style="font-size:13px;">
            <?php echo $search ? 'Try a different search term.' : 'No users have registered yet.'; ?>
        </div>
    </div>

    <?php else: ?>
    <div style="overflow-x:auto;">
        <table class="table">
            <thead>
                <tr>
                    <th style="width:40px;">#</th>
                    <th>User</th>
                    <th>Email</th>
                    <th>Status</th>
                    <th>Verified</th>
                    <th>Joined</th>
                    <th style="width:140px;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $i => $user): ?>
                <tr>
                    <td style="color:#aaa;font-size:12px;">
                        <?php echo $offset + $i + 1; ?>
                    </td>
                    <td>
                        <div style="display:flex;align-items:center;gap:10px;">
                            <!-- Avatar -->
                            <div style="width:38px;height:38px;border-radius:50%;
                                        background:<?php
                                            $colors = ['#e74c3c','#3498db','#27ae60','#f39c12','#9b59b6','#1abc9c'];
                                            echo $colors[$user['id'] % count($colors)];
                                        ?>;
                                        color:#fff;display:flex;align-items:center;
                                        justify-content:center;font-weight:700;font-size:15px;
                                        flex-shrink:0;">
                                <?php echo strtoupper(substr($user['name'], 0, 1)); ?>
                            </div>
                            <div>
                                <div style="font-weight:600;font-size:14px;color:#2c3e50;">
                                    <?php echo htmlspecialchars($user['name']); ?>
                                </div>
                                <div style="font-size:11px;color:#aaa;">
                                    ID: #<?php echo $user['id']; ?>
                                </div>
                            </div>
                        </div>
                    </td>
                    <td style="font-size:13px;color:#555;">
                        <i class="fas fa-envelope" style="color:#aaa;margin-right:5px;"></i>
                        <?php echo htmlspecialchars($user['email']); ?>
                    </td>
                    <td>
                        <?php if ($user['status']): ?>
                        <span style="display:inline-flex;align-items:center;gap:5px;padding:4px 10px;
                                     background:#eafaf1;color:#27ae60;border-radius:20px;
                                     font-size:12px;font-weight:600;">
                            <span style="width:6px;height:6px;background:#27ae60;border-radius:50%;"></span>
                            Active
                        </span>
                        <?php else: ?>
                        <span style="display:inline-flex;align-items:center;gap:5px;padding:4px 10px;
                                     background:#fdedec;color:#e74c3c;border-radius:20px;
                                     font-size:12px;font-weight:600;">
                            <span style="width:6px;height:6px;background:#e74c3c;border-radius:50%;"></span>
                            Inactive
                        </span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if ($user['email_verified']): ?>
                        <span style="color:#27ae60;font-size:13px;">
                            <i class="fas fa-check-circle"></i> Verified
                        </span>
                        <?php else: ?>
                        <span style="color:#f39c12;font-size:13px;">
                            <i class="fas fa-clock"></i> Pending
                        </span>
                        <?php endif; ?>
                    </td>
                    <td style="font-size:12px;color:#888;">
                        <i class="far fa-calendar-alt" style="margin-right:4px;"></i>
                        <?php echo date('M j, Y', strtotime($user['created_at'])); ?>
                        <div style="font-size:11px;color:#bbb;">
                            <?php echo timeAgo($user['created_at']); ?>
                        </div>
                    </td>
                    <td>
                        <div style="display:flex;gap:6px;">
                            <!-- Toggle Status -->
                            <?php if ($user['status']): ?>
                            <a href="users.php?action=deactivate&id=<?php echo $user['id']; ?>"
                               title="Deactivate"
                               style="display:inline-flex;align-items:center;justify-content:center;
                                      width:32px;height:32px;background:#fef9e7;color:#f39c12;
                                      border-radius:6px;transition:all 0.2s;"
                               onmouseover="this.style.background='#f39c12';this.style.color='#fff'"
                               onmouseout="this.style.background='#fef9e7';this.style.color='#f39c12'">
                                <i class="fas fa-ban" style="font-size:13px;"></i>
                            </a>
                            <?php else: ?>
                            <a href="users.php?action=activate&id=<?php echo $user['id']; ?>"
                               title="Activate"
                               style="display:inline-flex;align-items:center;justify-content:center;
                                      width:32px;height:32px;background:#eafaf1;color:#27ae60;
                                      border-radius:6px;transition:all 0.2s;"
                               onmouseover="this.style.background='#27ae60';this.style.color='#fff'"
                               onmouseout="this.style.background='#eafaf1';this.style.color='#27ae60'">
                                <i class="fas fa-check" style="font-size:13px;"></i>
                            </a>
                            <?php endif; ?>

                            <!-- View Email -->
                            <a href="mailto:<?php echo htmlspecialchars($user['email']); ?>"
                               title="Send Email"
                               style="display:inline-flex;align-items:center;justify-content:center;
                                      width:32px;height:32px;background:#ebf5fb;color:#3498db;
                                      border-radius:6px;transition:all 0.2s;"
                               onmouseover="this.style.background='#3498db';this.style.color='#fff'"
                               onmouseout="this.style.background='#ebf5fb';this.style.color='#3498db'">
                                <i class="fas fa-envelope" style="font-size:13px;"></i>
                            </a>

                            <!-- Delete -->
                            <a href="users.php?action=delete&id=<?php echo $user['id']; ?>"
                               title="Delete User"
                               class="confirm-delete"
                               style="display:inline-flex;align-items:center;justify-content:center;
                                      width:32px;height:32px;background:#fdedec;color:#e74c3c;
                                      border-radius:6px;transition:all 0.2s;"
                               onmouseover="this.style.background='#e74c3c';this.style.color='#fff'"
                               onmouseout="this.style.background='#fdedec';this.style.color='#e74c3c'">
                                <i class="fas fa-trash" style="font-size:13px;"></i>
                            </a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <?php if ($totalPages > 1): ?>
    <div style="padding:16px 20px;border-top:1px solid var(--border);
                display:flex;justify-content:space-between;align-items:center;">
        <div style="font-size:13px;color:#888;">
            Showing <?php echo $offset + 1; ?>–<?php echo min($offset + $perPage, $totalUsers); ?>
            of <?php echo number_format($totalUsers); ?> users
        </div>
        <div style="display:flex;gap:6px;">
            <?php for ($p = 1; $p <= $totalPages; $p++): ?>
            <a href="?page=<?php echo $p; ?>&search=<?php echo urlencode($search); ?>&filter=<?php echo $filter; ?>"
               style="display:inline-flex;align-items:center;justify-content:center;
                      width:34px;height:34px;border-radius:6px;font-size:13px;font-weight:600;
                      background:<?php echo $p == $currentPage ? 'var(--primary)' : '#f8f9fa'; ?>;
                      color:<?php echo $p == $currentPage ? '#fff' : '#555'; ?>;
                      border:1px solid <?php echo $p == $currentPage ? 'var(--primary)' : 'var(--border)'; ?>;">
                <?php echo $p; ?>
            </a>
            <?php endfor; ?>
        </div>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
