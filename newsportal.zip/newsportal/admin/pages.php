<?php
require_once 'includes/auth.php';
requireAdminLogin();
$db = getDB();
$pageTitle = 'Manage Pages';

$editPage = null;
if(isset($_GET['edit'])) {
    $pageName = sanitize($_GET['edit']);
    $editPage = $db->query("SELECT * FROM pages WHERE page_name='$pageName'")->fetch_assoc();
}

if($_SERVER['REQUEST_METHOD']==='POST') {
    $pageName = sanitize($_POST['page_name']??'');
    $title = sanitize($_POST['title']??'');
    $content = $_POST['content']??'';
    
    if(!$pageName||!$title||!$content) setFlash('danger','All fields required.');
    else {
        $content = $db->real_escape_string($content);
        $exists = $db->query("SELECT id FROM pages WHERE page_name='$pageName'")->num_rows;
        if($exists) $db->query("UPDATE pages SET title='$title', content='$content' WHERE page_name='$pageName'");
        else $db->query("INSERT INTO pages (page_name,title,content) VALUES ('$pageName','$title','$content')");
        setFlash('success','Page updated!');
        redirect(ADMIN_URL.'/pages.php');
    }
}

$pages = $db->query("SELECT * FROM pages ORDER BY page_name")->fetch_all(MYSQLI_ASSOC);

$extraCSS = '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.18/summernote-lite.min.css">';
$extraJS = '<script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.18/summernote-lite.min.js"></script>
<script>$(document).ready(function(){ $("#content").summernote({height:300}); });</script>';

include 'includes/header.php';
?>

<div style="display:grid;grid-template-columns:1fr 2fr;gap:24px;">
    <div>
        <div class="card">
            <div class="card-header"><div class="card-title">Pages</div></div>
            <div class="card-body" style="padding:0;">
                <?php foreach($pages as $p): ?>
                <a href="pages.php?edit=<?php echo $p['page_name']; ?>" style="display:flex;justify-content:space-between;align-items:center;padding:14px 18px;border-bottom:1px solid var(--border);transition:background 0.15s;<?php echo ($editPage&&$editPage['page_name']===$p['page_name'])?'background:var(--light);border-left:3px solid var(--primary);':''; ?>">
                    <div>
                        <div style="font-weight:600;font-size:14px;"><?php echo htmlspecialchars($p['title']); ?></div>
                        <div style="font-size:12px;color:var(--text-muted);"><?php echo $p['page_name']; ?></div>
                    </div>
                    <i class="fas fa-edit" style="color:var(--primary);"></i>
                </a>
                <?php endforeach; ?>
                <div style="padding:14px 18px;">
                    <a href="<?php echo SITE_URL; ?>/page.php?name=about" target="_blank" class="btn btn-info btn-sm" style="margin-right:6px;"><i class="fas fa-eye"></i> About</a>
                    <a href="<?php echo SITE_URL; ?>/page.php?name=contact" target="_blank" class="btn btn-info btn-sm"><i class="fas fa-eye"></i> Contact</a>
                </div>
            </div>
        </div>
    </div>
    
    <div>
        <?php if($editPage): ?>
        <div class="card">
            <div class="card-header"><div class="card-title">Edit: <?php echo htmlspecialchars($editPage['title']); ?></div></div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="page_name" value="<?php echo htmlspecialchars($editPage['page_name']); ?>">
                    <div class="form-group">
                        <label class="form-label">Page Title *</label>
                        <input type="text" name="title" class="form-control" value="<?php echo htmlspecialchars($editPage['title']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Content *</label>
                        <textarea name="content" id="content" class="form-control"><?php echo htmlspecialchars($editPage['content']); ?></textarea>
                    </div>
                    <div style="display:flex;gap:10px;">
                        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Changes</button>
                        <a href="pages.php" class="btn btn-secondary">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
        <?php else: ?>
        <div class="card">
            <div class="card-body" style="text-align:center;padding:60px;">
                <i class="fas fa-file-alt" style="font-size:48px;color:#ccc;margin-bottom:16px;display:block;"></i>
                <p style="color:var(--text-muted);">Select a page from the left to edit its content.</p>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
