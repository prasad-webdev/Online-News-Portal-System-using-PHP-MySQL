<?php
$db = getDB();

// Recent posts for sidebar
$recentPosts = $db->query("SELECT p.title, p.slug, p.image, p.created_at, c.name as cat_name FROM posts p LEFT JOIN categories c ON c.id=p.category_id WHERE p.status='published' AND p.deleted=0 ORDER BY p.created_at DESC LIMIT 6")->fetch_all(MYSQLI_ASSOC);

// Categories with count
$sideCats = $db->query("SELECT c.name, c.slug, COUNT(p.id) as cnt FROM categories c LEFT JOIN posts p ON p.category_id=c.id AND p.status='published' AND p.deleted=0 WHERE c.deleted=0 AND c.status=1 GROUP BY c.id ORDER BY cnt DESC")->fetch_all(MYSQLI_ASSOC);

// Popular posts (most views)
$popularPosts = $db->query("SELECT title, slug, views, image FROM posts WHERE status='published' AND deleted=0 ORDER BY views DESC LIMIT 5")->fetch_all(MYSQLI_ASSOC);

// Tags
$tagsResult = $db->query("SELECT tags FROM posts WHERE status='published' AND deleted=0 AND tags IS NOT NULL AND tags != '' LIMIT 30");
$allTags = [];
while($row = $tagsResult->fetch_assoc()) {
    $tags = array_map('trim', explode(',', $row['tags']));
    $allTags = array_merge($allTags, $tags);
}
$allTags = array_unique(array_filter($allTags));
?>

<!-- Categories Widget -->
<div class="sidebar-widget">
    <div class="sidebar-title"><i class="fas fa-list" style="color:var(--primary);margin-right:8px;"></i>Categories</div>
    <ul class="cat-list">
        <?php foreach($sideCats as $sc): ?>
        <li>
            <a href="<?php echo SITE_URL; ?>/category.php?slug=<?php echo $sc['slug']; ?>">
                <?php echo htmlspecialchars($sc['name']); ?>
            </a>
            <span class="cat-count"><?php echo $sc['cnt']; ?></span>
        </li>
        <?php endforeach; ?>
    </ul>
</div>

<!-- Recent Posts Widget -->
<div class="sidebar-widget">
    <div class="sidebar-title"><i class="fas fa-clock" style="color:var(--primary);margin-right:8px;"></i>Recent News</div>
    <?php foreach($recentPosts as $rp): ?>
    <div class="sidebar-news-item">
        <?php if($rp['image']): ?>
        <img src="<?php echo UPLOAD_URL . htmlspecialchars($rp['image']); ?>" alt="" class="sidebar-news-img">
        <?php else: ?>
        <div class="no-img-sm"><i class="fas fa-newspaper"></i></div>
        <?php endif; ?>
        <div>
            <div class="sidebar-news-title">
                <a href="<?php echo SITE_URL; ?>/post.php?slug=<?php echo $rp['slug']; ?>">
                    <?php echo htmlspecialchars($rp['title']); ?>
                </a>
            </div>
            <div class="sidebar-news-meta"><i class="far fa-clock"></i> <?php echo timeAgo($rp['created_at']); ?></div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<!-- Popular Posts Widget -->
<div class="sidebar-widget">
    <div class="sidebar-title"><i class="fas fa-fire" style="color:var(--primary);margin-right:8px;"></i>Popular Posts</div>
    <?php foreach($popularPosts as $i=>$pp): ?>
    <div class="sidebar-news-item">
        <div style="width:28px;height:28px;background:var(--primary);color:#fff;display:flex;align-items:center;justify-content:center;border-radius:50%;font-size:12px;font-weight:700;flex-shrink:0;"><?php echo $i+1; ?></div>
        <div>
            <div class="sidebar-news-title">
                <a href="<?php echo SITE_URL; ?>/post.php?slug=<?php echo $pp['slug']; ?>">
                    <?php echo htmlspecialchars($pp['title']); ?>
                </a>
            </div>
            <div class="sidebar-news-meta"><i class="fas fa-eye"></i> <?php echo number_format($pp['views']); ?> views</div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<!-- Tags Widget -->
<?php if(!empty($allTags)): ?>
<div class="sidebar-widget">
    <div class="sidebar-title"><i class="fas fa-tags" style="color:var(--primary);margin-right:8px;"></i>Tags</div>
    <div class="tags-cloud">
        <?php foreach(array_slice($allTags, 0, 20) as $tag): ?>
        <a href="<?php echo SITE_URL; ?>/search.php?q=<?php echo urlencode($tag); ?>" class="tag"><?php echo htmlspecialchars($tag); ?></a>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>
