<?php
// ============================================
// includes/sidebar.php - Complete Sidebar
// ============================================

$db = getDB();

// ===== WEATHER (PHP server-side fetch) =====
$weatherCity = 'Nashik';   // Change to your city
$weatherLat  = 19.9975;    // Change to your city latitude
$weatherLon  = 73.7898;    // Change to your city longitude

$weatherData  = null;
$apiUrl = "https://api.open-meteo.com/v1/forecast?latitude={$weatherLat}&longitude={$weatherLon}&current_weather=true&hourly=relativehumidity_2m&timezone=auto";

$ctx = stream_context_create([
    'http' => [
        'timeout'         => 6,
        'follow_location' => true,
        'user_agent'      => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
    ],
    'ssl' => [
        'verify_peer'      => false,
        'verify_peer_name' => false
    ]
]);

$response = @file_get_contents($apiUrl, false, $ctx);
if ($response) {
    $weatherData = json_decode($response, true);
}

$weatherIcons = [
    0  => 'fa-sun',              1  => 'fa-sun',
    2  => 'fa-cloud-sun',        3  => 'fa-cloud',
    45 => 'fa-smog',             48 => 'fa-smog',
    51 => 'fa-cloud-drizzle',    53 => 'fa-cloud-drizzle',    55 => 'fa-cloud-drizzle',
    61 => 'fa-cloud-rain',       63 => 'fa-cloud-rain',       65 => 'fa-cloud-showers-heavy',
    71 => 'fa-snowflake',        73 => 'fa-snowflake',        75 => 'fa-snowflake',
    80 => 'fa-cloud-rain',       81 => 'fa-cloud-rain',       82 => 'fa-cloud-showers-heavy',
    95 => 'fa-bolt',             96 => 'fa-bolt',             99 => 'fa-bolt'
];
$weatherDescs = [
    0  => 'Clear Sky',       1  => 'Mainly Clear',    2  => 'Partly Cloudy',
    3  => 'Overcast',        45 => 'Foggy',           48 => 'Foggy',
    51 => 'Light Drizzle',   53 => 'Mod. Drizzle',    55 => 'Dense Drizzle',
    61 => 'Slight Rain',     63 => 'Moderate Rain',   65 => 'Heavy Rain',
    71 => 'Light Snow',      73 => 'Moderate Snow',   75 => 'Heavy Snow',
    80 => 'Rain Showers',    81 => 'Rain Showers',    82 => 'Heavy Showers',
    95 => 'Thunderstorm',    96 => 'Thunderstorm',    99 => 'Thunderstorm'
];
?>

<!-- ===== WEATHER WIDGET ===== -->
<div class="sidebar-widget">
    <div class="sidebar-title">
        <i class="fas fa-cloud-sun" style="color:var(--primary);margin-right:8px;"></i>Weather
    </div>

    <?php if ($weatherData && isset($weatherData['current_weather'])): ?>
    <?php
        $w        = $weatherData['current_weather'];
        $temp     = round($w['temperature']);
        $wind     = round($w['windspeed']);
        $code     = $w['weathercode'];
        $isDay    = $w['is_day'] ?? 1;
        $icon     = $weatherIcons[$code] ?? 'fa-cloud';
        $desc     = $weatherDescs[$code] ?? 'Unknown';
        $humidity = $weatherData['hourly']['relativehumidity_2m'][0] ?? '--';
        // Night clear sky → moon icon
        if ($code === 0 && !$isDay) $icon = 'fa-moon';
        // Color based on temp
        $tempColor = $temp >= 35 ? '#e74c3c' : ($temp >= 25 ? '#f39c12' : ($temp >= 15 ? '#27ae60' : '#3498db'));
    ?>
    <div style="text-align:center;padding:10px 0 16px;">
        <i class="fas <?php echo $icon; ?>"
           style="font-size:54px;color:var(--primary);margin-bottom:10px;display:block;"></i>

        <div style="font-size:46px;font-weight:800;color:<?php echo $tempColor; ?>;line-height:1;">
            <?php echo $temp; ?>°C
        </div>

        <div style="font-size:14px;color:var(--text-muted);margin:6px 0 4px;">
            <?php echo $desc; ?>
        </div>

        <div style="font-size:13px;font-weight:600;color:var(--secondary);margin-bottom:16px;">
            <i class="fas fa-map-marker-alt" style="color:var(--primary);margin-right:4px;"></i>
            <?php echo htmlspecialchars($weatherCity); ?>
        </div>

        <div style="display:flex;justify-content:center;gap:20px;padding:12px 0;
                    border-top:1px solid var(--border);border-bottom:1px solid var(--border);">
            <div style="text-align:center;">
                <i class="fas fa-wind" style="color:var(--primary);font-size:18px;"></i>
                <div style="font-size:11px;color:var(--text-muted);margin-top:4px;">Wind</div>
                <div style="font-size:13px;font-weight:700;"><?php echo $wind; ?> km/h</div>
            </div>
            <div style="text-align:center;">
                <i class="fas fa-tint" style="color:#3498db;font-size:18px;"></i>
                <div style="font-size:11px;color:var(--text-muted);margin-top:4px;">Humidity</div>
                <div style="font-size:13px;font-weight:700;"><?php echo $humidity; ?>%</div>
            </div>
            <div style="text-align:center;">
                <i class="fas fa-thermometer-half" style="color:#e74c3c;font-size:18px;"></i>
                <div style="font-size:11px;color:var(--text-muted);margin-top:4px;">Feels Like</div>
                <div style="font-size:13px;font-weight:700;"><?php echo ($temp - 2); ?>°C</div>
            </div>
        </div>

        <div style="font-size:11px;color:var(--text-muted);margin-top:10px;">
            <i class="fas fa-sync-alt" style="margin-right:4px;"></i>
            Updated: <?php echo date('g:i A'); ?>
        </div>
    </div>

    <?php else: ?>
    <!-- API failed fallback -->
    <div style="text-align:center;padding:20px 0;">
        <i class="fas fa-cloud-slash" style="font-size:40px;color:#ccc;margin-bottom:10px;display:block;"></i>
        <div style="font-size:13px;color:var(--text-muted);">
            <?php echo htmlspecialchars($weatherCity); ?>
        </div>
        <div style="font-size:12px;color:#e74c3c;margin-top:10px;line-height:1.6;">
            <i class="fas fa-exclamation-circle"></i> Weather unavailable<br>
            <span style="color:var(--text-muted);font-size:11px;">Check your internet or enable<br>allow_url_fopen in php.ini</span>
        </div>
    </div>
    <?php endif; ?>
</div>


<?php
// ===== POPULAR POSTS WIDGET =====
$popular = $db->query("SELECT title, slug, image, views, created_at
                        FROM posts
                        WHERE status='published' AND deleted=0
                        ORDER BY views DESC LIMIT 5");
$popularPosts = $popular->fetch_all(MYSQLI_ASSOC);
?>
<?php if (!empty($popularPosts)): ?>
<div class="sidebar-widget">
    <div class="sidebar-title">
        <i class="fas fa-fire" style="color:var(--primary);margin-right:8px;"></i>Popular Posts
    </div>
    <?php foreach ($popularPosts as $i => $pp): ?>
    <div style="display:flex;gap:12px;align-items:flex-start;
                <?php echo $i < count($popularPosts)-1 ? 'margin-bottom:14px;padding-bottom:14px;border-bottom:1px solid var(--border);' : ''; ?>">
        <div style="font-size:22px;font-weight:800;color:var(--primary);
                    opacity:0.3;min-width:28px;line-height:1;margin-top:2px;">
            <?php echo str_pad($i+1, 2, '0', STR_PAD_LEFT); ?>
        </div>
        <div style="flex:1;">
            <a href="<?php echo SITE_URL; ?>/post.php?slug=<?php echo $pp['slug']; ?>"
               style="font-size:13px;font-weight:600;color:var(--secondary);line-height:1.4;display:block;
                      transition:color 0.2s;"
               onmouseover="this.style.color='var(--primary)'"
               onmouseout="this.style.color='var(--secondary)'">
                <?php echo htmlspecialchars($pp['title']); ?>
            </a>
            <div style="font-size:11px;color:var(--text-muted);margin-top:4px;">
                <i class="fas fa-eye" style="margin-right:3px;"></i><?php echo number_format($pp['views']); ?> views
                &nbsp;·&nbsp;
                <i class="far fa-clock" style="margin-right:3px;"></i><?php echo timeAgo($pp['created_at']); ?>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>


<?php
// ===== POLL WIDGET =====
$poll = $db->query("SELECT * FROM polls WHERE status='active' ORDER BY created_at DESC LIMIT 1")->fetch_assoc();
if ($poll):
    $pollOptions = $db->query("SELECT * FROM poll_options WHERE poll_id={$poll['id']} ORDER BY id ASC")->fetch_all(MYSQLI_ASSOC);
    $totalVotes  = array_sum(array_column($pollOptions, 'votes'));
    $voterIp     = $_SERVER['REMOTE_ADDR'];
    $hasVoted    = $db->query("SELECT id FROM poll_votes WHERE poll_id={$poll['id']} AND voter_ip='$voterIp'")->num_rows > 0;
?>
<div class="sidebar-widget" id="pollWidget">
    <div class="sidebar-title">
        <i class="fas fa-poll" style="color:var(--primary);margin-right:8px;"></i>Poll
    </div>

    <p style="font-size:14px;font-weight:600;color:var(--secondary);margin-bottom:14px;line-height:1.5;">
        <?php echo htmlspecialchars($poll['question']); ?>
    </p>

    <?php if (!$hasVoted): ?>
    <!-- Vote Form -->
    <div id="pollVoteForm">
        <?php foreach ($pollOptions as $opt): ?>
        <label style="display:flex;align-items:center;gap:10px;padding:9px 12px;
                      border:2px solid var(--border);border-radius:6px;margin-bottom:8px;
                      cursor:pointer;transition:border-color 0.2s,background 0.2s;font-size:14px;"
               onmouseover="this.style.borderColor='var(--primary)';this.style.background='#fff5f5'"
               onmouseout="this.style.borderColor='var(--border)';this.style.background='transparent'">
            <input type="radio" name="poll_option"
                   value="<?php echo $opt['id']; ?>"
                   style="accent-color:var(--primary);width:16px;height:16px;">
            <?php echo htmlspecialchars($opt['option_text']); ?>
        </label>
        <?php endforeach; ?>

        <button onclick="submitPoll(<?php echo $poll['id']; ?>)"
                style="width:100%;margin-top:6px;padding:11px;background:var(--primary);
                       color:#fff;border:none;border-radius:6px;font-size:14px;font-weight:600;
                       cursor:pointer;transition:background 0.2s;font-family:inherit;"
                onmouseover="this.style.opacity='0.85'"
                onmouseout="this.style.opacity='1'">
            <i class="fas fa-vote-yea"></i> Vote Now
        </button>
    </div>
    <?php endif; ?>

    <!-- Results (shown after voting OR if already voted) -->
    <div id="pollResults" <?php echo $hasVoted ? '' : 'style="display:none;"'; ?>>
        <?php foreach ($pollOptions as $opt):
            $pct = $totalVotes > 0 ? round(($opt['votes'] / $totalVotes) * 100) : 0;
        ?>
        <div style="margin-bottom:12px;">
            <div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:5px;">
                <span style="color:var(--secondary);font-weight:500;">
                    <?php echo htmlspecialchars($opt['option_text']); ?>
                </span>
                <strong style="color:var(--primary);"><?php echo $pct; ?>%</strong>
            </div>
            <div style="height:8px;background:#f0f0f0;border-radius:4px;overflow:hidden;">
                <div style="height:100%;width:<?php echo $pct; ?>%;background:var(--primary);
                            border-radius:4px;transition:width 1s ease;"></div>
            </div>
            <div style="font-size:11px;color:var(--text-muted);margin-top:3px;">
                <?php echo number_format($opt['votes']); ?> votes
            </div>
        </div>
        <?php endforeach; ?>
        <div style="text-align:center;font-size:12px;color:var(--text-muted);
                    margin-top:10px;padding-top:10px;border-top:1px solid var(--border);">
            <i class="fas fa-users" style="margin-right:4px;"></i>
            Total: <strong><?php echo number_format($totalVotes); ?></strong> votes
        </div>
    </div>
</div>
<?php endif; ?>


<!-- ===== NEWSLETTER WIDGET ===== -->
<div class="sidebar-widget">
    <div class="sidebar-title">
        <i class="fas fa-envelope-open-text" style="color:var(--primary);margin-right:8px;"></i>Newsletter
    </div>
    <p style="font-size:13px;color:var(--text-muted);margin-bottom:14px;line-height:1.6;">
        Get the latest news delivered directly to your inbox. No spam, ever!
    </p>
    <div id="newsletterForm">
        <input type="text" id="nlName" placeholder="Your name (optional)"
               style="width:100%;padding:9px 12px;border:2px solid var(--border);
                      border-radius:6px;font-size:13px;outline:none;margin-bottom:8px;
                      font-family:inherit;box-sizing:border-box;transition:border-color 0.2s;"
               onfocus="this.style.borderColor='var(--primary)'"
               onblur="this.style.borderColor='var(--border)'">
        <input type="email" id="nlEmail" placeholder="Your email address *"
               style="width:100%;padding:9px 12px;border:2px solid var(--border);
                      border-radius:6px;font-size:13px;outline:none;margin-bottom:8px;
                      font-family:inherit;box-sizing:border-box;transition:border-color 0.2s;"
               onfocus="this.style.borderColor='var(--primary)'"
               onblur="this.style.borderColor='var(--border)'">
        <button onclick="subscribeNewsletter()"
                style="width:100%;padding:11px;background:var(--primary);color:#fff;
                       border:none;border-radius:6px;font-size:14px;font-weight:600;
                       cursor:pointer;transition:opacity 0.2s;font-family:inherit;"
                onmouseover="this.style.opacity='0.85'"
                onmouseout="this.style.opacity='1'">
            <i class="fas fa-paper-plane"></i> Subscribe Free
        </button>
    </div>
    <div id="newsletterMsg" style="display:none;"></div>
</div>


<!-- ===== SOCIAL MEDIA WIDGET ===== -->
<div class="sidebar-widget">
    <div class="sidebar-title">
        <i class="fas fa-share-alt" style="color:var(--primary);margin-right:8px;"></i>Follow Us
    </div>
    <div style="display:flex;flex-direction:column;gap:10px;">
        <a href="#" style="display:flex;align-items:center;justify-content:space-between;
                           padding:10px 14px;background:#1877f2;color:#fff;border-radius:6px;
                           font-size:13px;font-weight:600;transition:opacity 0.2s;"
           onmouseover="this.style.opacity='0.85'" onmouseout="this.style.opacity='1'">
            <span><i class="fab fa-facebook-f" style="margin-right:8px;width:16px;"></i>Facebook</span>
            <span style="font-size:12px;opacity:0.85;background:rgba(0,0,0,0.15);padding:2px 8px;border-radius:10px;">12.5K</span>
        </a>
        <a href="#" style="display:flex;align-items:center;justify-content:space-between;
                           padding:10px 14px;background:#1da1f2;color:#fff;border-radius:6px;
                           font-size:13px;font-weight:600;transition:opacity 0.2s;"
           onmouseover="this.style.opacity='0.85'" onmouseout="this.style.opacity='1'">
            <span><i class="fab fa-twitter" style="margin-right:8px;width:16px;"></i>Twitter</span>
            <span style="font-size:12px;opacity:0.85;background:rgba(0,0,0,0.15);padding:2px 8px;border-radius:10px;">8.2K</span>
        </a>
        <a href="#" style="display:flex;align-items:center;justify-content:space-between;
                           padding:10px 14px;background:linear-gradient(135deg,#f09433,#e6683c,#dc2743,#cc2366,#bc1888);
                           color:#fff;border-radius:6px;font-size:13px;font-weight:600;transition:opacity 0.2s;"
           onmouseover="this.style.opacity='0.85'" onmouseout="this.style.opacity='1'">
            <span><i class="fab fa-instagram" style="margin-right:8px;width:16px;"></i>Instagram</span>
            <span style="font-size:12px;opacity:0.85;background:rgba(0,0,0,0.15);padding:2px 8px;border-radius:10px;">15.1K</span>
        </a>
        <a href="#" style="display:flex;align-items:center;justify-content:space-between;
                           padding:10px 14px;background:#ff0000;color:#fff;border-radius:6px;
                           font-size:13px;font-weight:600;transition:opacity 0.2s;"
           onmouseover="this.style.opacity='0.85'" onmouseout="this.style.opacity='1'">
            <span><i class="fab fa-youtube" style="margin-right:8px;width:16px;"></i>YouTube</span>
            <span style="font-size:12px;opacity:0.85;background:rgba(0,0,0,0.15);padding:2px 8px;border-radius:10px;">5.8K</span>
        </a>
        <a href="#" style="display:flex;align-items:center;justify-content:space-between;
                           padding:10px 14px;background:#25d366;color:#fff;border-radius:6px;
                           font-size:13px;font-weight:600;transition:opacity 0.2s;"
           onmouseover="this.style.opacity='0.85'" onmouseout="this.style.opacity='1'">
            <span><i class="fab fa-whatsapp" style="margin-right:8px;width:16px;"></i>WhatsApp</span>
            <span style="font-size:12px;opacity:0.85;background:rgba(0,0,0,0.15);padding:2px 8px;border-radius:10px;">Join</span>
        </a>
    </div>
</div>


<!-- ===== TAGS WIDGET ===== -->
<?php
$tagsResult = $db->query("SELECT tags FROM posts WHERE status='published' AND deleted=0 AND tags IS NOT NULL AND tags != '' LIMIT 30");
$allTags = [];
while ($row = $tagsResult->fetch_assoc()) {
    $tags = array_map('trim', explode(',', $row['tags']));
    foreach ($tags as $tag) {
        if ($tag) $allTags[] = $tag;
    }
}
$allTags = array_unique($allTags);
sort($allTags);
?>
<?php if (!empty($allTags)): ?>
<div class="sidebar-widget">
    <div class="sidebar-title">
        <i class="fas fa-tags" style="color:var(--primary);margin-right:8px;"></i>Popular Tags
    </div>
    <div style="display:flex;flex-wrap:wrap;gap:8px;">
        <?php foreach ($allTags as $tag): ?>
        <a href="<?php echo SITE_URL; ?>/search.php?q=<?php echo urlencode($tag); ?>"
           style="display:inline-block;padding:5px 12px;background:var(--light-bg);
                  color:var(--secondary);border:1px solid var(--border);border-radius:20px;
                  font-size:12px;font-weight:500;transition:all 0.2s;"
           onmouseover="this.style.background='var(--primary)';this.style.color='#fff';this.style.borderColor='var(--primary)'"
           onmouseout="this.style.background='var(--light-bg)';this.style.color='var(--secondary)';this.style.borderColor='var(--border)'">
            <?php echo htmlspecialchars($tag); ?>
        </a>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>


<script>
// ===== POLL VOTE =====
function submitPoll(pollId) {
    var selected = document.querySelector('input[name="poll_option"]:checked');
    if (!selected) {
        alert('Please select an option first.');
        return;
    }

    $.ajax({
        url: '<?php echo SITE_URL; ?>/poll-vote.php',
        type: 'POST',
        data: { poll_id: pollId, option_id: selected.value },
        dataType: 'json',
        success: function(res) {
            if (res.success) {
                var html = '';
                var total = res.total;
                $.each(res.options, function(i, opt) {
                    var pct = total > 0 ? Math.round((opt.votes / total) * 100) : 0;
                    html +=
                        '<div style="margin-bottom:12px;">' +
                        '<div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:5px;">' +
                        '<span style="color:var(--secondary);font-weight:500;">' + opt.option_text + '</span>' +
                        '<strong style="color:var(--primary);">' + pct + '%</strong>' +
                        '</div>' +
                        '<div style="height:8px;background:#f0f0f0;border-radius:4px;overflow:hidden;">' +
                        '<div style="height:100%;width:' + pct + '%;background:var(--primary);border-radius:4px;transition:width 1s ease;"></div>' +
                        '</div>' +
                        '<div style="font-size:11px;color:#888;margin-top:3px;">' + opt.votes + ' votes</div>' +
                        '</div>';
                });
                html +=
                    '<div style="text-align:center;font-size:12px;color:#888;margin-top:10px;' +
                    'padding-top:10px;border-top:1px solid #eee;">' +
                    '<i class="fas fa-users"></i> Total: <strong>' + total + '</strong> votes</div>';

                $('#pollVoteForm').slideUp(200, function() {
                    $('#pollResults').html(html).slideDown(300);
                });
            } else {
                if (res.already_voted) {
                    $('#pollVoteForm').slideUp(200);
                    $('#pollResults').slideDown(300);
                } else {
                    alert(res.message);
                }
            }
        },
        error: function() {
            alert('Something went wrong. Please try again.');
        }
    });
}

// ===== NEWSLETTER SUBSCRIBE =====
function subscribeNewsletter() {
    var name  = $('#nlName').val().trim();
    var email = $('#nlEmail').val().trim();

    if (!email) {
        alert('Please enter your email address.');
        return;
    }

    var btn = event.target;
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Subscribing...';

    $.ajax({
        url: '<?php echo SITE_URL; ?>/newsletter-subscribe.php',
        type: 'POST',
        data: { name: name, email: email },
        dataType: 'json',
        success: function(res) {
            $('#newsletterForm').hide();
            var color = res.success ? '#27ae60' : '#e74c3c';
            var icon  = res.success ? 'fa-check-circle' : 'fa-exclamation-circle';
            $('#newsletterMsg').html(
                '<div style="text-align:center;padding:16px;">' +
                '<i class="fas ' + icon + '" style="font-size:36px;color:' + color + ';margin-bottom:10px;display:block;"></i>' +
                '<p style="font-size:13px;color:' + color + ';font-weight:600;line-height:1.5;">' + res.message + '</p>' +
                '</div>'
            ).show();
            if (!res.success) {
                setTimeout(function() {
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fas fa-paper-plane"></i> Subscribe Free';
                    $('#newsletterForm').show();
                    $('#newsletterMsg').hide();
                }, 3000);
            }
        },
        error: function() {
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-paper-plane"></i> Subscribe Free';
            alert('Something went wrong. Please try again.');
        }
    });
}
</script>