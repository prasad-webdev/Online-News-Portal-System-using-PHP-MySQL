<?php
require_once __DIR__ . '/../includes/config.php';
$db = getDB();

$cats     = $db->query("SELECT * FROM categories WHERE deleted=0 AND status=1 ORDER BY name ASC");
$categories = $cats->fetch_all(MYSQLI_ASSOC);

$breaking     = $db->query("SELECT title, slug FROM posts WHERE status='published' AND deleted=0 ORDER BY created_at DESC LIMIT 8");
$breakingPosts = $breaking->fetch_all(MYSQLI_ASSOC);

$currentPage = basename($_SERVER['PHP_SELF'], '.php');

// Notifications for logged in users
$unreadCount = 0;
$notifications = [];
if(isset($_SESSION['user_id'])) {
    $userId = intval($_SESSION['user_id']);
    $notifResult = $db->query("SELECT n.* FROM notifications n WHERE n.is_active=1 ORDER BY n.created_at DESC LIMIT 10");
    $notifications = $notifResult->fetch_all(MYSQLI_ASSOC);
    $readResult = $db->query("SELECT notification_id FROM user_notifications WHERE user_id=$userId AND is_read=1");
    $readIds = array_column($readResult->fetch_all(MYSQLI_ASSOC), 'notification_id');
    foreach($notifications as $n) {
        if(!in_array($n['id'], $readIds)) $unreadCount++;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? htmlspecialchars($pageTitle) . ' | ' . SITE_NAME : SITE_NAME; ?></title>
    <meta name="description" content="<?php echo isset($metaDesc) ? htmlspecialchars($metaDesc) : 'Your trusted source for the latest news'; ?>">
    <meta name="site-url" content="<?php echo SITE_URL; ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/style.css">

    <script>
        if (localStorage.getItem('darkMode') === 'enabled') {
            document.documentElement.classList.add('dark-mode-pre');
        }
    </script>

    <style>
        /* Force dropdown visibility when open */
.notif-dropdown.open,
.user-dropdown.open {
    display: block !important;
    animation: slideDown 0.2s ease;
}

/* Make sure user dropdown logout is red */
.user-dropdown a:last-child {
    color: #e74c3c !important;
}
.user-dropdown a:last-child:hover {
    background: #fff5f5 !important;
}

/* Dark mode user dropdown */
body.dark-mode .user-dropdown a:last-child {
    color: #ff6b6b !important;
}
        html.dark-mode-pre body { background: #0f1117 !important; }

        /* ===== GOOGLE TRANSLATE ===== */
        .goog-te-banner-frame, #goog-gt-tt,
        .goog-te-balloon-frame, div#goog-gt- { display: none !important; }
        .skiptranslate { display: none !important; }
        body { top: 0 !important; position: static !important; }
        font { background-color: transparent !important; box-shadow: none !important; }

        /* ===== LANGUAGE SELECTOR ===== */

        
        .lang-selector-wrap { display:flex;align-items:center;gap:6px; }
        .lang-selector-wrap i { color:#aaa;font-size:14px; }
        #langSelect {
            background: rgba(255,255,255,0.1);
            border: 1px solid rgba(255,255,255,0.35);
            border-radius: 4px; color: #fff;
            font-size: 12px; padding: 4px 6px;
            cursor: pointer; outline: none;
            max-width: 140px; transition: border-color 0.2s;
        }
        #langSelect:hover { border-color: rgba(255,255,255,0.7); }
        #langSelect option { background: #2c3e50; color: #fff; }
        body.dark-mode #langSelect { background:#252836;border-color:#3a3d4e;color:#ccc; }
        body.dark-mode #langSelect option { background:#1a1d27;color:#ccc; }

        /* ===== DARK MODE TOGGLE ===== */
        #darkModeToggle {
            background: none;
            border: 2px solid rgba(255,255,255,0.3);
            color: #999; width: 34px; height: 34px;
            border-radius: 50%; cursor: pointer;
            font-size: 15px; display: flex;
            align-items: center; justify-content: center;
            transition: all 0.2s; flex-shrink: 0; padding: 0;
        }
        #darkModeToggle:hover { border-color: var(--primary); color: var(--primary); }
        body.dark-mode #darkModeToggle { border-color: rgba(255,255,255,0.2); color: #f1c40f; }

        /* ===== NOTIFICATION BELL ===== */
        .notif-wrap { position: relative; }
        #notifBtn {
            background: none;
            border: 2px solid var(--border);
            color: var(--secondary); width: 36px; height: 36px;
            border-radius: 50%; cursor: pointer; font-size: 15px;
            display: flex; align-items: center; justify-content: center;
            transition: all 0.2s; position: relative;
        }
        #notifBtn:hover { border-color: var(--primary); color: var(--primary); }
        .notif-badge {
            position: absolute; top: -4px; right: -4px;
            background: var(--primary); color: #fff;
            font-size: 10px; font-weight: 700;
            width: 18px; height: 18px; border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            border: 2px solid #fff;
        }
        .notif-dropdown {
            display: none;
            position: absolute; top: calc(100% + 10px); right: 0;
            width: 320px; background: #fff;
            border-radius: 10px; box-shadow: 0 10px 40px rgba(0,0,0,0.15);
            z-index: 9999; overflow: hidden;
            border: 1px solid var(--border);
        }
        .notif-dropdown.open { display: block; animation: slideDown 0.2s ease; }
        @keyframes slideDown { from { opacity:0;transform:translateY(-8px); } to { opacity:1;transform:translateY(0); } }
        .notif-header {
            padding: 14px 16px;
            background: var(--secondary); color: #fff;
            display: flex; justify-content: space-between; align-items: center;
            font-weight: 700; font-size: 14px;
        }
        .notif-item {
            padding: 12px 16px;
            border-bottom: 1px solid var(--border);
            display: flex; gap: 10px; align-items: flex-start;
            transition: background 0.15s; cursor: pointer;
        }
        .notif-item:hover { background: var(--light-bg); }
        .notif-item.unread { background: #fff8f8; border-left: 3px solid var(--primary); }
        .notif-icon {
            width: 34px; height: 34px; border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            font-size: 14px; flex-shrink: 0; color: #fff;
        }
        .notif-icon.breaking { background: var(--primary); }
        .notif-icon.info     { background: #3498db; }
        .notif-icon.success  { background: #27ae60; }
        .notif-icon.warning  { background: #f39c12; }
        .notif-title { font-size: 13px; font-weight: 600; color: var(--secondary); }
        .notif-msg   { font-size: 12px; color: var(--text-muted); margin-top: 2px; line-height: 1.4; }
        .notif-empty { padding: 30px; text-align: center; color: var(--text-muted); font-size: 13px; }
        body.dark-mode .notif-dropdown { background:#1a1d27;border-color:#2a2d3e; }
        body.dark-mode .notif-item { border-bottom-color:#2a2d3e; }
        body.dark-mode .notif-item:hover { background:#252836; }
        body.dark-mode .notif-item.unread { background:#1f1a1a;border-left-color:var(--primary); }
        body.dark-mode .notif-title { color:#ddd; }
        body.dark-mode #notifBtn { border-color:#3a3d4e;color:#ccc; }

        /* ===== USER MENU ===== */
        .user-menu-wrap { position: relative; }
        .user-menu-btn {
            display: flex; align-items: center; gap: 8px;
            background: none; border: 2px solid var(--border);
            border-radius: 25px; padding: 5px 12px 5px 5px;
            cursor: pointer; transition: all 0.2s; font-family: inherit;
        }
        .user-menu-btn:hover { border-color: var(--primary); }
        .user-avatar-sm {
            width: 28px; height: 28px; background: var(--primary);
            color: #fff; border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            font-size: 12px; font-weight: 700;
        }
        .user-menu-name { font-size: 13px; font-weight: 600; color: var(--secondary); }
        .user-dropdown {
            display: none;
            position: absolute; top: calc(100% + 8px); right: 0;
            background: #fff; border-radius: 8px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.15);
            z-index: 9999; min-width: 180px;
            border: 1px solid var(--border); overflow: hidden;
        }
        .user-dropdown.open { display: block; animation: slideDown 0.2s ease; }
        .user-dropdown a {
            display: flex; align-items: center; gap: 10px;
            padding: 11px 16px; font-size: 13px; color: var(--secondary);
            border-bottom: 1px solid var(--border); transition: background 0.15s;
        }
        .user-dropdown a:hover { background: var(--light-bg); color: var(--primary); }
        .user-dropdown a:last-child { border-bottom: none; color: #e74c3c; }
        .user-dropdown a i { width: 16px; text-align: center; }
        body.dark-mode .user-menu-btn { border-color:#3a3d4e; }
        body.dark-mode .user-menu-name { color:#ddd; }
        body.dark-mode .user-dropdown { background:#1a1d27;border-color:#2a2d3e; }
        body.dark-mode .user-dropdown a { color:#ddd;border-bottom-color:#2a2d3e; }
        body.dark-mode .user-dropdown a:hover { background:#252836; }

        /* ===== HAMBURGER MENU ===== */
        #hamburger {
            display: none;
            background: none; border: none;
            font-size: 22px; cursor: pointer;
            color: #fff; padding: 6px;
        }
        .mobile-nav-overlay {
            display: none;
            position: fixed; top:0;left:0;right:0;bottom:0;
            background: rgba(0,0,0,0.5); z-index: 8888;
        }
        .mobile-nav-overlay.open { display: block; }
        .mobile-nav {
            position: fixed; top:0;left:-280px;bottom:0;
            width: 280px; background: var(--secondary);
            z-index: 8999; transition: left 0.3s ease;
            overflow-y: auto; display: flex; flex-direction: column;
        }
        .mobile-nav.open { left: 0; }
        .mobile-nav-header {
            padding: 20px 16px;
            background: #1a252f;
            display: flex; justify-content: space-between; align-items: center;
        }
        .mobile-nav-logo { font-size: 20px; font-weight: 800; color: #fff; }
        .mobile-nav-logo span { color: var(--primary); }
        .mobile-nav-close {
            background: rgba(255,255,255,0.1); border: none;
            color: #fff; width: 32px; height: 32px; border-radius: 50%;
            cursor: pointer; font-size: 16px;
        }
        .mobile-nav-links { padding: 12px 0; flex: 1; }
        .mobile-nav-links a {
            display: flex; align-items: center; gap: 12px;
            padding: 13px 20px; color: #ccc; font-size: 14px;
            font-weight: 500; border-bottom: 1px solid rgba(255,255,255,0.05);
            transition: all 0.15s;
        }
        .mobile-nav-links a:hover { background: rgba(255,255,255,0.08); color: #fff; padding-left: 26px; }
        .mobile-nav-links a i { width: 18px; text-align: center; color: var(--primary); }
        .mobile-nav-section {
            font-size: 10px; text-transform: uppercase; letter-spacing: 1.5px;
            color: #607d8b; padding: 12px 20px 4px; font-weight: 700;
        }
        .mobile-nav-user {
            padding: 16px 20px;
            background: #1a252f;
            border-top: 1px solid rgba(255,255,255,0.08);
        }
        .mobile-nav-user a {
            display: flex; align-items: center; gap: 10px;
            color: #ccc; font-size: 13px; margin-bottom: 8px;
        }

        /* ===== SEARCH SUGGESTIONS DARK ===== */
        body.dark-mode #searchSuggestions { background:#1e2130 !important;border-color:#3a3d4e !important; }
        body.dark-mode #searchSuggestions a { color:#ccc;display:block;padding:8px 14px;border-bottom:1px solid #2a2d3e;font-size:13px; }
        body.dark-mode #searchSuggestions a:hover { background:#252836;color:#fff; }

        /* ===== TRANSLATE STATUS ===== */
        #translateStatus { font-size:11px;color:#aaa;display:none;align-items:center;gap:4px; }
        #translateStatus.show { display:flex; }
        @keyframes spin { to { transform:rotate(360deg); } }
        #translateStatus i { animation:spin 1s linear infinite; }

        /* ===== RESPONSIVE ===== */
        @media (max-width: 900px) {
            #hamburger { display: flex !important; align-items:center;justify-content:center; }
            .main-nav > .container > ul { display: none !important; }
        }
    </style>

    <!-- Google Translate Hidden -->
    <div id="google_translate_element" style="display:none;visibility:hidden;"></div>
    <script>
        function googleTranslateElementInit() {
            new google.translate.TranslateElement({ pageLanguage:'en', autoDisplay:false }, 'google_translate_element');
        }
        function translatePage(langCode) {
            if(langCode === 'en') {
                var exp = new Date(); exp.setTime(exp.getTime()-1);
                document.cookie = 'googtrans=; expires='+exp.toGMTString()+'; path=/';
                document.cookie = 'googtrans=; expires='+exp.toGMTString()+'; domain='+window.location.hostname+'; path=/';
                window.location.reload(); return;
            }
            var status = document.getElementById('translateStatus');
            if(status) status.classList.add('show');
            var cv = '/en/'+langCode;
            document.cookie = 'googtrans='+cv+'; path=/';
            document.cookie = 'googtrans='+cv+'; domain='+window.location.hostname+'; path=/';
            var attempts=0, interval=setInterval(function(){
                attempts++;
                var sel = document.querySelector('#google_translate_element select');
                if(sel){ sel.value=langCode; sel.dispatchEvent(new Event('change')); clearInterval(interval); if(status) status.classList.remove('show'); }
                if(attempts>30){ clearInterval(interval); window.location.reload(); }
            },100);
        }
        window.addEventListener('load', function(){
            var saved = localStorage.getItem('selectedLang');
            var sel   = document.getElementById('langSelect');
            if(saved && saved!=='en'){
                if(sel) sel.value = saved;
                if(document.cookie.indexOf('googtrans')===-1) translatePage(saved);
            }
        });
    </script>
    <script src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

</head>
<body>

<!-- Reading Progress Bar -->
<div id="readingProgress" style="position:fixed;top:0;left:0;height:3px;background:var(--primary);z-index:9999;width:0%;transition:width 0.1s;"></div>

<!-- Top Bar -->
<div class="top-bar">
    <div class="container">
        <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;">
            <span><i class="far fa-calendar-alt"></i> <?php echo date('l, F j, Y'); ?></span>
            <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap;">
                <div class="lang-selector-wrap">
                    <i class="fas fa-globe"></i>
                    <select id="langSelect" onchange="var l=this.value;localStorage.setItem('selectedLang',l);translatePage(l);">
                        <option value="en">🌐 English</option>
                        <option value="hi">🇮🇳 Hindi</option>
                        <option value="ur">🇵🇰 Urdu</option>
                        <option value="bn">🇧🇩 Bengali</option>
                        <option value="mr">🇮🇳 Marathi</option>
                        <option value="ta">🇮🇳 Tamil</option>
                        <option value="te">🇮🇳 Telugu</option>
                        <option value="gu">🇮🇳 Gujarati</option>
                        <option value="pa">🇮🇳 Punjabi</option>
                        <option value="ar">🇸🇦 Arabic</option>
                        <option value="fr">🇫🇷 French</option>
                        <option value="de">🇩🇪 German</option>
                        <option value="es">🇪🇸 Spanish</option>
                        <option value="pt">🇧🇷 Portuguese</option>
                        <option value="ru">🇷🇺 Russian</option>
                        <option value="zh-CN">🇨🇳 Chinese</option>
                        <option value="ja">🇯🇵 Japanese</option>
                        <option value="ko">🇰🇷 Korean</option>
                    </select>
                    <span id="translateStatus"><i class="fas fa-spinner"></i></span>
                </div>
                <a href="<?php echo SITE_URL; ?>/page.php?name=about"
                   style="color:#ccc;font-size:12px;" onmouseover="this.style.color='#fff'" onmouseout="this.style.color='#ccc'">About Us</a>
                <a href="<?php echo SITE_URL; ?>/page.php?name=contact"
                   style="color:#ccc;font-size:12px;" onmouseover="this.style.color='#fff'" onmouseout="this.style.color='#ccc'">Contact</a>
            </div>
        </div>
    </div>
</div>

<!-- Site Header -->
<header class="site-header">
    <div class="container">
        <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;">

            <!-- Logo -->
            <a href="<?php echo SITE_URL; ?>" class="site-logo">
                <i class="fas fa-newspaper"></i> News<span>Portal</span>
            </a>

            <!-- Right Controls -->
            <div style="display:flex;align-items:center;gap:10px;">

                <!-- Dark Mode Toggle -->
                <button id="darkModeToggle" title="Toggle Dark Mode">
                    <i class="fas fa-moon" id="darkModeIcon"></i>
                </button>

                <!-- Notification Bell (logged in users) -->
                <?php if(isset($_SESSION['user_id'])): ?>
                <div class="notif-wrap">
                    <button id="notifBtn" title="Notifications">
                        <i class="fas fa-bell"></i>
                        <?php if($unreadCount > 0): ?>
                        <span class="notif-badge"><?php echo $unreadCount; ?></span>
                        <?php endif; ?>
                    </button>
                    <div class="notif-dropdown" id="notifDropdown">
                        <div class="notif-header">
                            <span><i class="fas fa-bell"></i> Notifications</span>
                            <span style="font-size:12px;font-weight:400;opacity:0.8;"><?php echo $unreadCount; ?> unread</span>
                        </div>
                        <?php if(empty($notifications)): ?>
                        <div class="notif-empty"><i class="fas fa-bell-slash" style="font-size:28px;margin-bottom:8px;display:block;color:#ddd;"></i>No notifications</div>
                        <?php else: ?>
                        <?php foreach($notifications as $n): ?>
                        <?php $isUnread = !in_array($n['id'], $readIds ?? []); ?>
                        <div class="notif-item <?php echo $isUnread?'unread':''; ?>"
                             onclick="markRead(<?php echo $n['id']; ?>, '<?php echo $n['link'] ?? '#'; ?>')">
                            <div class="notif-icon <?php echo $n['type']; ?>">
                                <i class="fas fa-<?php echo $n['type']==='breaking'?'bolt':($n['type']==='success'?'check':($n['type']==='warning'?'exclamation':'info-circle')); ?>"></i>
                            </div>
                            <div>
                                <div class="notif-title"><?php echo htmlspecialchars($n['title']); ?></div>
                                <div class="notif-msg"><?php echo htmlspecialchars($n['message']); ?></div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>

                <!-- User Menu or Login Button -->
                <?php if(isset($_SESSION['user_id'])): ?>
                <div class="user-menu-wrap">
                    <button class="user-menu-btn" id="userMenuBtn">
                        <div class="user-avatar-sm">
                            <?php echo strtoupper(substr($_SESSION['user_name'],0,1)); ?>
                        </div>
                        <span class="user-menu-name"><?php echo htmlspecialchars(explode(' ',$_SESSION['user_name'])[0]); ?></span>
                        <i class="fas fa-chevron-down" style="font-size:10px;color:#aaa;"></i>
                    </button>
                    <div class="user-dropdown" id="userDropdown">
                        <a href="<?php echo SITE_URL; ?>/user-profile.php">
                            <i class="fas fa-user-circle"></i> My Profile
                        </a>
                        <a href="<?php echo SITE_URL; ?>/user-logout.php">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </div>
                </div>
                <?php else: ?>
                <a href="<?php echo SITE_URL; ?>/user-login.php"
                   style="display:inline-flex;align-items:center;gap:6px;padding:8px 16px;background:var(--primary);color:#fff;border-radius:20px;font-size:13px;font-weight:600;transition:background 0.2s;">
                    <i class="fas fa-sign-in-alt"></i> Login
                </a>
                <?php endif; ?>

                <!-- Search Form -->
                <form class="header-search" action="<?php echo SITE_URL; ?>/search.php" method="GET" style="position:relative;">
                    <input type="text" id="headerSearch" name="q" placeholder="Search news..."
                           value="<?php echo isset($_GET['q']) ? htmlspecialchars($_GET['q']) : ''; ?>">
                    <button type="submit"><i class="fas fa-search"></i></button>
                    <div id="searchSuggestions"
                         style="position:absolute;top:100%;left:0;right:40px;background:#fff;border:1px solid var(--border);box-shadow:var(--shadow-hover);z-index:999;display:none;border-radius:0 0 6px 6px;">
                    </div>
                </form>

            </div>
        </div>
    </div>
</header>

<!-- Main Navigation -->
<nav class="main-nav">
    <div class="container" style="display:flex;align-items:center;justify-content:space-between;">
        <ul id="mainNavList">
            <li>
                <a href="<?php echo SITE_URL; ?>" class="<?php echo $currentPage=='index'?'active':''; ?>">
                    <i class="fas fa-home"></i> Home
                </a>
            </li>
            <?php foreach($categories as $cat): ?>
            <?php
                $subs   = $db->query("SELECT * FROM subcategories WHERE category_id={$cat['id']} AND deleted=0 AND status=1 ORDER BY name ASC");
                $subcats = $subs->fetch_all(MYSQLI_ASSOC);
            ?>
            <li class="<?php echo count($subcats)?'dropdown':''; ?>">
                <a href="<?php echo count($subcats)?'#':SITE_URL.'/category.php?slug='.$cat['slug']; ?>"
                   class="<?php echo (isset($_GET['slug'])&&$_GET['slug']==$cat['slug'])?'active':''; ?>">
                    <?php echo htmlspecialchars($cat['name']); ?>
                    <?php if(count($subcats)): ?><i class="fas fa-chevron-down" style="font-size:10px;margin-left:4px;"></i><?php endif; ?>
                </a>
                <?php if(count($subcats)): ?>
                <ul class="dropdown-menu">
                    <?php foreach($subcats as $sub): ?>
                    <li><a href="<?php echo SITE_URL; ?>/subcategory.php?slug=<?php echo $sub['slug']; ?>"><?php echo htmlspecialchars($sub['name']); ?></a></li>
                    <?php endforeach; ?>
                </ul>
                <?php endif; ?>
            </li>
            <?php endforeach; ?>
        </ul>

        <!-- Hamburger -->
        <button id="hamburger" title="Menu">
            <i class="fas fa-bars"></i>
        </button>
    </div>
</nav>

<!-- Mobile Nav Overlay -->
<div class="mobile-nav-overlay" id="mobileOverlay"></div>

<!-- Mobile Nav Drawer -->
<div class="mobile-nav" id="mobileNav">
    <div class="mobile-nav-header">
        <div class="mobile-nav-logo"><i class="fas fa-newspaper" style="color:var(--primary);"></i> News<span>Portal</span></div>
        <button class="mobile-nav-close" id="mobileNavClose"><i class="fas fa-times"></i></button>
    </div>
    <div class="mobile-nav-links">
        <div class="mobile-nav-section">Navigation</div>
        <a href="<?php echo SITE_URL; ?>"><i class="fas fa-home"></i> Home</a>
        <?php foreach($categories as $cat): ?>
        <a href="<?php echo SITE_URL; ?>/category.php?slug=<?php echo $cat['slug']; ?>">
            <i class="fas fa-folder"></i> <?php echo htmlspecialchars($cat['name']); ?>
        </a>
        <?php endforeach; ?>
        <div class="mobile-nav-section">Pages</div>
        <a href="<?php echo SITE_URL; ?>/search.php"><i class="fas fa-search"></i> Search</a>
        <a href="<?php echo SITE_URL; ?>/page.php?name=about"><i class="fas fa-info-circle"></i> About Us</a>
        <a href="<?php echo SITE_URL; ?>/page.php?name=contact"><i class="fas fa-envelope"></i> Contact</a>
    </div>
    <div class="mobile-nav-user">
        <?php if(isset($_SESSION['user_id'])): ?>
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;">
            <div style="width:36px;height:36px;background:var(--primary);color:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700;">
                <?php echo strtoupper(substr($_SESSION['user_name'],0,1)); ?>
            </div>
            <div>
                <div style="color:#fff;font-size:13px;font-weight:600;"><?php echo htmlspecialchars($_SESSION['user_name']); ?></div>
                <div style="color:#aaa;font-size:11px;"><?php echo htmlspecialchars($_SESSION['user_email']); ?></div>
            </div>
        </div>
        <a href="<?php echo SITE_URL; ?>/user-logout.php" style="color:#e74c3c;"><i class="fas fa-sign-out-alt"></i> Logout</a>
        <?php else: ?>
        <a href="<?php echo SITE_URL; ?>/user-login.php" style="display:flex;align-items:center;justify-content:center;gap:8px;background:var(--primary);color:#fff;padding:10px;border-radius:6px;font-weight:600;font-size:14px;">
            <i class="fas fa-sign-in-alt"></i> Login / Register
        </a>
        <?php endif; ?>
    </div>
</div>

<!-- Breaking News Ticker -->
<?php if(!empty($breakingPosts)): ?>
<div class="breaking-news">
    <div class="container">
        <div style="display:flex;align-items:center;overflow:hidden;">
            <div class="breaking-label"><i class="fas fa-bolt"></i> Breaking</div>
            <div class="breaking-ticker">
                <div class="breaking-ticker-inner">
                    <?php foreach($breakingPosts as $bp): ?>
                    <a href="<?php echo SITE_URL; ?>/post.php?slug=<?php echo $bp['slug']; ?>">
                        &bull; <?php echo htmlspecialchars($bp['title']); ?>
                    </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Flash Message -->
<?php $flash = getFlash(); if($flash): ?>
<div class="container" style="margin-top:16px;">
    <div class="alert alert-<?php echo $flash['type']; ?>">
        <?php echo htmlspecialchars($flash['message']); ?>
    </div>
</div>
<?php endif; ?>

<script>
// ===== HEADER JS =====
$(document).ready(function(){

    // Dark mode
    var darkToggle = document.getElementById('darkModeToggle');
    var darkIcon   = document.getElementById('darkModeIcon');
    if(localStorage.getItem('darkMode')==='enabled'){
        document.body.classList.add('dark-mode');
        if(darkIcon) darkIcon.className='fas fa-sun';
    }
    if(darkToggle){
        darkToggle.addEventListener('click',function(){
            var isDark = document.body.classList.toggle('dark-mode');
            localStorage.setItem('darkMode', isDark?'enabled':'disabled');
            if(darkIcon) darkIcon.className = isDark?'fas fa-sun':'fas fa-moon';
        });
    }

    // Notification bell
    $('#notifBtn').on('click', function(e){
        e.stopPropagation();
        $('#notifDropdown').toggleClass('open');
        $('#userDropdown').removeClass('open');
    });

    // User menu
    $('#userMenuBtn').on('click', function(e){
        e.stopPropagation();
        $('#userDropdown').toggleClass('open');
        $('#notifDropdown').removeClass('open');
    });

    // Close dropdowns on outside click
    $(document).on('click', function(){
        $('#notifDropdown').removeClass('open');
        $('#userDropdown').removeClass('open');
    });

    // Hamburger menu
    $('#hamburger, #mobileNavClose, #mobileOverlay').on('click', function(){
        $('#mobileNav').toggleClass('open');
        $('#mobileOverlay').toggleClass('open');
    });

});

// Mark notification as read
function markRead(id, link) {
    $.post('<?php echo SITE_URL; ?>/mark-notification.php', { id: id }, function(){
        if(link && link !== '#') window.location.href = link;
    });
}
</script><script>
// ===== HEADER JS - runs after jQuery is ready =====
document.addEventListener('DOMContentLoaded', function() {

    // ===== DARK MODE =====
    var darkToggle = document.getElementById('darkModeToggle');
    var darkIcon   = document.getElementById('darkModeIcon');
    if (localStorage.getItem('darkMode') === 'enabled') {
        document.body.classList.add('dark-mode');
        if (darkIcon) darkIcon.className = 'fas fa-sun';
    }
    if (darkToggle) {
        darkToggle.addEventListener('click', function() {
            var isDark = document.body.classList.toggle('dark-mode');
            localStorage.setItem('darkMode', isDark ? 'enabled' : 'disabled');
            if (darkIcon) darkIcon.className = isDark ? 'fas fa-sun' : 'fas fa-moon';
        });
    }

    // ===== NOTIFICATION BELL =====
    var notifBtn      = document.getElementById('notifBtn');
    var notifDropdown = document.getElementById('notifDropdown');
    var userMenuBtn   = document.getElementById('userMenuBtn');
    var userDropdown  = document.getElementById('userDropdown');

    if (notifBtn && notifDropdown) {
        notifBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            notifDropdown.classList.toggle('open');
            if (userDropdown) userDropdown.classList.remove('open');
        });
    }

    // ===== USER MENU =====
    if (userMenuBtn && userDropdown) {
        userMenuBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            userDropdown.classList.toggle('open');
            if (notifDropdown) notifDropdown.classList.remove('open');
        });
    }

    // ===== CLOSE DROPDOWNS ON OUTSIDE CLICK =====
    document.addEventListener('click', function(e) {
        if (notifDropdown && !notifDropdown.contains(e.target) && e.target !== notifBtn) {
            notifDropdown.classList.remove('open');
        }
        if (userDropdown && !userDropdown.contains(e.target) && e.target !== userMenuBtn) {
            userDropdown.classList.remove('open');
        }
    });

    // ===== HAMBURGER MENU =====
    var hamburger    = document.getElementById('hamburger');
    var mobileNav    = document.getElementById('mobileNav');
    var mobileOverlay = document.getElementById('mobileOverlay');
    var mobileClose  = document.getElementById('mobileNavClose');

    function openMobileNav() {
        if (mobileNav)     mobileNav.classList.add('open');
        if (mobileOverlay) mobileOverlay.classList.add('open');
    }
    function closeMobileNav() {
        if (mobileNav)     mobileNav.classList.remove('open');
        if (mobileOverlay) mobileOverlay.classList.remove('open');
    }

    if (hamburger)     hamburger.addEventListener('click', openMobileNav);
    if (mobileClose)   mobileClose.addEventListener('click', closeMobileNav);
    if (mobileOverlay) mobileOverlay.addEventListener('click', closeMobileNav);

});

// ===== MARK NOTIFICATION READ =====
function markRead(id, link) {
    fetch('<?php echo SITE_URL; ?>/mark-notification.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'id=' + id
    }).then(function() {
        // Remove unread style
        var badge = document.querySelector('.notif-badge');
        if (badge) {
            var count = parseInt(badge.textContent) - 1;
            if (count <= 0) badge.style.display = 'none';
            else badge.textContent = count;
        }
        if (link && link !== '#' && link !== 'null') {
            window.location.href = link;
        }
    });
}
</script>