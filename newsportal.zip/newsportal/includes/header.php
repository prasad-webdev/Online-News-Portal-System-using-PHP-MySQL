<?php
require_once __DIR__ . '/../includes/config.php';
$db = getDB();

// Get categories with subcategories for nav
$cats = $db->query("SELECT * FROM categories WHERE deleted=0 AND status=1 ORDER BY name ASC");
$categories = $cats->fetch_all(MYSQLI_ASSOC);

// Get recent posts for breaking news
$breaking = $db->query("SELECT title, slug FROM posts WHERE status='published' AND deleted=0 ORDER BY created_at DESC LIMIT 8");
$breakingPosts = $breaking->fetch_all(MYSQLI_ASSOC);

$currentPage = basename($_SERVER['PHP_SELF'], '.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? htmlspecialchars($pageTitle) . ' | ' . SITE_NAME : SITE_NAME; ?></title>
    <meta name="description" content="<?php echo isset($metaDesc) ? htmlspecialchars($metaDesc) : 'Your trusted source for the latest news'; ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<!-- Reading Progress Bar -->
<div id="readingProgress" style="position:fixed;top:0;left:0;height:3px;background:var(--primary);z-index:9999;width:0%;transition:width 0.1s;"></div>

<!-- Top Bar -->
<div class="top-bar">
    <div class="container">
        <div style="display:flex;justify-content:space-between;align-items:center;">
            <span><i class="far fa-calendar-alt"></i> <?php echo date('l, F j, Y'); ?></span>
            <div>
                <a href="<?php echo SITE_URL; ?>/page.php?name=about" style="margin-right:14px;">About Us</a>
                <a href="<?php echo SITE_URL; ?>/page.php?name=contact">Contact</a>
            </div>
        </div>
    </div>
</div>

<!-- Site Header -->
<header class="site-header">
    <div class="container">
        <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:16px;">
            <a href="<?php echo SITE_URL; ?>" class="site-logo">
                <i class="fas fa-newspaper"></i> News<span>Portal</span>
            </a>
            <form class="header-search" action="<?php echo SITE_URL; ?>/search.php" method="GET" style="position:relative;">
                <input type="text" id="headerSearch" name="q" placeholder="Search news..." value="<?php echo isset($_GET['q']) ? htmlspecialchars($_GET['q']) : ''; ?>">
                <button type="submit"><i class="fas fa-search"></i></button>
                <div id="searchSuggestions" style="position:absolute;top:100%;left:0;right:40px;background:#fff;border:1px solid var(--border);box-shadow:var(--shadow-hover);z-index:999;display:none;border-radius:0 0 6px 6px;">
                </div>
            </form>
        </div>
    </div>
</header>

<!-- Main Navigation -->
<nav class="main-nav">
    <div class="container">
        <ul id="mainNavList">
            <li><a href="<?php echo SITE_URL; ?>" class="<?php echo $currentPage=='index'?'active':''; ?>"><i class="fas fa-home"></i> Home</a></li>
            <?php foreach($categories as $cat): ?>
            <?php
                $subs = $db->query("SELECT * FROM subcategories WHERE category_id={$cat['id']} AND deleted=0 AND status=1 ORDER BY name ASC");
                $subcats = $subs->fetch_all(MYSQLI_ASSOC);
            ?>
            <li class="<?php echo count($subcats) ? 'dropdown' : ''; ?>">
                <a href="<?php echo count($subcats) ? '#' : SITE_URL.'/category.php?slug='.$cat['slug']; ?>"
                   class="<?php echo (isset($_GET['slug']) && $_GET['slug']==$cat['slug'])?'active':''; ?>">
                    <?php echo htmlspecialchars($cat['name']); ?>
                    <?php if(count($subcats)): ?><i class="fas fa-chevron-down" style="font-size:10px;margin-left:4px;"></i><?php endif; ?>
                </a>
                <?php if(count($subcats)): ?>
                <ul class="dropdown-menu">
                    <?php foreach($subcats as $sub): ?>
                    <li><a href="<?php echo SITE_URL; ?>/subcategory.php?slug=<?php echo $sub['slug']; ?>"><?php echo htmlspecialchars($sub['name']); ?></a></li>
                    <?php endforeach; ?>
                </ul>
                <?php endif; ?>
            </li>
            <?php endforeach; ?>
        </ul>
    </div>
</nav>

<!-- Breaking News Ticker -->
<?php if(!empty($breakingPosts)): ?>
<div class="breaking-news">
    <div class="container">
        <div style="display:flex;align-items:center;overflow:hidden;">
            <div class="breaking-label"><i class="fas fa-bolt"></i> Breaking</div>
            <div class="breaking-ticker">
                <div class="breaking-ticker-inner">
                    <?php foreach($breakingPosts as $bp): ?>
                    <a href="<?php echo SITE_URL; ?>/post.php?slug=<?php echo $bp['slug']; ?>">
                        &bull; <?php echo htmlspecialchars($bp['title']); ?>
                    </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Flash Message -->
<?php $flash = getFlash(); if($flash): ?>
<div class="container" style="margin-top:16px;">
    <div class="alert alert-<?php echo $flash['type']; ?>"><?php echo htmlspecialchars($flash['message']); ?></div>
</div>
<?php endif; ?>
