<?php
$db = getDB();
$footerCats = $db->query("SELECT c.name, c.slug, COUNT(p.id) as cnt FROM categories c LEFT JOIN posts p ON p.category_id=c.id AND p.status='published' AND p.deleted=0 WHERE c.deleted=0 AND c.status=1 GROUP BY c.id ORDER BY cnt DESC LIMIT 8");
$footerCategories = $footerCats->fetch_all(MYSQLI_ASSOC);

$footerPosts = $db->query("SELECT title, slug, created_at FROM posts WHERE status='published' AND deleted=0 ORDER BY created_at DESC LIMIT 4");
$recentFooterPosts = $footerPosts->fetch_all(MYSQLI_ASSOC);
?>
<footer class="site-footer">
    <div class="container">
        <div class="footer-row">
            <div class="footer-col">
                <div class="footer-logo"><i class="fas fa-newspaper"></i> NewsPortal</div>
                <p class="footer-about">Your trusted source for breaking news, in-depth analysis, and comprehensive coverage of local, national, and international events.</p>
                <div style="margin-top:16px;">
                    <a href="#" style="color:#ccc;margin-right:12px;font-size:18px;"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" style="color:#ccc;margin-right:12px;font-size:18px;"><i class="fab fa-twitter"></i></a>
                    <a href="#" style="color:#ccc;margin-right:12px;font-size:18px;"><i class="fab fa-instagram"></i></a>
                    <a href="#" style="color:#ccc;font-size:18px;"><i class="fab fa-youtube"></i></a>
                </div>
            </div>
            <div class="footer-col">
                <div class="footer-title">Categories</div>
                <ul class="footer-links">
                    <?php foreach($footerCategories as $fc): ?>
                    <li><a href="<?php echo SITE_URL; ?>/category.php?slug=<?php echo $fc['slug']; ?>">
                        <i class="fas fa-angle-right" style="color:var(--primary);margin-right:6px;"></i>
                        <?php echo htmlspecialchars($fc['name']); ?> (<?php echo $fc['cnt']; ?>)
                    </a></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <div class="footer-col">
                <div class="footer-title">Latest News</div>
                <?php foreach($recentFooterPosts as $fp): ?>
                <div class="footer-news-item">
                    <a href="<?php echo SITE_URL; ?>/post.php?slug=<?php echo $fp['slug']; ?>"><?php echo htmlspecialchars($fp['title']); ?></a>
                    <div class="footer-news-date"><i class="far fa-clock"></i> <?php echo timeAgo($fp['created_at']); ?></div>
                </div>
                <?php endforeach; ?>
            </div>
            <div class="footer-col">
                <div class="footer-title">Quick Links</div>
                <ul class="footer-links">
                    <li><a href="<?php echo SITE_URL; ?>"><i class="fas fa-angle-right" style="color:var(--primary);margin-right:6px;"></i>Home</a></li>
                    <li><a href="<?php echo SITE_URL; ?>/page.php?name=about"><i class="fas fa-angle-right" style="color:var(--primary);margin-right:6px;"></i>About Us</a></li>
                    <li><a href="<?php echo SITE_URL; ?>/page.php?name=contact"><i class="fas fa-angle-right" style="color:var(--primary);margin-right:6px;"></i>Contact Us</a></li>
                    <li><a href="<?php echo SITE_URL; ?>/search.php"><i class="fas fa-angle-right" style="color:var(--primary);margin-right:6px;"></i>Search</a></li>
                    <li><a href="<?php echo ADMIN_URL; ?>/login.php"><i class="fas fa-angle-right" style="color:var(--primary);margin-right:6px;"></i>Admin Login</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. All rights reserved. | Designed by <i class="fas fa-heart" style="color:var(--primary);"></i> PRASAD</p>
    </div>
</footer>

<!-- Back to Top -->
<button id="backToTop" style="display:none;position:fixed;bottom:24px;right:24px;background:var(--primary);color:#fff;border:none;width:42px;height:42px;border-radius:50%;font-size:16px;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,0.3);z-index:9999;">
    <i class="fas fa-arrow-up"></i>
</button>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="<?php echo SITE_URL; ?>/assets/js/main.js"></script>

<script>
const dropdowns = document.querySelectorAll(".main-nav li.dropdown");

dropdowns.forEach(drop => {

    const link = drop.querySelector("a");

    link.addEventListener("click", function (e) {

        // ONLY block navigation if dropdown exists
        if (drop.querySelector(".dropdown-menu")) {
            e.preventDefault();
        }

        // Close others
        dropdowns.forEach(d => {
            if (d !== drop) d.classList.remove("active");
        });

        // Toggle
        drop.classList.toggle("active");
    });

});

// Outside click
document.addEventListener("click", function (e) {
    if (!e.target.closest(".main-nav")) {
        dropdowns.forEach(d => d.classList.remove("active"));
    }
});
</script>
<!-- AI Features -->
<link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/ai-features.css">
<script src="<?php echo SITE_URL; ?>/assets/js/ai-features.js"></script>

<!-- Floating Chatbot Button -->
<button id="chatbotToggle" title="AI News Assistant">
    <i class="fas fa-robot"></i>
    <span class="chatbot-badge">AI</span>
</button>

<!-- Chatbot Window -->
<div id="chatbotWindow">
    <div class="chatbot-header">
        <div class="chatbot-avatar"><i class="fas fa-robot"></i></div>
        <div class="chatbot-header-info">
            <div class="chatbot-header-name">News AI Assistant</div>
            <div class="chatbot-header-status">Online</div>
        </div>
        <button class="chatbot-close" id="chatbotClose">
            <i class="fas fa-times"></i>
        </button>
    </div>
    <div class="chatbot-messages" id="chatMessages">
        <div class="chat-msg bot">
            <div class="chat-msg-avatar"><i class="fas fa-robot"></i></div>
            <div class="chat-msg-bubble">
                👋 Hi! I'm your <strong>News AI Assistant</strong>.<br><br>
                I can find news, show trending stories, and answer your questions!
            </div>
        </div>
    </div>
    <div class="quick-replies">
        <span class="quick-chip">Latest News</span>
        <span class="quick-chip">Top Stories</span>
        <span class="quick-chip">Technology</span>
        <span class="quick-chip">Sports</span>
    </div>
    <div class="chatbot-input-wrap">
        <input type="text" id="chatbotInput" placeholder="Ask me anything...">
        <button id="chatbotSend"><i class="fas fa-paper-plane"></i></button>
    </div>
</div>
</body>
</html>
