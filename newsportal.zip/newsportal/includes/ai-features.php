<?php
// ===== AI FEATURES BACKEND =====
require_once __DIR__ . '/config.php';

header('Content-Type: application/json');
$action = $_POST['action'] ?? '';

// ==========================================
// 1. AI ARTICLE SUMMARIZER
// Uses free extractive summarization
// ==========================================
function summarizeText($text) {
    $text = strip_tags($text);
    $text = preg_replace('/\s+/', ' ', trim($text));
    
    // Split into sentences
    $sentences = preg_split('/(?<=[.!?])\s+/', $text);
    if(count($sentences) <= 3) return $text;
    
    // Score sentences by keyword frequency
    $wordFreq = [];
    $words = str_word_count(strtolower($text), 1);
    $stopWords = ['the','a','an','and','or','but','in','on','at','to','for',
                  'of','with','by','from','is','are','was','were','be','been',
                  'has','have','had','do','does','did','will','would','could',
                  'should','may','might','this','that','these','those','it',
                  'its','as','so','if','not','no','up','out','about','into'];
    
    foreach($words as $word) {
        if(!in_array($word, $stopWords) && strlen($word) > 3) {
            $wordFreq[$word] = ($wordFreq[$word] ?? 0) + 1;
        }
    }
    
    // Score each sentence
    $scores = [];
    foreach($sentences as $i => $sentence) {
        $sentWords = str_word_count(strtolower($sentence), 1);
        $score = 0;
        foreach($sentWords as $word) {
            $score += $wordFreq[$word] ?? 0;
        }
        // Boost first and last sentences
        if($i === 0) $score *= 1.5;
        if($i === count($sentences) - 1) $score *= 1.2;
        $scores[$i] = $score;
    }
    
    // Pick top 3 sentences
    arsort($scores);
    $topKeys = array_slice(array_keys($scores), 0, 3);
    sort($topKeys);
    
    $summary = [];
    foreach($topKeys as $key) {
        $summary[] = trim($sentences[$key]);
    }
    
    return implode(' ', $summary);
}

// ==========================================
// 2. SENTIMENT ANALYZER
// Analyzes news article tone
// ==========================================
function analyzeSentiment($text) {
    $text = strtolower(strip_tags($text));
    
    $positiveWords = ['good','great','excellent','amazing','wonderful','fantastic',
                      'positive','success','win','victory','growth','improve',
                      'better','best','happy','joy','love','hope','progress',
                      'achieve','benefit','gain','strong','rise','increase',
                      'breakthrough','innovative','solution','recover','peace',
                      'prosper','thrive','advance','support','help','save'];
    
    $negativeWords = ['bad','terrible','awful','horrible','negative','fail',
                      'loss','defeat','decline','worse','worst','sad','fear',
                      'hate','crisis','problem','danger','risk','threat','attack',
                      'death','disaster','war','violence','crime','corrupt',
                      'crash','collapse','drop','fall','suffer','victim','damage',
                      'destroy','conflict','protest','controversy','scandal'];
    
    $words = str_word_count($text, 1);
    $posCount = 0;
    $negCount = 0;
    
    foreach($words as $word) {
        if(in_array($word, $positiveWords)) $posCount++;
        if(in_array($word, $negativeWords)) $negCount++;
    }
    
    $total = $posCount + $negCount;
    if($total === 0) {
        return ['sentiment' => 'Neutral', 'score' => 50, 'positive' => 0, 'negative' => 0, 'icon' => '😐', 'color' => '#f39c12'];
    }
    
    $score = round(($posCount / $total) * 100);
    
    if($score >= 65) {
        $sentiment = 'Positive';
        $icon = '😊';
        $color = '#27ae60';
    } elseif($score <= 35) {
        $sentiment = 'Negative';
        $icon = '😟';
        $color = '#e74c3c';
    } else {
        $sentiment = 'Neutral';
        $icon = '😐';
        $color = '#f39c12';
    }
    
    return [
        'sentiment' => $sentiment,
        'score'     => $score,
        'positive'  => $posCount,
        'negative'  => $negCount,
        'icon'      => $icon,
        'color'     => $color
    ];
}

// ==========================================
// 3. RELATED NEWS SUGGESTIONS
// Smart keyword-based matching
// ==========================================
function getRelatedNews($postId, $title, $tags, $categoryId) {
    $db = getDB();
    $postId = intval($postId);
    $categoryId = intval($categoryId);
    
    // Extract keywords from title
    $stopWords = ['the','a','an','and','or','but','in','on','at','to','for','of',
                  'with','by','is','are','was','were','this','that','it','as','news'];
    $titleWords = str_word_count(strtolower($title), 1);
    $keywords = array_filter($titleWords, function($w) use($stopWords) {
        return !in_array($w, $stopWords) && strlen($w) > 3;
    });
    
    // Also use tags
    $tagArr = $tags ? array_map('trim', explode(',', strtolower($tags))) : [];
    $searchTerms = array_unique(array_merge(array_values($keywords), $tagArr));
    
    if(empty($searchTerms)) {
        // Fallback to same category
        $results = $db->query("SELECT id, title, slug, image, created_at FROM posts 
                               WHERE category_id=$categoryId AND id!=$postId 
                               AND status='published' AND deleted=0 
                               ORDER BY views DESC LIMIT 4")->fetch_all(MYSQLI_ASSOC);
        return $results;
    }
    
    // Score posts by keyword matches
    $allPosts = $db->query("SELECT p.id, p.title, p.slug, p.image, p.created_at, p.tags, p.views,
                            c.name as cat_name
                            FROM posts p 
                            LEFT JOIN categories c ON c.id=p.category_id
                            WHERE p.id!=$postId AND p.status='published' AND p.deleted=0 
                            ORDER BY p.created_at DESC LIMIT 50")->fetch_all(MYSQLI_ASSOC);
    
    $scored = [];
    foreach($allPosts as $post) {
        $score = 0;
        $postText = strtolower($post['title'] . ' ' . $post['tags']);
        
        foreach($searchTerms as $term) {
            if(strpos($postText, $term) !== false) {
                $score += strlen($term) > 5 ? 3 : 1;
            }
        }
        
        // Boost same category
        if(isset($post['category_id']) && $post['category_id'] == $categoryId) $score += 2;
        // Boost popular posts
        $score += min(2, $post['views'] / 100);
        
        if($score > 0) $scored[] = array_merge($post, ['score' => $score]);
    }
    
    usort($scored, fn($a, $b) => $b['score'] - $a['score']);
    return array_slice($scored, 0, 4);
}

// ==========================================
// 4. AI CHATBOT
// Smart news-aware Q&A bot
// ==========================================
function chatbotResponse($message) {
    $db = getDB();
    $message = strtolower(trim($message));
    
    // Greeting patterns
    $greetings = ['hello','hi','hey','good morning','good evening','good afternoon','namaste','salaam'];
    foreach($greetings as $g) {
        if(strpos($message, $g) !== false) {
            return "Hello! 👋 I'm your News Assistant. I can help you find news, summaries, and answer questions about our portal. What would you like to know?";
        }
    }
    
    // Help
    if(strpos($message, 'help') !== false || strpos($message, 'what can you do') !== false) {
        return "I can help you with:\n\n• 🔍 Find latest news by topic\n• 📰 Show news by category\n• 📊 Give you today's top stories\n• ℹ️ Answer questions about our portal\n\nJust ask me something like 'Show me technology news' or 'What are today's top stories?'";
    }
    
    // Latest/recent news
    if(strpos($message, 'latest') !== false || strpos($message, 'recent') !== false || strpos($message, 'today') !== false || strpos($message, 'new') !== false) {
        $posts = $db->query("SELECT title, slug FROM posts WHERE status='published' AND deleted=0 ORDER BY created_at DESC LIMIT 5")->fetch_all(MYSQLI_ASSOC);
        if($posts) {
            $response = "📰 Here are the latest news stories:\n\n";
            foreach($posts as $i => $p) {
                $response .= ($i+1) . ". <a href='".SITE_URL."/post.php?slug={$p['slug']}' target='_blank'>" . htmlspecialchars($p['title']) . "</a>\n";
            }
            return $response;
        }
    }
    
    // Top/popular stories
    if(strpos($message, 'top') !== false || strpos($message, 'popular') !== false || strpos($message, 'trending') !== false) {
        $posts = $db->query("SELECT title, slug, views FROM posts WHERE status='published' AND deleted=0 ORDER BY views DESC LIMIT 5")->fetch_all(MYSQLI_ASSOC);
        if($posts) {
            $response = "🔥 Top trending stories:\n\n";
            foreach($posts as $i => $p) {
                $response .= ($i+1) . ". <a href='".SITE_URL."/post.php?slug={$p['slug']}' target='_blank'>" . htmlspecialchars($p['title']) . "</a> (" . number_format($p['views']) . " views)\n";
            }
            return $response;
        }
    }
    
    // Category search
    $cats = $db->query("SELECT * FROM categories WHERE deleted=0 AND status=1")->fetch_all(MYSQLI_ASSOC);
    foreach($cats as $cat) {
        if(strpos($message, strtolower($cat['name'])) !== false) {
            $posts = $db->query("SELECT title, slug FROM posts WHERE category_id={$cat['id']} AND status='published' AND deleted=0 ORDER BY created_at DESC LIMIT 4")->fetch_all(MYSQLI_ASSOC);
            if($posts) {
                $response = "📂 Latest <strong>" . htmlspecialchars($cat['name']) . "</strong> news:\n\n";
                foreach($posts as $i => $p) {
                    $response .= ($i+1) . ". <a href='".SITE_URL."/post.php?slug={$p['slug']}' target='_blank'>" . htmlspecialchars($p['title']) . "</a>\n";
                }
                return $response;
            } else {
                return "No " . htmlspecialchars($cat['name']) . " news found at the moment. Check back later!";
            }
        }
    }
    
    // Search by keyword in DB
    $keyword = $db->real_escape_string($message);
    $posts = $db->query("SELECT title, slug FROM posts WHERE (title LIKE '%$keyword%' OR tags LIKE '%$keyword%') AND status='published' AND deleted=0 ORDER BY created_at DESC LIMIT 4")->fetch_all(MYSQLI_ASSOC);
    if($posts) {
        $response = "🔍 Found news related to \"" . htmlspecialchars($message) . "\":\n\n";
        foreach($posts as $i => $p) {
            $response .= ($i+1) . ". <a href='".SITE_URL."/post.php?slug={$p['slug']}' target='_blank'>" . htmlspecialchars($p['title']) . "</a>\n";
        }
        return $response;
    }
    
    // About portal
    if(strpos($message, 'about') !== false || strpos($message, 'portal') !== false || strpos($message, 'website') !== false) {
        return "📰 <strong>NewsPortal</strong> is your trusted source for the latest news from around the world. We cover Politics, Technology, Sports, Business, Entertainment, Health, Science, and more!\n\nVisit our <a href='".SITE_URL."/page.php?name=about'>About Us</a> page to learn more.";
    }
    
    // Contact
    if(strpos($message, 'contact') !== false) {
        return "📞 You can reach us through our <a href='".SITE_URL."/page.php?name=contact'>Contact page</a>. We'd love to hear from you!";
    }
    
    // Goodbye
    if(strpos($message, 'bye') !== false || strpos($message, 'goodbye') !== false || strpos($message, 'thanks') !== false || strpos($message, 'thank you') !== false) {
        return "Thank you for visiting NewsPortal! 😊 Stay informed and have a great day!";
    }
    
    // Default fallback
    return "🤔 I'm not sure about that. Try asking:\n• \"Show latest news\"\n• \"Technology news\"\n• \"Top stories today\"\n• \"Sports news\"\n\nOr use the <a href='".SITE_URL."/search.php?q=".urlencode($message)."'>search</a> to find specific articles.";
}

// ==========================================
// HANDLE AJAX REQUESTS
// ==========================================
switch($action) {
    case 'summarize':
        $content = $_POST['content'] ?? '';
        if(!$content) { echo json_encode(['error' => 'No content provided']); exit; }
        $summary = summarizeText($content);
        echo json_encode(['success' => true, 'summary' => $summary, 'words' => str_word_count(strip_tags($content))]);
        break;
        
    case 'sentiment':
        $content = $_POST['content'] ?? '';
        if(!$content) { echo json_encode(['error' => 'No content provided']); exit; }
        $result = analyzeSentiment($content);
        echo json_encode(['success' => true, 'data' => $result]);
        break;
        
    case 'related':
        $postId    = intval($_POST['post_id'] ?? 0);
        $title     = $_POST['title'] ?? '';
        $tags      = $_POST['tags'] ?? '';
        $catId     = intval($_POST['category_id'] ?? 0);
        $results   = getRelatedNews($postId, $title, $tags, $catId);
        echo json_encode(['success' => true, 'posts' => $results]);
        break;
        
    case 'chatbot':
        $message  = $_POST['message'] ?? '';
        if(!$message) { echo json_encode(['error' => 'No message']); exit; }
        $response = chatbotResponse($message);
        echo json_encode(['success' => true, 'response' => $response]);
        break;
        
    default:
        echo json_encode(['error' => 'Invalid action']);
}
?>