<?php
require_once 'includes/config.php';
$db = getDB();
$pageTitle = 'Home - Latest News';
$metaDesc = 'Stay updated with the latest news from around the world.';

// Featured post
$featured = $db->query("SELECT p.*, c.name as cat_name, c.slug as cat_slug, a.name as author FROM posts p LEFT JOIN categories c ON c.id=p.category_id LEFT JOIN admins a ON a.id=p.admin_id WHERE p.status='published' AND p.deleted=0 ORDER BY p.created_at DESC LIMIT 1")->fetch_assoc();

// Recent posts (skip featured)
$featuredId = $featured ? $featured['id'] : 0;
$recent = $db->query("SELECT p.*, c.name as cat_name, c.slug as cat_slug FROM posts p LEFT JOIN categories c ON c.id=p.category_id WHERE p.status='published' AND p.deleted=0 AND p.id!=$featuredId ORDER BY p.created_at DESC LIMIT 6")->fetch_all(MYSQLI_ASSOC);

// Posts by category sections
$catSections = $db->query("SELECT * FROM categories WHERE deleted=0 AND status=1 ORDER BY name ASC LIMIT 4")->fetch_all(MYSQLI_ASSOC);

include 'includes/header.php';
?>

<div class="main-content">
    <div class="container">
        <div class="row">
            <!-- Main Content -->
            <div class="col-8">
                <!-- Featured Post -->
                <?php if($featured): ?>
                <div class="featured-post">
                    <?php if($featured['image']): ?>
                    <img src="<?php echo UPLOAD_URL . htmlspecialchars($featured['image']); ?>" alt="<?php echo htmlspecialchars($featured['title']); ?>" class="featured-post-img">
                    <?php else: ?>
                    <div style="width:100%;height:400px;background:linear-gradient(135deg,#c0392b,#2c3e50);display:flex;align-items:center;justify-content:center;border-radius:6px 6px 0 0;">
                        <i class="fas fa-newspaper" style="font-size:80px;color:rgba(255,255,255,0.3);"></i>
                    </div>
                    <?php endif; ?>
                    <div class="featured-post-body">
                        <a href="category.php?slug=<?php echo $featured['cat_slug']; ?>" class="featured-post-category"><?php echo htmlspecialchars($featured['cat_name']); ?></a>
                        <div class="featured-post-title">
                            <a href="post.php?slug=<?php echo $featured['slug']; ?>"><?php echo htmlspecialchars($featured['title']); ?></a>
                        </div>
                        <p style="color:var(--text-muted);font-size:14px;margin-bottom:14px;"><?php echo truncate($featured['content'], 200); ?></p>
                        <div class="news-card-meta">
                            <span><i class="fas fa-user"></i> <?php echo htmlspecialchars($featured['author']); ?></span>
                            <span><i class="far fa-calendar"></i> <?php echo date('M j, Y', strtotime($featured['created_at'])); ?></span>
                            <span><i class="fas fa-eye"></i> <?php echo number_format($featured['views']); ?> views</span>
                        </div>
                        <a href="post.php?slug=<?php echo $featured['slug']; ?>" class="btn btn-primary btn-sm" style="margin-top:14px;">Read More <i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Recent News Grid -->
                <div class="section-title">Latest News</div>
                <div class="row">
                    <?php foreach($recent as $post): ?>
                    <div class="col-6">
                        <div class="news-card">
                            <?php if($post['image']): ?>
                            <img src="<?php echo UPLOAD_URL . htmlspecialchars($post['image']); ?>" alt="" class="news-card-img">
                            <?php else: ?>
                            <div class="no-img"><i class="fas fa-newspaper"></i></div>
                            <?php endif; ?>
                            <div class="news-card-body">
                                <a href="category.php?slug=<?php echo $post['cat_slug']; ?>" class="news-card-category"><?php echo htmlspecialchars($post['cat_name']); ?></a>
                                <div class="news-card-title">
                                    <a href="post.php?slug=<?php echo $post['slug']; ?>"><?php echo htmlspecialchars($post['title']); ?></a>
                                </div>
                                <p class="news-card-excerpt"><?php echo truncate($post['content'], 120); ?></p>
                                <div class="news-card-meta">
                                    <span><i class="far fa-calendar"></i> <?php echo timeAgo($post['created_at']); ?></span>
                                    <span><i class="fas fa-eye"></i> <?php echo number_format($post['views']); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>

                <!-- Category Sections -->
                <?php foreach($catSections as $catSec): ?>
                <?php
                    $catPosts = $db->query("SELECT p.*, c.name as cat_name, c.slug as cat_slug FROM posts p LEFT JOIN categories c ON c.id=p.category_id WHERE p.status='published' AND p.deleted=0 AND p.category_id={$catSec['id']} ORDER BY p.created_at DESC LIMIT 3");
                    $catPostsArr = $catPosts->fetch_all(MYSQLI_ASSOC);
                    if(empty($catPostsArr)) continue;
                ?>
                <div style="margin-bottom:30px;">
                    <div class="section-title" style="display:flex;justify-content:space-between;align-items:center;">
                        <?php echo htmlspecialchars($catSec['name']); ?>
                        <a href="category.php?slug=<?php echo $catSec['slug']; ?>" style="font-size:13px;font-weight:500;text-transform:none;color:var(--primary);">View All <i class="fas fa-arrow-right"></i></a>
                    </div>
                    <div class="row">
                        <?php foreach($catPostsArr as $i=>$cp): ?>
                        <div class="<?php echo $i==0 ? 'col-12' : 'col-6'; ?>">
                            <div class="news-card" style="<?php echo $i==0 ? 'display:flex;' : ''; ?>">
                                <?php if($i==0): ?>
                                    <?php if($cp['image']): ?>
                                    <img src="<?php echo UPLOAD_URL . htmlspecialchars($cp['image']); ?>" alt="" style="width:240px;height:180px;object-fit:cover;flex-shrink:0;">
                                    <?php else: ?>
                                    <div style="width:240px;height:180px;background:linear-gradient(135deg,#e0e0e0,#bdbdbd);display:flex;align-items:center;justify-content:center;flex-shrink:0;"><i class="fas fa-newspaper" style="font-size:40px;color:#999;"></i></div>
                                    <?php endif; ?>
                                    <div class="news-card-body">
                                <?php else: ?>
                                    <?php if($cp['image']): ?>
                                    <img src="<?php echo UPLOAD_URL . htmlspecialchars($cp['image']); ?>" alt="" class="news-card-img">
                                    <?php else: ?>
                                    <div class="no-img"><i class="fas fa-newspaper"></i></div>
                                    <?php endif; ?>
                                    <div class="news-card-body">
                                <?php endif; ?>
                                        <div class="news-card-title">
                                            <a href="post.php?slug=<?php echo $cp['slug']; ?>"><?php echo htmlspecialchars($cp['title']); ?></a>
                                        </div>
                                        <p class="news-card-excerpt"><?php echo truncate($cp['content'], 100); ?></p>
                                        <div class="news-card-meta">
                                            <span><i class="far fa-calendar"></i> <?php echo timeAgo($cp['created_at']); ?></span>
                                        </div>
                                    </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <!-- Sidebar -->
            <div class="col-4">
                <?php include 'includes/sidebar.php'; ?>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
