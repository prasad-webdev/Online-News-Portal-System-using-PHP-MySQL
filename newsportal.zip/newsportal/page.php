<?php
require_once 'includes/config.php';
$db = getDB();

$name = isset($_GET['name']) ? sanitize($_GET['name']) : 'about';
if(!in_array($name, ['about','contact'])) redirect(SITE_URL);

$page = $db->query("SELECT * FROM pages WHERE page_name='$name'")->fetch_assoc();
if(!$page) redirect(SITE_URL);

$pageTitle = $page['title'];
include 'includes/header.php';
?>
<div class="breadcrumb"><div class="container"><a href="<?php echo SITE_URL; ?>">Home</a><span>&rsaquo;</span><span><?php echo htmlspecialchars($page['title']); ?></span></div></div>
<div class="main-content">
    <div class="container">
        <div class="row">
            <div class="col-8">
                <div style="background:#fff;padding:32px;border-radius:6px;box-shadow:var(--shadow);">
                    <h1 style="font-size:28px;color:var(--secondary);margin-bottom:20px;padding-bottom:14px;border-bottom:2px solid var(--primary);"><?php echo htmlspecialchars($page['title']); ?></h1>
                    <div style="font-size:15px;line-height:1.8;color:#444;">
                        <?php echo $page['content']; ?>
                    </div>
                </div>
            </div>
            <div class="col-4"><?php include 'includes/sidebar.php'; ?></div>
        </div>
    </div>
</div>
<?php include 'includes/footer.php'; ?>
