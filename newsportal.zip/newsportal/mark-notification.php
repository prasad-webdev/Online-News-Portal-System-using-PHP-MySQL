<?php
require_once 'includes/config.php';
$db = getDB();
if(!isset($_SESSION['user_id'])) exit;
$notifId = intval($_POST['id'] ?? 0);
$userId  = intval($_SESSION['user_id']);
if($notifId) {
    $exists = $db->query("SELECT id FROM user_notifications WHERE user_id=$userId AND notification_id=$notifId")->num_rows;
    if(!$exists) {
        $db->query("INSERT INTO user_notifications (user_id, notification_id, is_read) VALUES ($userId, $notifId, 1)");
    } else {
        $db->query("UPDATE user_notifications SET is_read=1 WHERE user_id=$userId AND notification_id=$notifId");
    }
}
echo json_encode(['success'=>true]);